(function() {
    try {
        (function() {
            function kf(a, c, b, d) {
                var e = this;
                return E(window, "c.i", function() {
                    function f(F) {
                        (F = lf(l, m, "", F)(l, m)) && (O(F.then) ? F.then(g) : g(F));
                        return F
                    }

                    function g(F) {
                        F && (O(F) ? p.push(F) : ka(F) && x(function(P) {
                            var M = P[0];
                            P = P[1];
                            O(P) && ("u" === M ? p.push(P) : h(P, M))
                        }, La(F)))
                    }

                    function h(F, P, M) {
                        e[P] = jm(l, m, M || q, P, F)
                    }
                    var k, l = window;
                    (!l || isNaN(a) && !a) && fe();
                    var m = km(a, ge, c, b, d),
                        p = [],
                        q = [rh, lf, sh];
                    q.unshift(lm);
                    var r = A(Q, Za),
                        t = L(m);
                    m.id || Va(Qa("Invalid Metrika id: " + m.id, !0));
                    var y = kd.C("counters", {});
                    if (y[t]) return Kb(l,
                        t, "dc", (k = {}, k.key = t, k)), y[t];
                    mm(l, t, th(a, c, b, d));
                    y[t] = e;
                    kd.D("counters", y);
                    kd.Ia("counter", e);
                    x(function(F) {
                        F(l, m)
                    }, mf);
                    x(f, ld);
                    f(nm);
                    h(om(l, m, p), "destruct", [rh, sh]);
                    Tb(l, C([l, r, f, 1, "a.i"], uh));
                    x(f, W)
                })()
            }

            function pm(a, c) {
                delete J(a).C("cok", {})[c]
            }

            function mm(a, c, b) {
                a = J(a);
                var d = a.C("cok", {});
                d[c] = b;
                a.D("cok", d)
            }

            function qm(a, c) {
                var b = "" + c,
                    d = {
                        id: 1,
                        ca: "0"
                    },
                    e = rm(b);
                e ? d.id = e : -1 === ib(b, ":") ? (b = Ha(b), d.id = b) : (b = b.split(":"), e = b[1], d.id = Ha(b[0]), d.ca = he(e) ? "1" : "0");
                return [za(a, d), d]
            }

            function sm(a) {
                return ka(a) &&
                    R(a.code)
            }

            function tm(a, c) {
                var b, d = c.slice(2),
                    e = [(b = {}, b.require = {
                        kind: 0,
                        value: w(um, Nc([a, {}]))
                    }, b)];
                nf(e, ie([3], d))
            }

            function nf(a, c, b) {
                c = c.slice(1);
                a.push(b || {});
                x(function(d) {
                    R(d) && 3 === d[0] ? nf(a, d) : !R(d) || 18 !== d[0] && 19 !== d[0] ? R(d) && 2 === d[0] && cc(a, d[1]) : vm(a, d)
                }, c);
                a.pop()
            }

            function vm(a, c) {
                var b = 18 === c[0];
                x(function(d) {
                    var e = d[0],
                        f = d[1];
                    if (b && 1 === d.length) throw Qa("mca");
                    d = a[a.length - 1];
                    if (Lb(d, e)) throw Qa("vr");
                    f = cc(a, f);
                    d[e] = {
                        kind: b ? 0 : 1,
                        value: f
                    }
                }, c.slice(1))
            }

            function cc(a, c) {
                if (ia(c) || "[object Number]" ===
                    Object.prototype.toString.call(c) || !!c === c || ca(c)) return c;
                if (R(c) && 40 === c[0]) {
                    a: {
                        var b = c[1];
                        for (var d = a.length; 0 < d;) {
                            var e = a[--d];
                            if (Lb(e, b)) {
                                b = e[b];
                                break a
                            }
                        }
                        b = void 0
                    }
                    if (!b) throw Qa("vnd");
                    return b.value
                }
                if (R(c) && 37 === c[0]) {
                    d = c.slice(2);
                    b = cc(a, c[1]);
                    if (!O(b)) throw Qa("tenf");
                    d = A(u(a, cc), d);
                    return b.apply(null, d)
                }
                if (R(c) && 24 === c[0]) return wm(a, c);
                if (R(c) && 35 === c[0]) {
                    d = c[2];
                    b = cc(a, c[1]);
                    d = cc(a, d);
                    if (!b) throw Qa("noma");
                    return b["" + d]
                }
                if (R(c) && 23 === c[0]) return xm(a, c)
            }

            function xm(a, c) {
                return N(function(b,
                    d) {
                    var e = d[1],
                        f = cc(a, d[0]);
                    e = cc(a, e);
                    b["" + f] = e;
                    return b
                }, {}, c.slice(1))
            }

            function wm(a, c) {
                var b = c[1],
                    d = c[2],
                    e = c[3],
                    f = A(Q, a);
                return function() {
                    var g = arguments,
                        h = N(function(k, l, m) {
                            if (k[l]) throw Qa("da");
                            k[l] = {
                                kind: 1,
                                value: g[m]
                            };
                            return k
                        }, {}, d);
                    b && !I(b, d) && (h[b] = {
                        kind: 0,
                        value: b
                    });
                    nf(f, e, h)
                }
            }

            function um(a) {
                return zm[a]
            }

            function of (a, c) {
                return function() {
                    try {
                        return c.apply(null, arguments)
                    } catch (b) {
                        vh(a, b)
                    }
                }
            }

            function Am(a, c, b, d) {
                function e() {
                    g.state = 1;
                    b()
                }

                function f() {
                    g.state = 2;
                    d && d()
                }
                var g = Bm(a, c);
                c = g.Di;
                var h = g.state;
                c && 2 !== h ? 1 === h ? e() : (a = fa(a), a.F(c, ["load"], e), a.F(c, ["error"], f)) : f()
            }

            function Bm(a, c) {
                pf[c] || (pf[c] = {
                    Di: uc(a, {
                        src: c
                    }),
                    state: 0
                });
                return pf[c]
            }

            function wh(a, c) {
                if (ca(a)) throw Qa("noma");
                if (1 === c.length) return a;
                var b = n(a, G(".", c.slice(0, -1)));
                if (!b) throw Qa("noma");
                return b
            }

            function Cm(a) {
                return N(function(c, b) {
                    Lb(a, b) && (c[b] = a[b]);
                    return c
                }, {}, da(a))
            }

            function Dm(a, c) {
                if ("*" === c) return !0;
                var b = S(a);
                return c === b.host + b.pathname
            }

            function Em(a, c) {
                var b = n(c, "target");
                b && a(b)
            }

            function Fm(a,
                c, b) {
                var d = n(b, "submitter");
                d || (b = n(b, "target")) && (d = je(a, b));
                d && c(d)
            }

            function Gm(a, c, b, d) {
                var e = ke(a, d);
                e && x(function(f) {
                    var g, h = null;
                    try {
                        var k = n(f, "css_selector"),
                            l = dc(k, a.document);
                        h = xh(l)
                    } catch (r) {}
                    k = null;
                    try {
                        var m = n(f, "xpath"),
                            p = Hm(m);
                        var q = p ? n(a, "document.evaluate") ? a.document.evaluate(p, a.document, null, a.XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue : null : null;
                        k = xh(q)
                    } catch (r) {}
                    f = (g = {}, g.s = [k, h], g.b = e, g);
                    c(f)
                }, b)
            }

            function xh(a) {
                return (a = Mb(a)) ? md(le(a)) : null
            }

            function Hm(a) {
                if (!a) return "";
                a = a.match(Im);
                if (!a || 0 === a.length) return "";
                var c = Jm();
                return "//HTML/BODY/" + N(function(b, d) {
                    var e = d[0],
                        f = Ha(d.slice(1));
                    return "/" + c[e] + (f ? "[" + (f + 1) + "]" : "") + b
                }, "", a)
            }

            function Km(a) {
                x(function(c) {
                    var b;
                    if (c.data.auctionId) {
                        var d = c.event,
                            e = c.data;
                        c = e.auctionId;
                        Ia[c] || (Ia[c] = (b = {}, b.auctionId = c, b));
                        b = "auctionInit" === d;
                        if (!Ia[c].startStamp || b) Ia[c].startStamp = b ? e.auctionStart || e.timestamp : e.auctionStart;
                        if (I(d, Lm)) {
                            if (b = e.bidderCode) {
                                Ia[c][d] || (Ia[c][d] = {});
                                var f = {};
                                Ia[c][d][b] = f;
                                x(function(g) {
                                    var h = e[g];
                                    ca(h) || (f[g] = h)
                                }, Mm);
                                Ia[c].endStamp && (Ia[c].aa = !0)
                            }
                        } else "auctionEnd" === d && (Ia[c].aa = !0, Ia[c].endStamp = e.auctionEnd || e.timestamp, Ia[c].requestedBidders = ha(function(g, h, k) {
                            return qf(g, k) === h
                        }, A(T("bidderCode"), e.bidderRequests)))
                    }
                }, a)
            }

            function Nm(a, c) {
                x(function(b) {
                    b.aa && Om(a, c, b.auctionId)
                }, yh(Ia))
            }

            function Om(a, c, b) {
                Ia[b].aa = !1;
                Ia[b].Ka && la(a, Ia[b].Ka);
                Ia[b].Ka = U(a, function() {
                    var d, e;
                    delete Ia[b].Ka;
                    delete Ia[b].aa;
                    c((d = {}, d.__ym = (e = {}, e.pbjs = Ia[b], e), d));
                    delete Ia[b]
                }, 2E3)
            }

            function Pm(a) {
                var c = n(a,
                    "featurePolicy");
                return c ? "browsingTopics" in a && c.allowsFeature("browsing-topics") : !1
            }

            function Qm(a, c, b, d) {
                var e = n(d, "data");
                if (ia(e)) {
                    var f = e.split("*");
                    e = f[0];
                    var g = f[1];
                    f = f[2];
                    "sc.topics-response" === e ? (g && ("1" === g && f ? (a = qb(a, f), R(a) && c.D("cta", a)) : c.D("cta.e", g)), b()) : "sc.frame" === e && d.source && d.source.postMessage("sc.topics", "*")
                }
            }

            function Rm(a, c) {
                var b;
                if ("https://oauth.yandex.ru" === n(c, "origin") && n(c, "source.window") && "_ym_uid_request" === n(c.data, "_ym")) {
                    var d = c.source,
                        e = (b = {}, b._ym_uid = a, b);
                    d.postMessage(e, "https://oauth.yandex.ru")
                }
            }

            function zh(a, c) {
                void 0 === c && (c = !0);
                var b = dc("canvas", a.document);
                if (b && (b = Oc(b))) {
                    var d = me(a) || Pc(a),
                        e = d[0];
                    d = d[1];
                    if (.3 <= Ah(a, b, {
                            h: d,
                            w: e
                        }) / (d * e)) {
                        J(a).D("hc", 1);
                        return
                    }
                }
                c && U(a, C([a, !1], zh), 3E3)
            }

            function Bh(a) {
                return {
                    N: function(c, b) {
                        Sm(a).then(function(d) {
                            c.J || (c.J = {});
                            c.J.uah = d;
                            b()
                        }, b)
                    }
                }
            }

            function Tm(a) {
                var c = N(function(b, d) {
                    var e = d[1],
                        f = Um(a[d[0]]);
                    f && b.push("" + e + "\n" + f);
                    return b
                }, [], La(Vm));
                return G("\n", c)
            }

            function Wm(a) {
                return "che\n" + a
            }

            function Um(a) {
                return ia(a) ?
                    a : R(a) ? G(",", A(function(c) {
                        return '"' + c.brand + '";v="' + c.version + '"'
                    }, a)) : ca(a) ? "" : a ? "?1" : "?0"
            }

            function Xm(a, c) {
                var b = Ym(a),
                    d = [Zm(a) || $m(a)];
                Ch(a) && d.push(b);
                var e = ja(a);
                b = Oa(a);
                var f = b.C("synced", {});
                d = ha(function(g) {
                    if (c[g]) {
                        var h = (f[g] || 1) + 1440 < e(rb);
                        h && delete f[g];
                        return h
                    }
                }, d);
                b.D("synced", f);
                return A(function(g) {
                    return {
                        Ni: c[g],
                        $h: g
                    }
                }, d)
            }

            function $m(a) {
                a = an(a);
                return bn[a] || a
            }

            function Ym(a) {
                a = Dh(a);
                return cn[a] || "ru"
            }

            function dn(a, c, b, d) {
                if (!b.K || he(c.ca)) d();
                else {
                    var e = ne(a),
                        f = u(e, en),
                        g = Qc(a,
                            ""),
                        h = function() {
                            var q = G(",", A(fn(rf), oe(e)));
                            q = "" + q + gn(q, g);
                            pe(b, "gdpr", q);
                            d()
                        };
                    if (c.fj) f("31"), h();
                    else if (3 === c.id) h();
                    else {
                        var k = J(a),
                            l = k.C("f1");
                        if (l) l(h);
                        else if (l = oe(e), $a(vc(rf), l)) h();
                        else if (g.C("yandex_login")) f("13"), g.D("gdpr", Rc, 525600), h();
                        else {
                            l = qe(a);
                            var m = S(a);
                            var p = /(^|\w+\.)yango(\.yandex)?\.com$/.test(m.hostname) ? {
                                url: "https://yastatic.net/s3/taxi-front/yango-gdpr-popup/",
                                version: 2,
                                rf: hn,
                                zf: "_inversed_buttons"
                            } : void 0;
                            l || p ? (l = g.C("gdpr"), I(l, wc) ? (f(l === sf ? "12" : "3"), h()) : tf(a) ||
                                jn(a) ? (f("17"), h()) : kn(a).then(Q, D).then(function(q) {
                                    q ? (f("28"), h()) : (Eh(h), k.D("f1", Eh), (0, uf[0])(a).then(T("params.eu")).then(function(r) {
                                        if (r || eb(m.href, "yagdprcheck=1") || g.C("yaGdprCheck")) {
                                            g.D("gdpr_popup", sf);
                                            ln(a, c);
                                            if (sb(a)) return mn(a, f, c);
                                            var t = Fh(a, e);
                                            if (t) return r = nn(a, f, t, c, p), r.then(C([a, c], on)), r
                                        }
                                        r || f("8");
                                        return K.resolve({
                                            value: Rc,
                                            Nd: !0
                                        })
                                    }).then(function(r) {
                                        g.pc("gdpr_popup");
                                        if (r) {
                                            var t = r.value;
                                            r = r.Nd;
                                            I(t, wc) && g.D("gdpr", t, r ? void 0 : 525600)
                                        }
                                        t = ec(Gh, ma);
                                        nd(a, t, 20)(Ra(E(a, "gdr"), D));
                                        k.D("f1", ma)
                                    })["catch"](E(a, "gdp.a")))
                                })) : (f("14"), h())
                        }
                    }
                }
            }

            function on(a, c) {
                if (qe(a)) {
                    var b = ne(a),
                        d = za(a, c);
                    d = d && d.params;
                    b = A(u(pn, n), oe(b));
                    d && b.length && d("gdpr", ua(b))
                }
            }

            function mn(a, c, b) {
                var d = re(a, b);
                return new K(function(e) {
                    var f;
                    if (d) {
                        var g = d.$,
                            h = w(u("4", c), u(null, e)),
                            k = U(a, h, 2E3, "gdp.f.t");
                        d.Tf((f = {}, f.type = "isYandex", f)).then(function(l) {
                            l.isYandex ? (c("5"), g.F(Hh, function(m) {
                                e({
                                    value: Ih(m[1].type)
                                })
                            })) : (c("6"), e(null))
                        })["catch"](h).then(C([a, k], la))
                    } else e({
                        value: sf,
                        Nd: !0
                    })
                })
            }

            function ln(a,
                c) {
                var b = re(a, c);
                b && b.$.F(["isYandex"], function() {
                    var d;
                    return d = {
                        type: "isYandex"
                    }, d.isYandex = qe(a), d
                });
                return b
            }

            function qn(a, c, b) {
                a = b || Dh(a);
                return I(a, c) ? a : "en"
            }

            function Ih(a) {
                if (I(a, ["GDPR-ok-view-default", "GDPR-ok-view-detailed"])) return Rc;
                a = a.replace("GDPR-ok-view-detailed-", "");
                return I(a, wc) ? a : Rc
            }

            function Jh(a, c, b) {
                var d = n(a, "AppMetricaInitializer"),
                    e = n(d, "init");
                if (e) try {
                    H(e, d)(Ab(a, c))
                } catch (f) {} else Kh = U(a, C([a, c, 2 * b], Jh), b, "ai.d");
                return function() {
                    return la(a, Kh)
                }
            }

            function Lh(a, c, b,
                d) {
                var e, f, g, h = b.Uh,
                    k = b.Ph;
                b = b.isTrusted;
                a = vf(a, k);
                k = k.readOnly;
                d = (e = {}, e.fi = wf((f = {}, f.a = h ? 1 : 0, f.b = a, f.c = d || 0, f.d = k ? 1 : null, f)).Ha(), e);
                ca(b) || (d.ite = tb(b));
                c.params((g = {}, g.__ym = d, g))
            }

            function Mh(a, c) {
                var b = n(c, "target");
                if (b) {
                    var d = n(b, "value");
                    if ((d = ab(d)) && !(100 <= Sa(d))) {
                        var e = "tel" === n(b, "type"),
                            f = 0 < ib(d, "@") && !e,
                            g = Ub(d),
                            h = Sa(g);
                        if (f || !f && (e || h)) {
                            if (f) {
                                if (d = Nh(d), 5 > Sa(d) || 100 < Sa(d)) return
                            } else {
                                if (rn(d) || Sa(d) - h > h || 10 > Sa(g) || 16 < Sa(g)) return;
                                e = g[0];
                                g = d[1];
                                if ("+" === d[0] && g !== e) return;
                                d = Oh(a, d)
                            }
                            e =
                                n(c, "isTrusted");
                            return {
                                Ph: b,
                                Uh: f,
                                Qh: d,
                                isTrusted: e
                            }
                        }
                    }
                }
            }

            function Ph(a, c, b, d, e) {
                if (!od(a)) return D;
                var f = [],
                    g = fa(a);
                Nb(a)(Ra(D, function() {
                    var h = jb(c, a.document.body);
                    e && (h = ha(e, h));
                    x(function(l) {
                        f.push(g.F(l, b, d))
                    }, h);
                    if (Da("MutationObserver", a.MutationObserver)) {
                        var k = c.toUpperCase();
                        h = new a.MutationObserver(E(a, "de.m", function(l) {
                            x(function(m) {
                                var p = m.addedNodes;
                                m = m.removedNodes;
                                p && p.length && x(function(q) {
                                    pd(a, q, function(r) {
                                        r.nodeName !== k || e && !e(r) || f.push(g.F(r, b, d))
                                    }, void 0, a.NodeFilter.SHOW_ELEMENT, !0)
                                }, p);
                                m && m.length && x(function(q) {
                                    pd(a, q, function(r) {
                                        r.nodeName !== k || e && !e(r) || g.xb(r, b, d)
                                    }, void 0, a.NodeFilter.SHOW_ELEMENT, !0)
                                }, m)
                            }, l)
                        }));
                        h.observe(a.document.body, {
                            childList: !0,
                            subtree: !0
                        });
                        f.push(H(h.disconnect, h))
                    }
                }));
                return C([ma, f], x)
            }

            function sn(a) {
                var c = n(a, "speechSynthesis.getVoices");
                if (c) return a = H(c, a.speechSynthesis), xc(function(b) {
                    return A(u(b, n), tn)
                }, a())
            }

            function un(a, c, b) {
                return G("x", A(w(Q, Ea("concat", "" + a), u(b, n)), c))
            }

            function vn(a, c) {
                var b = c.Fg;
                if (!wn(a, b)) return "";
                var d = [];
                a: {
                    var e = xn(a, b);
                    try {
                        var f = C(e, w)()();
                        break a
                    } catch (F) {
                        if ("ccf" === F.message) {
                            f = null;
                            break a
                        }
                        Va(F)
                    }
                    f = void 0
                }
                if (Wa(f)) var g = "";
                else try {
                    g = f.toDataURL()
                } catch (F) {
                    g = ""
                }(f = g) && d.push(f);
                var h = b.getContextAttributes();
                try {
                    var k = oa(b.getSupportedExtensions, "getSupportedExtensions") ? b.getSupportedExtensions() || [] : []
                } catch (F) {
                    k = []
                }
                k = G(";", k);
                f = xf(b.getParameter(b.ALIASED_LINE_WIDTH_RANGE), b);
                e = xf(b.getParameter(b.ALIASED_POINT_SIZE_RANGE), b);
                g = b.getParameter(b.ALPHA_BITS);
                h = h && h.antialias ? "yes" : "no";
                var l =
                    b.getParameter(b.BLUE_BITS),
                    m = b.getParameter(b.DEPTH_BITS),
                    p = b.getParameter(b.GREEN_BITS),
                    q = b.getExtension("EXT_texture_filter_anisotropic") || b.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || b.getExtension("MOZ_EXT_texture_filter_anisotropic");
                if (q) {
                    var r = b.getParameter(q.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
                    0 === r && (r = 2)
                }
                r = {
                    rj: k,
                    "webgl aliased line width range": f,
                    "webgl aliased point size range": e,
                    "webgl alpha bits": g,
                    "webgl antialiasing": h,
                    "webgl blue bits": l,
                    "webgl depth bits": m,
                    "webgl green bits": p,
                    "webgl max anisotropy": q ? r : null,
                    "webgl max combined texture image units": b.getParameter(b.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
                    "webgl max cube map texture size": b.getParameter(b.MAX_CUBE_MAP_TEXTURE_SIZE),
                    "webgl max fragment uniform vectors": b.getParameter(b.MAX_FRAGMENT_UNIFORM_VECTORS),
                    "webgl max render buffer size": b.getParameter(b.MAX_RENDERBUFFER_SIZE),
                    "webgl max texture image units": b.getParameter(b.MAX_TEXTURE_IMAGE_UNITS),
                    "webgl max texture size": b.getParameter(b.MAX_TEXTURE_SIZE),
                    "webgl max varying vectors": b.getParameter(b.MAX_VARYING_VECTORS),
                    "webgl max vertex attribs": b.getParameter(b.MAX_VERTEX_ATTRIBS),
                    "webgl max vertex texture image units": b.getParameter(b.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
                    "webgl max vertex uniform vectors": b.getParameter(b.MAX_VERTEX_UNIFORM_VECTORS),
                    "webgl max viewport dims": xf(b.getParameter(b.MAX_VIEWPORT_DIMS), b),
                    "webgl red bits": b.getParameter(b.RED_BITS),
                    "webgl renderer": b.getParameter(b.RENDERER),
                    "webgl shading language version": b.getParameter(b.SHADING_LANGUAGE_VERSION),
                    "webgl stencil bits": b.getParameter(b.STENCIL_BITS),
                    "webgl vendor": b.getParameter(b.VENDOR),
                    "webgl version": b.getParameter(b.VERSION)
                };
                yf(d, r, ": ");
                a: {
                    try {
                        var t = b.getExtension("WEBGL_debug_renderer_info");
                        if (t) {
                            var y = {
                                "webgl unmasked vendor": b.getParameter(t.UNMASKED_VENDOR_WEBGL),
                                "webgl unmasked renderer": b.getParameter(t.UNMASKED_RENDERER_WEBGL)
                            };
                            break a
                        }
                    } catch (F) {}
                    y = {}
                }
                yf(d, y);
                if (!b.getShaderPrecisionFormat) return G("~", d);
                yf(d, yn(b));
                return G("~", d)
            }

            function yf(a, c, b) {
                void 0 === b && (b = ":");
                x(function(d) {
                    return a.push("" + d[0] + b + d[1])
                }, La(c))
            }

            function zn(a,
                c, b, d) {
                c = d.C("cc");
                d = C(["cc", ""], d.D);
                if (c) {
                    var e = c.split("&");
                    c = e[0];
                    if ((e = (e = e[1]) && Ha(e)) && 1440 < ja(a)(rb) - e) return d();
                    b.D("cc", c)
                } else Aa(0)(c) || d()
            }

            function An(a, c, b, d) {
                return pa(c, function(e) {
                    if (!zf(e) && !qd(a))
                        if (e = d.C("zzlc"), X(e) || Wa(e) || "na" === e) {
                            var f = fb(a);
                            if (f && (e = fc(a))) {
                                var g = f("iframe");
                                z(g.style, {
                                    display: "none",
                                    width: "1px",
                                    height: "1px",
                                    visibility: "hidden"
                                });
                                f = Af(a, 68);
                                var h = Bf(a, 79);
                                g.src = "https://mc.yandex." + (f || h ? "md" : "ru") + Qh("L21ldHJpa2EvenpsYy5odG1s");
                                e.appendChild(g);
                                var k = 0,
                                    l = fa(a).F(a, ["message"], E(a, "zz.m", function(m) {
                                        (m = n(m, "data")) && m.substr && "__ym__zz" === m.substr(0, 8) && (yc(g), m = m.substr(8), d.D("zzlc", m), b.D("zzlc", m), l(), la(a, k))
                                    }));
                                k = U(a, w(l, u(g, yc)), 3E3)
                            }
                        } else b.D("zzlc", e)
                })
            }

            function Bn(a, c, b) {
                var d, e;
                c = ub(u(a, n), Cn);
                c = X(c) ? null : n(a, c);
                if (n(a, "navigator.onLine") && c && c && n(c, "prototype.constructor.name")) {
                    var f = new c((d = {}, d.iceServers = [], d));
                    a = n(f, "createDataChannel");
                    O(a) && (H(a, f, "y.metrika")(), a = n(f, "createOffer"), O(a) && !a.length && (a = H(a, f)(), d = n(a, "then"),
                        O(d) && H(d, a, function(g) {
                            var h = n(f, "setLocalDescription");
                            O(h) && H(h, f, g, D, D)()
                        })(), z(f, (e = {}, e.onicecandidate = function() {
                            var g, h = n(f, "close");
                            if (O(h)) {
                                h = H(h, f);
                                try {
                                    var k = (g = n(f, "localDescription.sdp")) && g.match(/c=IN\s[\w\d]+\s([\w\d:.]+)/)
                                } catch (l) {
                                    f.onicecandidate = D;
                                    "closed" !== f.iceConnectionState && h();
                                    return
                                }
                                k && 0 < k.length && (g = gc(k[1]), b.D("pp", g));
                                f.onicecandidate = D;
                                h()
                            }
                        }, e))))
                }
            }

            function Dn(a, c, b) {
                var d, e = rd(a, c);
                if (e) {
                    e.$.F(["gpu-get"], function() {
                        var h;
                        return h = {}, h.type = "gpu-get", h.pu = b.C("pu"),
                            h
                    });
                    var f = n(a, "opener");
                    if (f) {
                        var g = U(a, C([a, c, b], Rh), 200, "pu.m");
                        e.oe(f, (d = {}, d.type = "gpu-get", d), function(h, k) {
                            var l = n(k, "pu");
                            l && (la(a, g), b.D("pu", l))
                        })
                    } else Rh(a, c, b)
                }
            }

            function Rh(a, c, b) {
                var d = n(a, "location.host");
                a = sd(a, c);
                b.D("pu", "" + gc(d) + a)
            }

            function Sh(a, c, b) {
                c = Qc(a, void 0, c);
                c = Th(a, c.C("phc_settings") || "");
                var d = n(c, "clientId"),
                    e = n(c, "orderId"),
                    f = n(c, "service_id"),
                    g = n(c, "phones") || [];
                return d && e && g && f ? En(a, b.kc, {
                        eg: Fn
                    })(g).then(function(h) {
                        return Gn(b, {
                            Db: d,
                            Pb: e,
                            Wf: f
                        }, h.ja, g, h.Aa)
                    })["catch"](D) :
                    K.resolve()
            }

            function Fn(a, c, b) {
                a = Hn(b.Sb);
                if ("href" === b.ke) {
                    var d = b.sb;
                    c = d.href;
                    b = c.replace(a, b.bb);
                    if (c !== b) return d.href = b, !0
                } else if ((a = null === (d = b.sb.textContent) || void 0 === d ? void 0 : d.replace(a, b.bb)) && a !== b.sb.textContent) return b.sb.textContent = a, !0;
                return !1
            }

            function Gn(a, c, b, d, e) {
                var f;
                c.Db && c.Pb && (c.Db === a.Db && c.Pb === a.Pb || z(a, c, {
                    ja: {},
                    gb: !0
                }), 0 < e && ra(a.Aa, [e]), x(function(g) {
                    var h, k, l = g[0];
                    g = g[1];
                    var m = +(a.ja[l] && a.ja[l][g] ? a.ja[l][g] : 0);
                    z(a.ja, (h = {}, h[l] = (k = {}, k[g] = m, k), h))
                }, d), x(function(g) {
                    var h,
                        k, l = g[0];
                    g = g[1];
                    var m = 1 + (a.ja[l] ? a.ja[l][g] : 0);
                    z(a.ja, (h = {}, h[l] = (k = {}, k[g] = m, k), h))
                }, b), a.nf && (a.gb || b.length) && ((c = za(a.l, a.kc)) && c.params("__ym", "phc", (f = {}, f.clientId = a.Db, f.orderId = a.Pb, f.service_id = a.Wf, f.phones = a.ja, f.performance = a.Aa, f)), a.gb = !1))
            }

            function In(a) {
                a = fb(a);
                if (!a) return "";
                a = a("video");
                try {
                    var c = Ea("canPlayType", a),
                        b = xc(function(d) {
                            return A(w(Q, Ea("concat", d + "; codecs=")), Jn)
                        }, Uh);
                    return A(c, Uh.concat(b))
                } catch (d) {
                    return "canPlayType"
                }
            }

            function Kn(a) {
                var c = n(a, "matchMedia");
                if (c &&
                    Da("matchMedia", c)) {
                    var b = Ea("matchMedia", a);
                    return N(function(d, e) {
                        d[e] = b("(" + e + ")");
                        return d
                    }, {}, Ln)
                }
            }

            function yn(a) {
                return N(function(c, b) {
                    var d = b[0],
                        e = b[1];
                    c[d + " precision"] = n(e, "precision") || "n";
                    c[d + " precision rangeMin"] = n(e, "rangeMin") || "n";
                    c[d + " precision rangeMax"] = n(e, "rangeMax") || "n";
                    return c
                }, {}, [
                    ["webgl vertex shader high float", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.HIGH_FLOAT)],
                    ["webgl vertex shader medium", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.MEDIUM_FLOAT)],
                    ["webgl vertex shader low float",
                        a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.LOW_FLOAT)
                    ],
                    ["webgl fragment shader high float", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.HIGH_FLOAT)],
                    ["webgl fragment shader medium float", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.MEDIUM_FLOAT)],
                    ["webgl fragment shader low float", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.LOW_FLOAT)],
                    ["webgl vertex shader high int", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.HIGH_INT)],
                    ["webgl vertex shader medium int", a.getShaderPrecisionFormat(a.VERTEX_SHADER,
                        a.MEDIUM_INT)],
                    ["webgl vertex shader low int", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.LOW_INT)],
                    ["webgl fragment shader high int", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.HIGH_INT)],
                    ["webgl fragment shader medium int", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.MEDIUM_INT)],
                    ["webgl fragment shader low int precision", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.LOW_INT)]
                ])
            }

            function xn(a, c) {
                return [function() {
                    var b = c.createBuffer();
                    b && c.getParameter && Da("getParameter", c.getParameter) ||
                        Cf();
                    c.bindBuffer(c.ARRAY_BUFFER, b);
                    var d = new a.Float32Array(Mn);
                    c.bufferData(c.ARRAY_BUFFER, d, c.STATIC_DRAW);
                    b.Wh = 3;
                    b.ii = 3;
                    d = c.createProgram();
                    var e = c.createShader(c.VERTEX_SHADER);
                    d && e || Cf();
                    return {
                        ie: d,
                        ej: e,
                        dj: b
                    }
                }, function(b) {
                    var d = b.ie,
                        e = b.ej;
                    c.shaderSource(e, "attribute vec2 attrVertex;varying vec2 varyinTexCoordinate;uniform vec2 uniformOffset;void main(){varyinTexCoordinate=attrVertex+uniformOffset;gl_Position=vec4(attrVertex,0,1);}");
                    c.compileShader(e);
                    c.attachShader(d, e);
                    (d = c.createShader(c.FRAGMENT_SHADER)) ||
                    Cf();
                    return z(b, {
                        lh: d
                    })
                }, function(b) {
                    var d = b.ie,
                        e = b.lh;
                    c.shaderSource(e, "precision mediump float;varying vec2 varyinTexCoordinate;void main() {gl_FragColor=vec4(varyinTexCoordinate,0,1);}");
                    c.compileShader(e);
                    c.attachShader(d, e);
                    c.linkProgram(d);
                    c.useProgram(d);
                    return b
                }, function(b) {
                    var d = b.ie;
                    b = b.dj;
                    d.cj = c.getAttribLocation(d, "attrVertex");
                    d.ki = c.getUniformLocation(d, "uniformOffset");
                    c.enableVertexAttribArray(d.Lj);
                    c.vertexAttribPointer(d.cj, b.Wh, c.FLOAT, !1, 0, 0);
                    c.uniform2f(d.ki, 1, 1);
                    c.drawArrays(c.TRIANGLE_STRIP,
                        0, b.ii);
                    return c.canvas
                }]
            }

            function wn(a, c) {
                if (!O(a.Float32Array)) return !1;
                var b = n(c, "canvas");
                if (!b || !Da("toDataUrl", b.toDataURL)) return !1;
                try {
                    c.createBuffer()
                } catch (d) {
                    return !1
                }
                return !0
            }

            function xf(a, c) {
                c.clearColor(0, 0, 0, 1);
                c.enable(c.DEPTH_TEST);
                c.depthFunc(c.LEQUAL);
                c.clear(c.COLOR_BUFFER_BIT | c.DEPTH_BUFFER_BIT);
                return "[" + n(a, "0") + ", " + n(a, "1") + "]"
            }

            function Nn(a, c) {
                if (n(c, "settings.ins")) {
                    var b = J(a);
                    if (!b.C("scip")) {
                        var d = Oa(a),
                            e = ja(a)(rb),
                            f = se(d.C("sci"));
                        if (!(f && 1440 >= e - f)) {
                            f = va(a, "ci");
                            var g = ["sync.cook.int"],
                                h = function(l) {
                                    l = b.C("scip", "") + l;
                                    b.D("scip", l)
                                },
                                k = u("a", h);
                            b.D("scip", "0");
                            return f({
                                ba: {
                                    ha: g,
                                    Qa: 3E3,
                                    Ab: !0
                                }
                            }, ["https://an.yandex.ru/sync_cookie"]).then(function(l) {
                                l = n(l.Rc, "CookieMatchUrls");
                                if (R(l) && Sa(l)) {
                                    h("1");
                                    var m = va(a, "c");
                                    l = A(function(p, q) {
                                        return m({
                                            ba: {
                                                ha: g,
                                                Qa: 3E3
                                            }
                                        }, ["https://" + p])["catch"](w(u("b", h), u("" + q, h)))
                                    }, ha(ia, l));
                                    return K.all(l)
                                }
                                k()
                            }, k).then(function() {
                                var l = b.C("scip");
                                !l || eb(l, "a") || eb(l, "b") || (d.D("sci", e), h("2"))
                            }, D)
                        }
                    }
                }
            }

            function Vh(a) {
                return {
                    N: function(c,
                        b) {
                        if (!c.K) return b();
                        var d = J(a).C("fid");
                        !Wh && d && (pe(c, "fid", d), Wh = !0);
                        return b()
                    }
                }
            }

            function On(a, c) {
                var b = a.document;
                if (I(b.readyState, ["interactive", "complete"])) Tb(a, c);
                else {
                    var d = fa(a),
                        e = d.F,
                        f = d.xb,
                        g = function() {
                            f(b, ["DOMContentLoaded"], g);
                            f(a, ["load"], g);
                            c()
                        };
                    e(b, ["DOMContentLoaded"], g);
                    e(a, ["load"], g)
                }
            }

            function Df(a) {
                return {
                    N: function(c, b) {
                        var d = c.K;
                        if (d) {
                            var e = J(a).C("adBlockEnabled");
                            e && d.D("adb", e)
                        }
                        b()
                    }
                }
            }

            function Pn(a) {
                var c = E(a, "i.clch", Qn);
                fa(a).F(a.document, ["click"], u(a, c), {
                    passive: !1
                });
                return function(b) {
                    var d = Fa.Sa,
                        e = a.Ya[Fa.jc],
                        f = !!e._informer;
                    e._informer = z({
                        domain: "informer.yandex.ru"
                    }, b);
                    f || uc(a, {
                        src: d + "//informer.yandex.ru/metrika/informer.js"
                    })
                }
            }

            function Rn(a, c) {
                var b = Oa(a);
                if ("" === b.C("cc")) {
                    var d = u("cc", b.D);
                    d(0);
                    var e = ja(a),
                        f = J(a);
                    f = w(T(Sn({
                        Rc: 1
                    }) + ".c"), Sc(function(g) {
                        d(g + "&" + e(rb))
                    }), u("cc", f.D));
                    va(a, "6", c)({
                        ba: {
                            Ab: !0,
                            Ie: !1
                        }
                    }, ["https://mc.yandex.md/cc"]).then(f)["catch"](w(Sc(function() {
                        var g = e(rb);
                        b.D("cc", "&" + g)
                    }), E(a, "cc")))
                }
            }

            function te(a, c) {
                if (!c) return !1;
                var b =
                    S(a);
                return (new RegExp(c)).test("" + b.pathname + b.hash + b.search)
            }

            function Tn(a, c) {
                return pa(c, function(b) {
                    var d = n(b, "settings.dr");
                    return {
                        Tg: Un(a, d),
                        isEnabled: n(b, "settings.auto_goals")
                    }
                })
            }

            function Vn(a, c, b, d, e) {
                b = Ef(a.document.body, b);
                d = Ef(a.document.body, d);
                I(e.target, [b, d]) && Ff(a, c)
            }

            function Xh(a, c, b, d) {
                (b = Wn(a, d, b)) && Ff(a, c, b)
            }

            function Yh(a, c) {
                var b = Zh(a, c);
                return Xn(a, b)
            }

            function Zh(a, c) {
                var b = Ef(a.document.body, c);
                return b ? Yn(a, b) : ""
            }

            function Ff(a, c, b) {
                if (c = za(a, c)) a = td(["dr", b || "" + Xa(a, 10, 99)]),
                    c.params(td(["__ym", a]))
            }

            function Ef(a, c) {
                var b = null;
                try {
                    b = c ? dc(c, a) : b
                } catch (d) {}
                return b
            }

            function $h(a) {
                a = Ba(Qh(a));
                return A(function(c) {
                    c = c.charCodeAt(0).toString(2);
                    return ai("0", 8, c)
                }, a)
            }

            function Yn(a, c) {
                if (!c) return "";
                var b = [],
                    d = n(a, "document");
                pd(a, c, function(e) {
                    if (e.nodeType === d.TEXT_NODE) var f = e.textContent;
                    else e instanceof a.HTMLImageElement ? f = e.alt : e instanceof a.HTMLInputElement && (f = e.value);
                    (f = f && ab(f)) && b.push(f)
                });
                return 0 === b.length ? "" : G(" ", b)
            }

            function Zn(a, c, b) {
                a = Pa(b);
                b = a[1];
                "track" ===
                a[0] && c({
                    version: "0",
                    rc: b
                })
            }

            function $n(a, c, b) {
                if (b) {
                    var d = b.version;
                    (b = n(ao, d + "." + b.rc)) && (c && I(b, bo) || a("ym-" + b + "-" + d))
                }
            }

            function co(a, c, b) {
                if ("rt" === b) return "https://" + bi(a, c) + ".mc.yandex.ru/watch/3/1";
                if ("mf" === b) {
                    b = S(a);
                    b = ue(b.protocol + "//" + b.hostname + b.pathname);
                    c = sd(a, c);
                    var d = "";
                    do d += Xa(a); while (d.length < c.length);
                    d = d.slice(0, c.length);
                    a = "";
                    for (var e = 0; e < c.length; e += 1) a += (c.charCodeAt(e) + d.charCodeAt(e) - 96) % 10;
                    a = [d, a];
                    return "https://adstat.yandex.ru/track?service=metrika&id=" + a[1] + "&mask=" +
                        a[0] + "&ref=" + b
                }
            }

            function eo(a, c, b) {
                var d, e = Gf(c).Rb;
                return va(a, "pi", c)({
                    K: Ja((d = {}, d[e] = 1, d))
                }, [b])
            }

            function fo(a, c, b) {
                return new K(function(d, e) {
                    if (ci(a, ve, "isp")) {
                        var f = D,
                            g = function(h) {
                                ("1" === h ? d : e)();
                                f();
                                di(ve, "isp")
                            };
                        f = fa(a).F(a, ["message"], C([b, g], E(a, "isp.stat.m", go)));
                        U(a, g, 1500)
                    } else e()
                })
            }

            function go(a, c, b) {
                var d = n(b, "data");
                if (ia(d)) {
                    var e = d.split("*");
                    d = e[0];
                    var f = e[1];
                    e = e[2];
                    "sc.frame" === d && b.source ? b.source.postMessage("sc.images*" + a, "*") : "sc.image" === d && f === a && c(e)
                }
            }

            function ho(a, c) {
                var b =
                    Oa(a),
                    d = "wv2rf:" + L(c),
                    e = c.fc,
                    f = Hf(a),
                    g = b.C(d),
                    h = c.Wi;
                return X(f) || Wa(g) ? Ga(function(k, l) {
                    pa(c, function(m) {
                        var p = !!n(m, "settings.webvisor.forms");
                        p = !n(m, "settings.x3") && p;
                        f = Hf(a) || n(m, "settings.eu");
                        b.D(d, tb(p));
                        l({
                            fc: e,
                            Md: !!f,
                            Cf: p,
                            gg: h
                        })
                    })
                }) : If({
                    fc: e,
                    Md: f,
                    Cf: !!Ha(g),
                    gg: h
                })
            }

            function io() {
                var a = N(function(c, b) {
                    c[b[0]] = {
                        gd: 0,
                        Dg: 1 / b[1]
                    };
                    return c
                }, {}, [
                    ["blur", .0034],
                    ["change", .0155],
                    ["click", .01095],
                    ["deviceRotation", 2E-4],
                    ["focus", .0061],
                    ["mousemove", .5132],
                    ["scroll", .4795],
                    ["selection", .0109],
                    ["touchcancel",
                        2E-4
                    ],
                    ["touchend", .0265],
                    ["touchforcechange", .0233],
                    ["touchmove", .1442],
                    ["touchstart", .027],
                    ["zoom", .0014]
                ]);
                return {
                    zg: function(c) {
                        if (c.length) return {
                            type: "activity",
                            data: N(function(b, d) {
                                var e = a[d];
                                return Math.round(b + e.gd * e.Dg)
                            }, 0, da(a))
                        }
                    },
                    li: function(c) {
                        c && (c = a[c.data.type || c.event]) && (c.gd += 1)
                    }
                }
            }

            function jo(a) {
                return {
                    nh: function() {
                        var c = a.document.querySelector("base[href]");
                        return c ? c.getAttribute("href") : null
                    },
                    ph: function() {
                        if (a.document.doctype) {
                            var c = z({
                                        name: "html",
                                        publicId: "",
                                        systemId: ""
                                    },
                                    a.document.doctype),
                                b = c.publicId,
                                d = c.systemId;
                            return "<!DOCTYPE " + G("", [c.name, b ? ' PUBLIC "' + b + '"' : "", !b && d ? " SYSTEM" : "", d ? ' "' + d + '"' : ""]) + ">"
                        }
                        return null
                    }
                }
            }

            function ko(a, c, b) {
                var d = ud(a),
                    e = fa(a),
                    f = sb(a),
                    g = c.Ad(),
                    h = !n(a, "postMessage") || f && !n(a, "parent.postMessage"),
                    k = u(d, Q);
                if (h) {
                    if (!g) return U(a, H(d.R, d, "i", {
                        va: !1
                    }), 10), {
                        zd: k,
                        Pf: D,
                        stop: D
                    };
                    Va(Ta())
                }
                d.F(["sr"], function(r) {
                    var t, y = ei(a, r.source);
                    y && Jf(a, r.source, (t = {}, t.type = "\u043d", t.frameId = c.sa().Z(y), t))
                });
                d.F(["sd"], function(r) {
                    var t = r.data;
                    r =
                        r.source;
                    (a === r || ei(a, r)) && d.R("sdr", {
                        data: t.data,
                        frameId: t.frameId
                    })
                });
                if (f && !g) {
                    var l = !1,
                        m = 0,
                        p = function() {
                            var r;
                            Jf(a, a.parent, (r = {}, r.type = "sr", r));
                            m = U(a, p, 100, "if.i")
                        };
                    p();
                    var q = function(r) {
                        d.ga(["\u043d"], q);
                        la(a, m);
                        var t = Tc(a, r.origin).host;
                        l || r.source !== a.parent || !r.data.frameId || "about:blank" !== S(a).host && !I(t, b) || (l = !0, d.R("i", {
                            frameId: r.data.frameId,
                            va: !0
                        }))
                    };
                    d.F(["\u043d"], q);
                    U(a, function() {
                        d.ga(["\u043d"], q);
                        la(a, m);
                        l || (l = !0, d.R("i", {
                            va: !1
                        }))
                    }, 2E3, "if.r")
                }
                e = e.F(a, ["message"], function(r) {
                    var t =
                        qb(a, r.data);
                    t && t.type && I(t.type, lo) && d.R(t.type, {
                        data: t,
                        source: r.source,
                        origin: r.origin
                    })
                });
                return {
                    zd: k,
                    Pf: function(r) {
                        var t;
                        return Jf(a, a.parent, (t = {}, t.frameId = c.Ad(), t.data = r, t.type = "sd", t))
                    },
                    stop: e
                }
            }

            function ei(a, c) {
                try {
                    return ub(w(T("contentWindow"), Aa(c)), Ba(a.document.querySelectorAll("iframe")))
                } catch (b) {
                    return null
                }
            }

            function Jf(a, c, b) {
                c || Va(Ta());
                a = Ab(a, b);
                c.postMessage(a, "*")
            }

            function fi() {
                return hc() + hc() + "-" + hc() + "-" + hc() + "-" + hc() + "-" + hc() + hc() + hc()
            }

            function hc() {
                return Math.floor(65536 *
                    (1 + Math.random())).toString(16).substring(1)
            }

            function mo(a, c) {
                if (ia(c)) return c;
                var b = a.textContent;
                if (ia(b)) return b;
                b = a.data;
                if (ia(b)) return b;
                b = a.nodeValue;
                return ia(b) ? b : ""
            }

            function no(a, c, b, d, e) {
                void 0 === d && (d = {});
                void 0 === e && (e = Ma(c));
                var f = z(N(function(h, k) {
                    h[k.name] = k.value;
                    return h
                }, {}, Ba(c.attributes)), d);
                z(f, oo(c, e, f));
                var g = (d = Bb(function(h, k) {
                    var l = k[0],
                        m = we(a, c, l, k[1], b, e),
                        p = m.value;
                    ca(p) ? delete f[l] : f[l] = p;
                    return h || m.pb
                }, !1, La(f))) && Oc(c);
                g && (f.width = g.width, f.height = g.height);
                return {
                    pb: d,
                    Ag: f
                }
            }

            function oo(a, c, b) {
                var d = {};
                Kf(a) ? d.value = a.value || b.value : "IMG" !== c || b.src || (d.src = "");
                return d
            }

            function we(a, c, b, d, e, f) {
                void 0 === f && (f = Ma(c));
                var g = {
                    pb: !1,
                    value: d
                };
                if (Kf(c)) "value" === b ? !ca(d) && "" !== d && (b = e.Md, f = e.Cf, e = vd(a, c), f ? (b = Uc(a, c, b), a = b.qb, c = b.hb, b = b.Va, g.pb = !c && (e || a)) : (g.pb = e, b = !(c && ic("ym-record-keys", c))), b || e) && (d = "" + d, g.value = 0 < d.length ? gi("\u2022", d.length) : "") : "checked" === b && I((c.getAttribute("type") || "").toLowerCase(), po) ? g.value = c.checked ? "checked" : null : qo.test(b) && Lf(a,
                    c) && (g.value = null);
                else if ("IMG" === f && "src" === b)(e = vd(a, c)) ? (g.pb = e, g.value = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=") : g.value = (c.getAttribute("srcset") ? c.currentSrc : "") || c.src;
                else if ("A" === f && "href" === b) g.value = d ? "#" : "";
                else if (I(b, ["srcset", "integrity", "crossorigin", "password"]) || 2 < b.length && 0 === ib(b, "on") || "IFRAME" === f && "src" === b || "SCRIPT" === f && I(b, ["src", "type"])) g.value = null;
                return g
            }

            function Mf(a, c, b, d) {
                void 0 === d &&
                    (d = "wv2");
                return {
                    H: function(e, f) {
                        return E(a, d + "." + b + "." + f, e, void 0, c)
                    }
                }
            }

            function ro(a, c, b, d, e) {
                function f() {
                    l && l.stop()
                }
                if (!c.zb) return K.resolve(D);
                var g = va(a, "4", c),
                    h = {
                        K: Ja()
                    },
                    k = new so(a, b, function(m, p, q) {
                        if (!g) return K.resolve();
                        var r = "wv-data=" + md(m, !0),
                            t = E(a, "m.n.m.s");
                        p = {};
                        p["wv-part"] = "" + q;
                        q = m.length;
                        for (var y = 0, F = 255, P = 255, M, na, wa; q;) {
                            M = 21 < q ? 21 : q;
                            q -= M;
                            do na = "string" === typeof m ? m.charCodeAt(y) : m[y], y += 1, 255 < na && (wa = na >> 8, na &= 255, na ^= wa), F += na, P += F; while (--M);
                            F = (F & 255) + (F >> 8);
                            P = (P & 255) + (P >>
                                8)
                        }
                        m = (F & 255) + (F >> 8) << 8 | (P & 255) + (P >> 8);
                        return g(z({}, h, {
                            ba: {
                                da: r
                            },
                            J: (p["wv-check"] = "" + (65535 === m ? 0 : m), p["wv-type"] = b.type, p)
                        }), c)["catch"](t)
                    }),
                    l = to(a, k, d, e);
                return pa(c, function(m) {
                    m && J(a).D("isEU", n(m, "settings.eu"));
                    J(a).C("oo") || l && hi(a, m) && l.start();
                    return f
                })
            }

            function to(a, c, b, d) {
                var e = a.document,
                    f = [],
                    g = fa(a),
                    h = ":submit" + Math.random(),
                    k = [],
                    l = H(c.flush, c),
                    m = sa(function(r, t) {
                        E(a, "hfv." + r, function() {
                            try {
                                var y = t.type
                            } catch (F) {
                                return
                            }
                            y = I(y, d);
                            c.push(t, {
                                type: r
                            });
                            y && l()
                        })()
                    }),
                    p = E(a, "sfv", function() {
                        var r =
                            b(a),
                            t = uo(a);
                        x(function(y) {
                            f.push(g.F(y.target, [y.event], m(y.type)))
                        }, r);
                        x(function(y) {
                            f.push(g.F(y.target, [y.event], E(a, "hff." + y.type + "." + y.event, function(F) {
                                x(Ga({
                                    l: a,
                                    qa: F,
                                    flush: l
                                }), y.O)
                            })))
                        }, t);
                        k = ii(a, "form", e);
                        e.attachEvent && (r = ii(a, "form *", e), x(function(y) {
                            f.push(g.F(y, ["submit"], m("form")))
                        }, k), x(function(y) {
                            Nf(y) && f.push(g.F(y, ["change"], m("formInput")))
                        }, r));
                        x(function(y) {
                            var F = y.submit;
                            if (O(F) || "object" === typeof F && vo.test("" + F)) y[h] = F, y.submit = E(a, "fv", function() {
                                var P = {
                                    target: y,
                                    type: "submit"
                                };
                                m("document")(P);
                                return y[h]()
                            })
                        }, k)
                    }),
                    q = E(a, "ufv", function() {
                        x(ma, f);
                        x(function(r) {
                            r && (r.submit = r[h])
                        }, k);
                        c.flush()
                    });
                return {
                    start: p,
                    stop: q
                }
            }

            function wo(a, c) {
                var b = ha(function(e) {
                        return 0 < e.O.length
                    }, c),
                    d = ji({
                        target: a.document,
                        type: "document"
                    });
                return A(w(Q, d, xo(a)), b)
            }

            function ki(a, c) {
                var b = a.l,
                    d = [],
                    e = c.form;
                if (!c[Ya] && e) {
                    var f = e.elements;
                    e = e.length;
                    for (var g = 0; g < e; g += 1) {
                        var h = f[g];
                        xe(h) && !h[Ya] && ra(d, zc(b, h))
                    }
                } else ra(d, zc(b, c));
                return d
            }

            function Of(a) {
                if (wd) {
                    wd = !1;
                    var c = Cb(a.l),
                        b = [];
                    kb(a.l, b,
                        15) ? a = [] : (V(b, c), a = b);
                    return a
                }
            }

            function li(a) {
                if (!wd) {
                    wd = !0;
                    a = Cb(a.l);
                    var c = [];
                    Vb(c, 14);
                    V(c, a);
                    return c
                }
            }

            function yo(a, c, b) {
                var d = c[Ya];
                if (d) {
                    a: {
                        var e = Cb(a),
                            f = c[Ya];
                        if (0 < f) {
                            var g = [];
                            c = Pf(a, c);
                            var h = Ac[f],
                                k = c[0] + "x" + c[1],
                                l = c[2] + "x" + c[3];
                            if (k !== h.yf) {
                                h.yf = k;
                                if (kb(a, g, 9)) {
                                    a = [];
                                    break a
                                }
                                V(g, e);
                                V(g, f);
                                V(g, c[0]);
                                V(g, c[1])
                            }
                            if (l !== h.size) {
                                h.size = l;
                                if (kb(a, g, 10)) {
                                    a = [];
                                    break a
                                }
                                V(g, e);
                                V(g, f);
                                V(g, c[2]);
                                V(g, c[3])
                            }
                            if (g.length) {
                                a = g;
                                break a
                            }
                        }
                        a = []
                    }
                    ra(b, a)
                }
                return d
            }

            function Uc(a, c, b) {
                void 0 === b && (b = !1);
                if (!c) return {
                    Va: !1,
                    hb: !1,
                    qb: !1
                };
                var d = c.getAttribute("type") || c.type;
                if ("button" === d) return {
                    Va: !1,
                    hb: !1,
                    qb: !1
                };
                var e = ha(mi, [c.className, c.id, c.name]),
                    f = c && ic("ym-record-keys", c);
                d = d && I(d, ni) || $a(gb(zo), e);
                var g;
                (g = d) || (g = c.placeholder, g = $a(gb(Ao), e) || mi(g) && Bo.test(g || ""));
                e = g;
                return {
                    Va: !f && (Qf(a, c) || e && b || e && !d && !b),
                    hb: f,
                    qb: e
                }
            }

            function Qf(a, c) {
                return Lf(a, c) || xd(a, c) ? !0 : vd(a, c)
            }

            function mi(a) {
                return !!(a && 2 < a.length)
            }

            function Kf(a) {
                try {
                    var c = Ma(a);
                    if (I(c, Rf)) {
                        if ("INPUT" === c) {
                            var b = a.type;
                            return !b || I(b.toLocaleLowerCase(),
                                Co)
                        }
                        return !0
                    }
                } catch (d) {}
                return !1
            }

            function oi(a, c) {
                return c && ic("(ym-disable-submit|-metrika-noform)", c)
            }

            function Do(a, c) {
                return G("", A(function(b) {
                    return a.isNaN(b) ? Eo.test(b) ? (b = b.toUpperCase() === b ? Fo : Go, String.fromCharCode(Xa(a, b[0], b[1]))) : b : "" + Xa(a, 0, 9)
                }, c.split("")))
            }

            function vd(a, c) {
                if (ca(c)) return !1;
                if (Sf(c)) {
                    var b = c.parentNode;
                    return (ca(b) ? 0 : 11 === b.nodeType) ? !1 : vd(a, c.parentNode)
                }
                b = pi(a);
                if (!b) return !1;
                var d = b.call(c, ".ym-hide-content,.ym-hide-content *");
                return d && b.call(c, ".ym-show-content,.ym-hide-content .ym-show-content *") ?
                    !1 : d
            }

            function hi(a, c) {
                var b = Vc(a),
                    d = b.C("visorc");
                I(d, ["w", "b"]) || (d = "");
                qi(a) && ri(a, ye, "visorc") && !Ho.test(lb(a) || "") || (d = "b");
                var e = n(c, "settings.webvisor.recp");
                if (!a.isFinite(e) || 0 > e || 1 < e) d = "w";
                d || (d = J(a).C("hitId") % 1E4 / 1E4 < e ? "w" : "b");
                b.D("visorc", d, 30);
                return "w" === d
            }

            function Io(a, c) {
                return {
                    N: function(b, d) {
                        b.K.Wb("we", Ob(c.zb));
                        si(a, c, b, "rn");
                        d()
                    }
                }
            }

            function ti(a, c, b) {
                if (ui.isEnabled(a)) return new ui(a, c);
                if (vi.isEnabled(a)) return new vi(a, b)
            }

            function wi(a, c) {
                var b = c[1][3],
                    d = 0,
                    e = new a.Uint8Array(c[0]);
                return ec([b], function(f, g) {
                    if (!f) return e;
                    f[0](a, f[2], e, d);
                    d += f[1];
                    g.push(f[3]);
                    return e
                })
            }

            function xi(a, c, b) {
                a = c(b);
                c = [D, 0, 0];
                var d = [0, c, c, void 0];
                return ec(a, function(e, f) {
                    var g = e[0],
                        h = e[1],
                        k = e[2];
                    if (0 === g) return k(d, h), d;
                    if (void 0 === h || null === h) return d;
                    var l = g >> 3;
                    if (g & 1) Bc(d, Y(l)), h = k(h), l & 2 && Bc(d, Y(h[1])), Bc(d, h);
                    else if (g & 4)
                        for (g = h.length - 1; 0 <= g;) {
                            var m = k(h[g]);
                            m.push([0, 0, Tf]);
                            m.push([0, Y(l), Bc]);
                            m.unshift([0, 0, Uf]);
                            ra(f, m);
                            --g
                        } else if (g & 2) {
                            k = e[2];
                            var p = e[3],
                                q = e[4],
                                r = e[5],
                                t = da(h);
                            for (g = t.length -
                                1; 0 <= g;) m = t[g], m = [
                                [0, 0, Uf],
                                [q, h[m], r],
                                [k, m, p],
                                [0, 0, Tf],
                                [0, Y(l), Bc]
                            ], ra(f, m), --g
                        } else m = k(h), m.push([0, 0, Tf]), m.push([0, Y(l), Bc]), m.unshift([0, 0, Uf]), ra(f, m);
                    return d
                })
            }

            function Uf(a) {
                var c = a[1],
                    b = a[0],
                    d = a[2];
                a[3] ? (a[0] = a[3][0], a[1] = a[3][1], a[2] = a[3][2], a[3] = a[3][3]) : (a[0] = 0, a[1] = [D, 0, 0], a[2] = a[1]);
                Bc(a, Y(b));
                b && (a[2][3] = c[3], a[2] = d, a[0] += b)
            }

            function Tf(a) {
                a[3] = [a[0], a[1], a[2], a[3]];
                a[1] = [D, 0, 0];
                a[2] = a[1];
                a[0] = 0
            }

            function Bc(a, c) {
                a[0] += c[1];
                a[2][3] = c;
                a[2] = c
            }

            function yi(a) {
                return [
                    [1857, a.partsTotal,
                        Y
                    ],
                    [1793, a.activity, Y],
                    [1744, a.textChangeMutation, Jo],
                    [1680, a.removedNodesMutation, Ko],
                    [1616, a.addedNodesMutation, Lo],
                    [1552, a.attributesChangeMutation, Mo],
                    [1488, a.publishersHeader, No],
                    [1424, a.articleInfo, Oo],
                    [1360, a.focusEvent, Po],
                    [1296, a.fatalErrorEvent, Qo],
                    [1232, a.deviceRotationEvent, Ro],
                    [1168, a.keystrokesEvent, So],
                    [1104, a.resizeEvent, To],
                    [1040, a.zoomEvent, Uo],
                    [976, a.touchEvent, Vo],
                    [912, a.changeEvent, Wo],
                    [848, a.selectionEvent, Xo],
                    [784, a.scrollEvent, Yo],
                    [720, a.mouseEvent, Zo],
                    [656, a.Ij, $o],
                    [592, a.page,
                        ap
                    ],
                    [513, a.end, Cc],
                    [449, a.partNum, Y],
                    [401, a.chunk, bp],
                    [257, a.frameId, ta],
                    [193, a.event, Y],
                    [129, a.type, Y],
                    [65, a.stamp, Y]
                ]
            }

            function cp(a) {
                return [
                    [84, a.Ai, yi]
                ]
            }

            function dp(a) {
                return [
                    [129, a.position, ta],
                    [81, a.name, ea]
                ]
            }

            function ep(a) {
                return [
                    [81, a.name, ea]
                ]
            }

            function fp(a) {
                return [
                    [81, a.name, ea]
                ]
            }

            function Oo(a) {
                return [
                    [593, a.updateDate, ea],
                    [532, a.rubric, dp],
                    [449, a.chars, ta],
                    [401, a.publicationDate, ea],
                    [340, a.topics, ep],
                    [276, a.authors, fp],
                    [209, a.pageTitle, ea],
                    [145, a.pageUrlCanonical, ea],
                    [65, a.id, Y]
                ]
            }

            function gp(a) {
                return [
                    [513,
                        a.chars, ta
                    ],
                    [489, a.maxScrolled, yd],
                    [385, a.involvedTime, ta],
                    [321, a.height, ta],
                    [257, a.width, ta],
                    [193, a.y, ta],
                    [129, a.x, ta],
                    [65, a.id, Y]
                ]
            }

            function No(a) {
                return [
                    [129, a.involvedTime, ta],
                    [84, a.articleMeta, gp]
                ]
            }

            function Po(a) {
                return [
                    [65, a.target, ta]
                ]
            }

            function Qo(a) {
                return [
                    [209, a.stack, ea],
                    [145, a.Yg, ea],
                    [81, a.code, ea]
                ]
            }

            function Ro(a) {
                return [
                    [193, a.orientation, ta],
                    [129, a.height, Y],
                    [65, a.width, Y]
                ]
            }

            function So(a) {
                return [
                    [84, a.keystrokes, hp]
                ]
            }

            function hp(a) {
                return [
                    [273, a.modifier, ea],
                    [193, a.isMeta, Cc],
                    [145, a.key,
                        ea
                    ],
                    [65, a.id, Y]
                ]
            }

            function To(a) {
                return [
                    [257, a.pageHeight, Y],
                    [193, a.pageWidth, Y],
                    [129, a.height, Y],
                    [65, a.width, Y]
                ]
            }

            function Uo(a) {
                return [
                    [193, a.y, ta],
                    [129, a.x, ta],
                    [105, a.level, yd]
                ]
            }

            function Vo(a) {
                return [
                    [129, a.target, ta],
                    [84, a.touches, ip]
                ]
            }

            function ip(a) {
                return [
                    [297, a.force, yd],
                    [233, a.y, yd],
                    [169, a.x, yd],
                    [81, a.id, ea]
                ]
            }

            function Wo(a) {
                return [
                    [257, a.target, ta],
                    [193, a.hidden, Cc],
                    [129, a.checked, Cc],
                    [81, a.value, ea]
                ]
            }

            function Xo(a) {
                return [
                    [257, a.endNode, Y],
                    [193, a.startNode, Y],
                    [129, a.end, ta],
                    [65, a.start, ta]
                ]
            }

            function Yo(a) {
                return [
                    [257, a.target, ta],
                    [193, a.page, Cc],
                    [129, a.y, ta],
                    [65, a.x, ta]
                ]
            }

            function Zo(a) {
                return [
                    [193, a.target, ta],
                    [129, a.y, Y],
                    [65, a.x, Y]
                ]
            }

            function $o(a) {
                return [
                    [148, a.changes, jp],
                    [65, a.target, ta]
                ]
            }

            function jp(a) {
                return [
                    [193, a.index, Y],
                    [145, a.op, ea],
                    [81, a.style, ea]
                ]
            }

            function Jo(a) {
                return [
                    [209, a.value, ea],
                    [129, a.index, Y],
                    [65, a.target, Y]
                ]
            }

            function Ko(a) {
                return [
                    [129, a.index, Y],
                    [69, a.nodes, ta]
                ]
            }

            function Lo(a) {
                return [
                    [129, a.index, Y],
                    [84, a.nodes, zi]
                ]
            }

            function Mo(a) {
                return [
                    [210, a.attributes, 81, ea,
                        145, ea
                    ],
                    [129, a.index, Y],
                    [65, a.target, Y]
                ]
            }

            function ap(a) {
                return [
                    [852, a.content, zi],
                    [785, a.tabId, ea],
                    [705, a.recordStamp, kp],
                    [656, a.location, lp],
                    [592, a.viewport, Ai],
                    [528, a.screen, Ai],
                    [449, a.hasBase, Cc],
                    [401, a.base, ea],
                    [337, a.referrer, ea],
                    [273, a.ua, ea],
                    [209, a.address, ea],
                    [145, a.title, ea],
                    [81, a.doctype, ea]
                ]
            }

            function lp(a) {
                return [
                    [209, a.path, ea],
                    [145, a.protocol, ea],
                    [81, a.host, ea]
                ]
            }

            function Ai(a) {
                return [
                    [129, a.height, ta],
                    [65, a.width, ta]
                ]
            }

            function zi(a) {
                return [
                    [513, a.hidden, Cc],
                    [449, a.prev, Y],
                    [385, a.next,
                        Y
                    ],
                    [337, a.content, ea],
                    [257, a.parent, Y],
                    [210, a.attributes, 81, ea, 145, ea],
                    [145, a.name, ea],
                    [65, a.id, Y]
                ]
            }

            function ea(a) {
                var c = mp({}, a, [], 0);
                return c ? [np, c, a] : [Bi, 0, 0]
            }

            function bp(a) {
                return [op, a.length, a]
            }

            function Cc(a) {
                return [Bi, 1, a ? 1 : 0]
            }

            function kp(a) {
                a = Ci(a);
                var c = a[0],
                    b = a[1],
                    d = (b >>> 28 | c << 4) >>> 0;
                c >>>= 24;
                return [Di, 0 === c ? 0 === d ? 16384 > b ? 128 > b ? 1 : 2 : 2097152 > b ? 3 : 4 : 16384 > d ? 128 > d ? 5 : 6 : 2097152 > d ? 7 : 8 : 128 > c ? 9 : 10, a]
            }

            function yd(a) {
                return [pp, 4, a]
            }

            function ta(a) {
                return 0 > a ? [Di, 10, Ci(a)] : Y(a)
            }

            function Y(a) {
                return [qp,
                    128 > a ? 1 : 16384 > a ? 2 : 2097152 > a ? 3 : 268435456 > a ? 4 : 5, a
                ]
            }

            function qp(a, c, b, d) {
                for (a = c; 127 < a;) b[d++] = a & 127 | 128, a >>>= 7;
                b[d] = a
            }

            function Bi(a, c, b, d) {
                b[d] = c
            }

            function op(a, c, b, d) {
                for (a = 0; a < c.length; ++a) b[d + a] = c[a]
            }

            function Ei(a) {
                return function(c, b, d, e) {
                    for (var f, g = 0, h = 0; h < b.length; ++h)
                        if (c = b.charCodeAt(h), 128 > c) a ? g += 1 : d[e++] = c;
                        else {
                            if (2048 > c) {
                                if (a) {
                                    g += 2;
                                    continue
                                }
                                d[e++] = c >> 6 | 192
                            } else {
                                if (55296 === (c & 64512) && 56320 === ((f = b.charCodeAt(h + 1)) & 64512)) {
                                    if (a) {
                                        g += 4;
                                        continue
                                    }
                                    c = 65536 + ((c & 1023) << 10) + (f & 1023);
                                    ++h;
                                    d[e++] = c >> 18 |
                                        240;
                                    d[e++] = c >> 12 & 63 | 128
                                } else {
                                    if (a) {
                                        g += 3;
                                        continue
                                    }
                                    d[e++] = c >> 12 | 224
                                }
                                d[e++] = c >> 6 & 63 | 128
                            }
                            d[e++] = c & 63 | 128
                        }
                    return a ? g : e
                }
            }

            function pp(a, c, b, d) {
                return rp(a)(a, c, b, d)
            }

            function sp(a, c, b, d) {
                var e = 0 > c ? 1 : 0;
                e && (c = -c);
                if (0 === c) zd(0 < 1 / c ? 0 : 2147483648, b, d);
                else if (a.isNaN(c)) zd(2143289344, b, d);
                else if (3.4028234663852886E38 < c) zd((e << 31 | 2139095040) >>> 0, b, d);
                else if (1.1754943508222875E-38 > c) zd((e << 31 | a.Math.round(c / 1.401298464324817E-45)) >>> 0, b, d);
                else {
                    var f = a.Math.floor(a.Math.log(c) / Math.LN2);
                    zd((e << 31 | f + 127 << 23 | Math.round(c *
                        a.Math.pow(2, -f) * 8388608) & 8388607) >>> 0, b, d)
                }
            }

            function zd(a, c, b) {
                c[b] = a & 255;
                c[b + 1] = a >>> 8 & 255;
                c[b + 2] = a >>> 16 & 255;
                c[b + 3] = a >>> 24
            }

            function Di(a, c, b, d) {
                a = c[0];
                for (c = c[1]; a;) b[d++] = c & 127 | 128, c = (c >>> 7 | a << 25) >>> 0, a >>>= 7;
                for (; 127 < c;) b[d++] = c & 127 | 128, c >>>= 7;
                b[d++] = c
            }

            function Ci(a) {
                if (!a) return [0, 0];
                var c = 0 > a;
                c && (a = -a);
                var b = a >>> 0;
                a = (a - b) / 4294967296 >>> 0;
                c && (a = ~a >>> 0, b = ~b >>> 0, 4294967295 < ++b && (b = 0, 4294967295 < ++a && (a = 0)));
                return [a, b]
            }

            function si(a, c, b, d) {
                var e, f = b.J;
                f.wmode = "0";
                f["wv-hit"] = f["wv-hit"] || "" + Dc(a);
                f["page-url"] = f["page-url"] || S(a).href;
                d && (f[d] = f[d] || "" + Xa(a));
                a = {
                    na: {
                        Ba: "webvisor/" + c.id
                    },
                    ba: z(b.ba || {}, {
                        Za: (e = {}, e["Content-Type"] = "text/plain", e),
                        $c: "POST"
                    }),
                    J: f
                };
                z(b, a)
            }

            function tp(a, c) {
                return pa(c, function(b) {
                    var d = J(a),
                        e = d.C,
                        f = u("dSync", d.D);
                    L(c);
                    if (e("dSync", !1)) f(1);
                    else return f(!0), Fi(a, b, {
                        cb: c,
                        Rb: "s",
                        Rd: "ds",
                        Wc: f,
                        Li: function(g, h, k) {
                            var l = g.Rc;
                            g = g.host;
                            if (n(l, "settings")) return Va(Ta("ds.e"));
                            h = h(Z) - k;
                            k = g[1];
                            var m, p;
                            l = Ja((m = {}, m.di = l, m.dit = h, m.dip = k, m));
                            m = (p = {}, p["page-url"] = S(a).href,
                                p);
                            return va(a, "S", Gi)({
                                K: l,
                                J: m
                            }, Gi).then(u(10, f), E(a, "ds.rs"))
                        }
                    })
                })
            }

            function Fi(a, c, b) {
                var d, e = b.cb,
                    f = b.Wc;
                f = void 0 === f ? D : f;
                var g = ja(a),
                    h = up(a, c.userData, e),
                    k = vp(a),
                    l = w(Hi, C([wp, xp], Ad))(a),
                    m = n(c, "settings.sbp");
                b.Wc = f;
                m && (b.data = z({}, m, (d = {}, d.c = e.id, d)));
                return k.length ? yp(a, g, h, c, l, b).then(function() {
                    return zp(a, k, h, g, l, b)
                }, D) : (f(2), K.resolve())
            }

            function vp(a) {
                var c = Bd(a);
                a = w(Vf, vc(["iPhone", "iPad"]))(a);
                return c ? Ap : a ? Bp : []
            }

            function zp(a, c, b, d, e, f) {
                e = f.Li;
                var g = void 0 === e ? D : e,
                    h = f.Rd;
                e = f.Wc;
                var k =
                    void 0 === e ? D : e,
                    l = d(Z);
                return Cp(a, c, f)(Ra(function(m) {
                    k(6);
                    x(function(p) {
                        p && Cd(a, h + ".s", p)
                    }, m);
                    m = d(rb);
                    b.D(h, m).then(u(7, k))
                }, function(m) {
                    k(8);
                    b.D(h, d(rb)).then(u(9, k));
                    g(m, d, l)
                }))
            }

            function yp(a, c, b, d, e, f) {
                var g = f.Rd,
                    h = f.cb,
                    k = f.Wc;
                return new K(function(l, m) {
                    var p = b.C(g, 0);
                    p = parseInt("" + p, 10);
                    return c(rb) - p <= e.ag ? (k(3), m()) : Dp(a) ? l(void 0) : zf(d) ? (k(4), m()) : l(Ep(a, h)["catch"](w(Sc(u(5, k)), Va)))
                })
            }

            function Cp(a, c, b) {
                var d = b.Rb,
                    e = b.data,
                    f = va(a, d, b.cb);
                a = z({}, Ii);
                e && z(a.J, e);
                return Fp(A(function(g) {
                    return Gp(f(z({
                        ba: {
                            Ie: !1,
                            le: !0
                        }
                    }, Ii), A(function(h) {
                        var k = h[1],
                            l = h[2];
                        h = G("", A(function(m) {
                            return String.fromCharCode(m.charCodeAt(0) + 10)
                        }, h[0].split("")));
                        return "http" + (l ? "s" : "") + "://" + h + ":" + k + "/" + Hp[d]
                    }, g)).then(function(h) {
                        return z({}, h, {
                            host: g[h.ig]
                        })
                    }))
                }, c))
            }

            function up(a, c, b) {
                var d = c || {},
                    e = va(a, "u", b),
                    f = Oa(a);
                return {
                    C: function(g, h) {
                        return X(d[g]) ? f.C(g, h) : d[g]
                    },
                    D: function(g, h) {
                        var k, l = "" + h;
                        d[g] = l;
                        f.D(g, l);
                        return e({
                            J: (k = {}, k.key = g, k.value = l, k)
                        }, [Fa.Sa + "//" + jc + "/user_storage_set"], {})["catch"](E(a, "u.d.s.s"))
                    }
                }
            }

            function Ip(a) {
                return {
                    N: function(c,
                        b) {
                        J(a).C("oo") || b()
                    }
                }
            }

            function Jp(a, c) {
                try {
                    var b = c[0];
                    var d = b[1]
                } catch (e) {
                    return function() {
                        return K.resolve()
                    }
                }
                return function(e) {
                    var f, g = (f = {}, f["browser-info"] = Kp, f["page-url"] = a.location && "" + a.location.href, f);
                    return d && (e = Ab(a, e)) ? d(Lp, {
                        $a: g,
                        ha: [],
                        da: "site-info=" + ue(e)
                    })["catch"](D) : K.resolve()
                }
            }

            function Mp(a, c) {
                var b = ze(function(d, e) {
                    return d[1].ea > e[1].ea ? 1 : -1
                }, La(ge));
                b = A(function(d) {
                    var e = d[0],
                        f = d[1].Pa;
                    d = Lb(c, e) && !ca(c[e]);
                    e = c[e] !== (f || Q)(void 0);
                    return tb(d && e)
                }, b);
                return Ae(G("", b))
            }

            function Np(a, c) {
                if (n(a, "disableYaCounter" + c.id) || n(a, "Ya.disableMetrica")) {
                    var b = L(c);
                    delete J(a).C("counters", {})[b];
                    Va(Ta("oo.e"))
                }
            }

            function Op(a) {
                if (Dd(a)) return null;
                var c = Pp(a),
                    b = c.Bf;
                X(b) && (c.Bf = null, Qp(a).then(function(d) {
                    c.Bf = d
                }));
                return b ? 1 : null
            }

            function Rp(a, c, b) {
                b = b.J;
                if ((void 0 === b ? {} : b).nohit) return null;
                a = Ed(a);
                if (!a) return null;
                var d = b = null;
                n(a, "getEntriesByType") && (d = n(a.getEntriesByType("navigation"), "0")) && (b = Sp);
                if (!b) {
                    var e = n(a, "timing");
                    e && (b = Tp, d = e)
                }
                if (!b) return null;
                a = Up(a,
                    d, b);
                c = L(c);
                c = Vp(c);
                return (c = Wp(c, a)) && G(",", c)
            }

            function Wp(a, c) {
                var b = a.length ? A(function(d, e) {
                    var f = c[e];
                    return f === d ? null : f
                }, a) : c;
                a.length = 0;
                x(w(Q, Ea("push", a)), c);
                return ha(Aa(null), b).length === a.length ? null : b
            }

            function Up(a, c, b) {
                return A(function(d) {
                    var e = d[0],
                        f = d[1];
                    if (O(e)) return e(a, c) || null;
                    if (1 === d.length) return c[e] ? Math.round(c[e]) : null;
                    var g;
                    !(g = c[e] && c[f]) && (g = 0 === c[e] && 0 === c[f]) && (g = d[1], g = !(Ji[d[0]] || Ji[g]));
                    if (!g) return null;
                    d = Math.round(c[e]) - Math.round(c[f]);
                    return 0 > d || 36E5 < d ? null :
                        d
                }, b)
            }

            function Be(a, c) {
                try {
                    var b = c.localStorage.getItem(a);
                    return b && md(le(b))
                } catch (d) {}
                return null
            }

            function le(a) {
                for (var c = [], b = 0; b < a.length; b++) {
                    var d = a.charCodeAt(b);
                    128 > d ? c.push(d) : (127 < d && 2048 > d ? c.push(d >> 6 | 192) : (c.push(d >> 12 | 224), c.push(d >> 6 & 63 | 128)), c.push(d & 63 | 128))
                }
                return c
            }

            function md(a, c) {
                void 0 === c && (c = !1);
                for (var b = a.length, d = b - b % 3, e = [], f = 0; f < d; f += 3) {
                    var g = (a[f] << 16) + (a[f + 1] << 8) + a[f + 2];
                    e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 18 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >>
                        12 & 63
                    ], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g & 63])
                }
                switch (b - d) {
                    case 1:
                        b = a[d] << 4;
                        e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b & 63], "=", "=");
                        break;
                    case 2:
                        b = (a[d] << 10) + (a[d + 1] << 2), e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b >> 12 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b >>
                            6 & 63
                        ], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b & 63], "=")
                }
                e = G("", e);
                return c ? Ki(e, !0) : e
            }

            function Qh(a, c) {
                void 0 === c && (c = !1);
                var b = a,
                    d = "",
                    e = 0;
                if (!b) return "";
                for (c && (b = Ki(b)); b.length % 4;) b += "=";
                do {
                    var f = kc("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", b.charAt(e++)),
                        g = kc("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", b.charAt(e++)),
                        h = kc("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", b.charAt(e++)),
                        k = kc("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                            b.charAt(e++));
                    if (0 > f || 0 > g || 0 > h || 0 > k) return "";
                    var l = f << 18 | g << 12 | h << 6 | k;
                    f = l >> 16 & 255;
                    g = l >> 8 & 255;
                    l &= 255;
                    d = 64 === h ? d + String.fromCharCode(f) : 64 === k ? d + String.fromCharCode(f, g) : d + String.fromCharCode(f, g, l)
                } while (e < b.length);
                return d
            }

            function Ki(a, c) {
                void 0 === c && (c = !1);
                return a ? a.replace(c ? /[+/=]/g : /[-*_]/g, function(b) {
                    return Xp[b] || b
                }) : ""
            }

            function Yp(a) {
                try {
                    var c = Sa(a) ? a : [];
                    return G(",", [a.name, a.description, w(Ba, ua, Wb(Zp), Ce(","))(c)])
                } catch (b) {
                    return ""
                }
            }

            function Zp(a) {
                return G(",", [a.description, a.suffixes,
                    a.type
                ])
            }

            function $p(a, c) {
                for (var b = "", d = 0; d < c; d += 1) b += a;
                return b
            }

            function aq(a, c, b, d, e, f, g, h) {
                var k = b.C(f);
                ca(k) && (b.D(f, g), e(a, c, b, d), k = b.C(f, g));
                X(h) || h.Wb(f, "" + k);
                return k
            }

            function bq(a, c) {
                if (Fd(a)) {
                    var b = lb(a).match(cq);
                    if (b && b.length) return b[1] === c
                }
                return !1
            }

            function De(a, c, b) {
                return function(d) {
                    var e, f, g = za(c, b);
                    g && dq(a, d, c) && (g = H(g.params, g), (d = Wf({
                        event: a,
                        La: "products",
                        xa: lc,
                        Dh: "goods"
                    }, d)) && g && g((e = {}, e.__ym = (f = {}, f.ecommerce = [d], f), e)))
                }
            }

            function dq(a, c, b) {
                var d = !1,
                    e = "";
                if (!ka(c)) return Kb(b,
                    "", "ecomeo"), d;
                var f = c.goods;
                switch (a) {
                    case "detail":
                    case "add":
                    case "remove":
                        R(f) && f.length ? (d = Li(function(g) {
                            return ka(g) && (ia(g.id) || mc(b, g.id) || ia(g.name))
                        }, f)) || (e = "ecomgi") : e = "ecomgei";
                        break;
                    case "purchase":
                        mc(b, c.id) || ia(c.id) ? d = !0 : e = "ecompi"
                }
                Kb(b, "", e);
                return d
            }

            function Gd(a, c) {
                return {
                    N: function(b, d) {
                        Xf(b) ? d() : pa(c, function(e) {
                            var f;
                            if (e = n(e, "settings.hittoken")) e = (f = {}, f.hittoken = e, f), b.J = z(b.J || {}, e);
                            d()
                        })
                    }
                }
            }

            function eq(a, c) {
                function b() {
                    q.hidden ? z(k.style, Hd(["top", "right", "left", "background"],
                        "initial")) : z(k.style, Hd(["top", "right", "left"], "0"), {
                        background: "rgba(0, 0, 0, .3)"
                    });
                    y.parentNode || (r.appendChild(p), r.appendChild(y));
                    q.hidden = !q.hidden;
                    r.hidden = !r.hidden;
                    t.hidden = !t.hidden
                }

                function d(M) {
                    var na = g();
                    z(na.style, Ec("2px", "18px"), Wc, {
                        left: "15px",
                        top: "7px",
                        background: "#2f3747",
                        borderRadius: "2px"
                    });
                    na.style.transform = "rotate(" + M + "deg)";
                    return na
                }

                function e(M, na, wa, Db, Id) {
                    var Ee = g();
                    z(Ee.style, Ec(na + "px", wa + "px"), Wc, {
                        left: M + "px",
                        bottom: 0,
                        background: Db,
                        borderTopLeftRadius: Id
                    });
                    return Ee
                }
                var f = fb(a);
                if (!f) return D;
                var g = u("div", f),
                    h = u("iframe", f),
                    k = g();
                k.classList.add("__ym_wv_ign");
                z(k.style, Mi, {
                    bottom: "0",
                    width: "100%",
                    maxWidth: "initial",
                    zIndex: "999999999"
                });
                var l = k.attachShadow ? k.attachShadow({
                        mode: "open"
                    }) : k,
                    m = g();
                z(m.style, Ec("24px"), Wc, Yf, {
                    top: "12px",
                    right: "10px",
                    background: "#3367dc",
                    overflow: "hidden"
                });
                var p = g();
                z(p.style, {
                        border: "2px solid transparent",
                        animation: "__ym_wv_ign-spinner-animation 1s 0.21s infinite linear"
                    }, Yf, Wc, Ec("48px"), Hd(["top", "left"], "calc(50% - 24px)"),
                    Hd(["borderTopColor", "borderLeftColor"], "#fc0"));
                f = f("style");
                f.textContent = "@keyframes __ym_wv_ign-spinner-animation {to {transform: rotate(360deg);}}";
                p.appendChild(f);
                var q = g();
                q.id = "__ym_wv_ign__opener";
                z(q.style, Ec("46px", "48px"), Mi, {
                    right: "0",
                    bottom: "60px",
                    cursor: "pointer",
                    background: "#fff",
                    borderRadius: "16px 0 0 16px",
                    boxShadow: "0px 0px 1px rgba(67, 68, 69, 0.3), 0px 1px 2px rgba(67, 68, 69, 0.3)"
                });
                var r = g();
                z(r.style, Wc, Hd(["top", "right", "bottom"], "0"), {
                    width: "600px",
                    background: "#fff"
                });
                var t = g();
                t.id = "__ym_wv_ign__closer";
                z(t.style, Ec("32px"), Wc, Yf, {
                    top: "12px",
                    right: "612px",
                    cursor: "pointer",
                    background: "#fff"
                });
                f = h();
                f.src = "https://metrika.yandex.ru/widget/iframe-check";
                var y = h();
                z(y.style, Ec("100%"), {
                    border: "none"
                });
                y.src = "https://metrika.yandex.ru/widget/dashboard?id=" + c;
                r.hidden = !0;
                t.hidden = !0;
                t.appendChild(d(45));
                t.appendChild(d(-45));
                r.appendChild(f);
                m.appendChild(e(0, 8, 9, "linear-gradient(0deg, #ff324f, #ff324f), linear-gradient(158.67deg, #ff455c 12.6%, #ff1139 96.76%)"));
                m.appendChild(e(8, 9, 16, "#04acff", "3px"));
                m.appendChild(e(17, 7, 24, "#ffdd13"));
                q.appendChild(m);
                l.appendChild(r);
                l.appendChild(t);
                var F = ["click", "touchstart"];
                h = fa(a);
                m = a.document.body;
                l = [h.F(q, F, b), h.F(t, F, b), h.F(f, ["load"], C([ma, [H(r.removeChild, r, f), H(l.appendChild, l, q)]], x)), h.F(y, ["load"], H(r.removeChild, r, p)), H(m.removeChild, m, k)];
                var P = C([ma, l], x);
                l.push(h.F(a, ["securitypolicyviolation"], function(M) {
                    (M = n(M, "blockedURI")) && 0 <= ib(M, "https://metrika.yandex.ru") && P()
                }));
                m.appendChild(k);
                return P
            }

            function Hd(a, c) {
                return N(function(b, d) {
                    b[d] = c;
                    return b
                }, {}, a)
            }

            function Ec(a, c) {
                var b;
                return b = {}, b.width = a, b.height = c || a, b
            }

            function fq(a, c) {
                var b = n(c, "origin"),
                    d;
                if (d = b) d = gq.test(b) || hq.test(b);
                d && (b = qb(a, c.data), "appendremote" === n(b, "action") && iq(a, c, b))
            }

            function Ni(a, c, b, d) {
                var e, f, g, h;
                void 0 === b && (b = "");
                void 0 === d && (d = "");
                var k = J(a),
                    l = {};
                l.getCachedTags = Fe;
                l.form = (e = {}, e.closest = u(a, Oi), e.select = jq, e.getData = u(a, Pi), e);
                l.button = (f = {}, f.closest = u(a, je), f.select = Zf, f.getData = u(a, ke), f);
                l.phone =
                    (g = {}, g.hidePhones = C([a, null, [d]], Qi), g);
                l.status = (h = {}, h.checkStatus = C([a, Ha(b)], kq), h);
                k.D("_u", l);
                c && uc(a, {
                    src: c
                })
            }

            function Ri(a) {
                var c = a.lang;
                c = void 0 === c ? "" : c;
                var b = a.appVersion;
                b = void 0 === b ? "" : b;
                var d = a.fileId;
                d = void 0 === d ? "" : d;
                a = a.beta;
                a = void 0 === a ? !1 : a;
                b = G(".", ua(A(w(Q, Ha), b.split("."))));
                if (!I(d, lq) || !I(c, ["ru", "en", "tr"])) return "";
                c = (a ? "https://s3.mds.yandex.net/internal-metrika-betas" : "https://yastatic.net/s3/metrika") + (b ? "/" + b : "") + "/form-selector/" + (d + "_" + c + ".js");
                return Si(c) ? c : ""
            }

            function mq(a,
                c) {
                var b = fb(a);
                if (b) {
                    var d = b("div"),
                        e = fc(a);
                    if (e) {
                        d.innerHTML = '<iframe name="RemoteIframe" allowtransparency="true" style="position: absolute; left: -999px; top: -999px; width: 1px; height: 1px;"></iframe>';
                        var f = d.firstChild;
                        f.onload = function() {
                            var h = b("meta");
                            h.setAttribute("http-equiv", "Content-Security-Policy");
                            h.setAttribute("content", "script-src *");
                            f.contentWindow.document.head.appendChild(h);
                            uc(f.contentWindow, {
                                src: c
                            })
                        };
                        a._ym__remoteIframeEl = f;
                        e.appendChild(d);
                        d.removeChild(f);
                        var g = null;
                        d.attachShadow ? g = d.attachShadow({
                            mode: "open"
                        }) : d.createShadowRoot ? g = d.createShadowRoot() : d.webkitCreateShadowRoot && (g = d.webkitCreateShadowRoot());
                        g ? g.appendChild(f) : (e.appendChild(f), a._ym__remoteIframeContainer = f)
                    }
                }
            }

            function kq(a) {
                var c, b = Ti(a);
                a = J(a).C("getCounters", Jd)();
                a = A(T("id"), a);
                return c = {
                    id: b
                }, c.counterFound = !!b && I(b, a), c
            }

            function Qi(a, c, b) {
                var d;
                c = Ui(a, c, {
                    eg: nq,
                    ei: (d = {}, d.href = !0, d)
                });
                b = ua(A(function(f) {
                    return "*" === f ? f : Ub(f)
                }, b));
                var e = A(w(Q, Ea("concat", [""]), Vi("reverse"), ma), b);
                b = Kd(a);
                d = Wi(a, b, 1E3);
                c = u(e, c);
                d.F(c);
                oq(a, b);
                Xi(a, b);
                c()
            }

            function nq(a, c, b) {
                var d = fb(a),
                    e = b.sb,
                    f = b.Sb,
                    g = e.parentNode,
                    h = e.textContent;
                if (!("text" === b.ke && h && d && g)) return !1;
                b = d("small");
                Yi(b);
                var k = Zi(h).length;
                x(Ea("appendChild", b), N(function(l, m) {
                    var p = l.nodes,
                        q = l.lg,
                        r = d("small");
                    r.innerHTML = m;
                    var t = pq.test(m);
                    Yi(r);
                    t && (r.style.opacity = "" + (k - q - 1) / k);
                    p.push(r);
                    return {
                        nodes: p,
                        lg: q + (t ? 1 : 0)
                    }
                }, {
                    nodes: [],
                    lg: 0
                }, h).nodes);
                qq(a, c, b, f);
                g.insertBefore(b, e);
                e.textContent = "";
                return !0
            }

            function qq(a, c, b, d) {
                function e() {
                    x(function(l) {
                        l.style &&
                            z(l.style, {
                                opacity: ""
                            })
                    }, Ba(b.childNodes));
                    if (c) {
                        var k = za(a, c);
                        k && k.extLink("tel:" + d, {})
                    }
                    g();
                    h()
                }
                var f = fa(a),
                    g = D,
                    h = D;
                g = f.F(b, ["mouseenter"], function(k) {
                    if (k.target === b) {
                        var l = U(a, e, 200, "ph.h.e");
                        h();
                        h = f.F(b, ["mouseleave"], function(m) {
                            m.target === b && la(a, l)
                        })
                    }
                })
            }

            function Xi(a, c) {
                Nb(a)(Ra(D, function() {
                    var b, d = a.document.body,
                        e = (b = {}, b.attributes = !0, b.childList = !0, b.subtree = !0, b);
                    Da("MutationObserver", a.MutationObserver) && (new MutationObserver(c.R)).observe(d, e)
                }))
            }

            function oq(a, c) {
                return fa(a).F(a, ["load"],
                    c.R)
            }

            function Ui(a, c, b) {
                function d(k) {
                    return f(a, c, k) ? h[k.Sb] && h[k.Sb].Yc : null
                }
                var e, f = b.eg;
                b = b.ei;
                var g = void 0 === b ? (e = {}, e.href = !0, e.text = !0, e) : b,
                    h;
                return function(k) {
                    return new K(function(l, m) {
                        k && k.length || m();
                        h = $i()(k);
                        Nb(a)(Ra(u({
                            ja: [],
                            Aa: 0
                        }, l), function() {
                            var p = ja(a),
                                q = p(Z),
                                r = g.href ? rq(a, h) : [],
                                t = g.text ? aj(a, h, a.document.body) : [];
                            l({
                                ja: ha(R, ua(A(d, r.concat(t)))),
                                Aa: p(Z) - q
                            })
                        }))
                    })
                }
            }

            function rq(a, c) {
                var b = a.document.body;
                if (!b) return [];
                var d = bj(c);
                return N(function(e, f) {
                    var g = n(f, "href");
                    try {
                        var h =
                            decodeURI(g || "")
                    } catch (p) {
                        h = ""
                    }
                    if ("tel:" === h.slice(0, 4)) {
                        var k = (d.exec(h) || [])[0],
                            l = k ? Ub(k) : "",
                            m = c[l];
                        X(m) || !l && "*" !== m.Yc[0] || (e.push({
                            ke: "href",
                            sb: f,
                            Sb: l,
                            bb: cj(k, c[l].bb),
                            Oi: g
                        }), g = Ub(h.slice(4)), l = $i()([l ? m.Yc : [g, ""]]), ra(e, aj(a, l, f)))
                    }
                    return e
                }, [], Ba(b.querySelectorAll("a")))
            }

            function aj(a, c, b) {
                if (!b) return [];
                var d = [],
                    e = bj(c),
                    f = ["script", "style"];
                pd(a, b, function(g) {
                    var h = n(g, "parentNode.nodeName") || "";
                    g === b || I(h.toLowerCase(), f) || (h = ua(e.exec(g.textContent || "") || []), x(function(k) {
                        var l = Ub(k);
                        X(c[l]) ||
                            d.push({
                                ke: "text",
                                sb: g,
                                Sb: l,
                                bb: cj(k, c[l].bb),
                                Oi: g.textContent || ""
                            })
                    }, h))
                }, function(g) {
                    return e.test(g.textContent || "") ? 1 : 0
                }, a.NodeFilter.SHOW_TEXT);
                return d
            }

            function $i() {
                return $f(function(a, c) {
                    var b = A(Ub, c),
                        d = b[0];
                    b = b[1];
                    a[d] = {
                        bb: b,
                        Yc: c
                    };
                    var e = dj(d);
                    e !== d && (a[e] = {
                        bb: dj(b),
                        Yc: c
                    });
                    return a
                }, {})
            }

            function cj(a, c) {
                for (var b = [], d = a.split(""), e = c.split(""), f = 0, g = 0; g < a.length && !(f >= e.length); g += 1) {
                    var h = d[g];
                    "0" <= h && "9" >= h ? (b.push(e[f]), f += 1) : b.push(d[g])
                }
                return G("", b) + c.slice(f + 1)
            }

            function dj(a) {
                var c = {
                    7: "8",
                    8: "7"
                };
                return 11 === a.length && c[a[0]] ? "" + c[a[0]] + a.slice(1) : a
            }

            function bj(a) {
                return new RegExp("(?:" + G("|", A(ej, da(a))) + ")")
            }

            function fj(a, c, b, d) {
                if (c) {
                    var e = [];
                    c && (a.document.documentElement.contains(c) ? pd(a, c, Ea("push", e), d) : ra(e, gj(a, c, d)));
                    x(b, e)
                }
            }

            function pd(a, c, b, d, e, f) {
                function g(k) {
                    return O(d) ? d(k) ? a.NodeFilter.FILTER_ACCEPT : a.NodeFilter.FILTER_REJECT : a.NodeFilter.FILTER_ACCEPT
                }
                void 0 === e && (e = -1);
                void 0 === f && (f = !1);
                var h = g(c);
                if (O(b) && (f || h === a.NodeFilter.FILTER_ACCEPT) && (h && b(c), !Sf(c)))
                    for (c =
                        a.document.createTreeWalker(c, e, d ? {
                            acceptNode: g
                        } : null, !1); c.nextNode() && !1 !== b(c.currentNode););
            }

            function gj(a, c, b) {
                var d = [],
                    e = w(Q, Ea("push", d));
                O(b) ? (b = b(c), (ca(b) || b === a.NodeFilter.FILTER_ACCEPT) && e(c)) : e(c);
                if (c.childNodes && 0 < c.childNodes.length) {
                    c = c.childNodes;
                    b = 0;
                    for (var f = c.length; b < f; b += 1) {
                        var g = gj(a, c[b]);
                        x(e, g)
                    }
                }
                return d
            }

            function hj(a, c, b) {
                var d;
                a = [ij(a, c, function(e) {
                    d = e;
                    e.za.F(b)
                }), function() {
                    d && d.unsubscribe()
                }];
                return C([Ge, a], x)
            }

            function sq(a, c, b, d) {
                var e, f, g;
                if (b) {
                    var h = n(d, "ecommerce") || {};
                    var k = n(d, "event") || "";
                    h = ka(h) && ia(k) ? Wf(k, h) : void 0;
                    if (!h) a: {
                        var l = d;!R(d) && mc(a, Sa(d)) && (l = Pa(l));
                        if (R(l) && (h = l[0], k = l[1], l = l[2], ia(k) && ka(l) && "event" === h)) {
                            h = Wf(k, l);
                            break a
                        }
                        h = void 0
                    }
                    if (d = h || tq(d)) vb(a, (e = {}, e.counterKey = c, e.name = "ecommerce", e.data = d, e)), b((f = {}, f.__ym = (g = {}, g.ecommerce = [d], g), f))
                }
            }

            function tq(a) {
                var c = n(a, "ecommerce");
                if (ka(c)) return a = ha(vc(uq), da(c)), a = N(function(b, d) {
                    b[d] = c[d];
                    return b
                }, {}, a), 0 === da(a).length ? void 0 : a
            }

            function Wf(a, c) {
                var b, d, e = ia(a) ? vq[a] : a;
                if (e) {
                    var f =
                        e.event,
                        g = e.La,
                        h = e.Dh,
                        k = void 0 === h ? "items" : h,
                        l = c.purchase || c;
                    if (h = l[k]) {
                        e = A(u(e.xa, wq), h);
                        var m = (b = {}, b[f] = g ? (d = {}, d[g] = e, d) : e, b);
                        b = da(l);
                        g && 1 < b.length && (m[f].actionField = Bb(function(p, q) {
                            if (q === k) return p;
                            if ("currency" === q) return m.currencyCode = l.currency, p;
                            p[xq[q] || ag[q] || q] = l[q];
                            return p
                        }, {}, b));
                        return m
                    }
                }
            }

            function wq(a, c) {
                var b = {};
                x(function(d) {
                    var e = a[d] || ag[d] || d; - 1 !== ib(d, "item_category") ? (e = ag.item_category, b[e] = b[e] ? b[e] + ("/" + c[d]) : c[d]) : b[e] = c[d]
                }, da(c));
                return b
            }

            function yq(a, c, b) {
                var d,
                    e, f, g = n(b, "target");
                if (g && (g = je(a, g), g = ke(a, g))) {
                    g = "?" + Fc(g);
                    var h = nc(a, c, "gbn", (d = {}, d.id = c.id, d.query = g, d));
                    b = n(b, "isTrusted");
                    b = ca(b) ? void 0 : (e = {}, e.__ym = (f = {}, f.ite = tb(b), f), e);
                    He(a, c, "btn", h).reachGoal(g, b)
                }
            }

            function zq(a, c, b, d) {
                var e = n(d, "target");
                e && (d = n(d, "isTrusted"), (e = oc("button,input", a, e)) && "submit" === e.type && (e = Oi(a, e))) && (b.push(e), U(a, C([!1, a, c, b, e, d], jj), 300))
            }

            function jj(a, c, b, d, e, f) {
                var g, h, k, l = Pb(c)(e, d),
                    m = -1 !== l;
                if (a || m) m && d.splice(l, 1), a = Pi(c, e), a = "?" + Fc(a), d = C([c, b, "fg", (g = {}, g.id = b.id, g.query = a, g)], kj), f = ca(f) ? void 0 : (h = {}, h.__ym = (k = {}, k.ite = tb(f), k), h), He(c, b, "form", d).reachGoal(a, f)
            }

            function kj(a, c, b, d) {
                return Aq(a, c).then(w(C([nc(a, c, b, d), D], Ad), ma))
            }

            function Pi(a, c, b) {
                return lj(a, c, ["i", "n", "p"], void 0, b)
            }

            function Bq(a, c) {
                var b;
                a((b = {}, b.clickmap = X(c) ? !0 : c, b))
            }

            function Cq(a, c, b, d, e) {
                var f, g = "clmap/" + e.id;
                c = (f = {}, f["page-url"] = c, f["pointer-click"] = b, f);
                f = {
                    K: Ja(),
                    J: c,
                    na: {
                        Ba: g
                    }
                };
                d(f, e)["catch"](E(a, "c.s.c"))
            }

            function Dq(a, c, b, d, e) {
                if (Lb(a, "ymDisabledClickmap") || !c ||
                    !c.element) return !1;
                a = Ma(c.element);
                if (e && !e(c.element, a) || I(c.button, [2, 3]) && "A" !== a || $a(Aa(a), d)) return !1;
                d = c.element;
                if (c && b) {
                    if (50 > c.time - b.time) return !1;
                    e = Math.abs(b.position.x - c.position.x);
                    a = Math.abs(b.position.y - c.position.y);
                    c = c.time - b.time;
                    if (b.element === d && 2 > e && 2 > a && 1E3 > c) return !1
                }
                for (; d;) {
                    if (Eq(d)) return !1;
                    d = d.parentElement
                }
                return !0
            }

            function Fq(a, c) {
                var b = null;
                try {
                    if (b = c.target || c.srcElement) !b.ownerDocument && b.documentElement ? b = b.documentElement : b.ownerDocument !== a.document && (b = null)
                } catch (d) {}
                return b
            }

            function Gq(a) {
                var c = a.which;
                a = a.button;
                return c || void 0 === a ? c : 1 === a || 3 === a ? 1 : 2 === a ? 3 : 4 === a ? 2 : 0
            }

            function mj(a, c) {
                var b = fc(a),
                    d = bg(a);
                return {
                    x: c.pageX || c.clientX + d.x - (b.clientLeft || 0) || 0,
                    y: c.pageY || c.clientY + d.y - (b.clientTop || 0) || 0
                }
            }

            function Ie(a, c) {
                return {
                    N: function(b, d) {
                        var e, f = b.K,
                            g = b.Ja,
                            h = b.J,
                            k = b.ba;
                        k = void 0 === k ? {} : k;
                        if (f && h) {
                            var l = ja(a);
                            f.Wb("rqnl", 1);
                            for (var m = Ld(a), p = 1; m[p];) p += 1;
                            b.M || (b.M = {});
                            b.M.Tb = p;
                            m[p] = (e = {}, e.protocol = Fa.Sa, e.host = jc, e.resource = b.na.Ba, e.postParams = k.da, e.time = l(Z), e.counterType =
                                c.ca, e.params = h, e.browserInfo = f.l(), e.counterId = c.id, e.ghid = Dc(a), e);
                            g && (m[p].telemetry = g.l());
                            cg(a)
                        }
                        d()
                    },
                    Da: function(b, d) {
                        nj(a, b);
                        d()
                    }
                }
            }

            function nj(a, c) {
                var b = Ld(a);
                c.K && !Wa(b) && c.M && (delete b[c.M.Tb], cg(a))
            }

            function cg(a) {
                var c = Ld(a);
                Oa(a).D("retryReqs", c)
            }

            function Hq(a, c) {
                if (a.Ui()) {
                    var b = oj(c);
                    if (b && !ic("ym-disable-tracklink", b)) {
                        var d = a.l,
                            e = a.Og,
                            f = a.cb,
                            g = a.sender,
                            h = a.ah,
                            k = f.wc,
                            l = b.href;
                        var m = ab(b.innerHTML && b.innerHTML.replace(/<\/?[^>]+>/gi, ""));
                        m || (m = (m = b.querySelector("img")) ? ab(m.getAttribute("title") ||
                            m.getAttribute("alt")) : "");
                        m = l === m ? "" : m;
                        var p = n(c, "isTrusted");
                        if (ic("ym-external-link", b)) Je(d, f, {
                            url: l,
                            ob: !0,
                            title: m,
                            Fc: p,
                            sender: g
                        });
                        else {
                            k = k ? Tc(d, k).hostname : S(d).hostname;
                            h = RegExp("\\.(" + G("|", A(Iq, h)) + ")$", "i");
                            var q = b.protocol + "//" + b.hostname + b.pathname;
                            h = pj.test(q) || pj.test(l) || h.test(l) || h.test(q);
                            b = b.hostname;
                            Ke(k) === Ke(b) ? h ? Je(d, f, {
                                url: l,
                                Dc: !0,
                                Fc: p,
                                title: m,
                                sender: g
                            }) : m && e.D("il", ab(m).slice(0, 100)) : l && Jq.test(l) || Je(d, f, {
                                url: l,
                                Hc: !0,
                                ob: !0,
                                Dc: h,
                                Fc: p,
                                title: m,
                                sender: g
                            })
                        }
                    }
                }
            }

            function Je(a, c,
                b) {
                var d, e, f, g, h = Ja();
                void 0 !== b.Fc && h.D("ite", tb(b.Fc));
                b.Dc && h.D("dl", 1);
                b.ob && h.D("ln", 1);
                var k = b.kg || {};
                h = {
                    K: h,
                    M: {
                        title: k.title || b.title,
                        Hc: !!b.Hc,
                        X: k.params
                    },
                    J: (d = {}, d["page-url"] = b.url, d["page-ref"] = c.wc || S(a).href, d)
                };
                d = "Link";
                b.Dc ? d = b.ob ? "Ext link - File" : "File" : b.ob && (d = "Ext link");
                vb(a, (e = {}, e.counterKey = L(c), e.name = "event", e.data = (f = {}, f.schema = "Link click", f.name = (b.ob ? "external" : "internal") + " url: " + b.url, f), e));
                c = b.sender(h, c).then(nc(a, c, "lcl", (g = {}, g.prefix = d, g.id = c.id, g.url = b.url,
                    g), b.kg));
                return Xc(a, "cl.p.s", c, k.callback || D, k.ctx)
            }

            function Kq(a, c) {
                var b, d, e = (b = {}, b.string = !0, b.object = !0, b["boolean"] = c, b)[typeof c] || !1;
                a((d = {}, d.trackLinks = e, d))
            }

            function Lq(a, c, b, d) {
                var e = S(a),
                    f = e.hostname;
                e = e.href;
                if (c = Md(c).url) a = Tc(a, c), f = a.hostname, e = a.href;
                return [d + "://" + f + "/" + b, e || ""]
            }

            function qj(a) {
                return (a.split(":")[1] || "").replace(/^\/*/, "").replace(/^www\./, "").split("/")[0]
            }

            function Mq(a, c, b, d) {
                var e;
                if (a = za(a, b)) {
                    var f = d.data;
                    b = "" + b.id;
                    var g = d.sended || [];
                    d.sended || (d.sended =
                        g);
                    I(b, g) || !a.params || d.counter && "" + d.counter !== b || (a.params(f), g.push(b), d.parent && c.Tf((e = {}, e.type = "params", e.data = f, e)))
                }
            }

            function Fh(a, c, b) {
                void 0 === b && (b = Q);
                var d = ud(a);
                b(d);
                var e = u(d, Nq);
                Le(a, c, function(f) {
                    f.za.F(e)
                });
                return d
            }

            function Nq(a, c) {
                var b = n(c, "ymetrikaEvent");
                b && a.R(n(b, "type"), b)
            }

            function Le(a, c, b, d) {
                void 0 === b && (b = D);
                void 0 === d && (d = !1);
                var e = Kd(a);
                if (c && O(c.push)) {
                    var f = c.push;
                    c.push = function() {
                        var g = Pa(arguments),
                            h = g[0];
                        d && e.R(h);
                        g = f.apply(c, g);
                        d || e.R(h);
                        return g
                    };
                    a = {
                        za: e,
                        unsubscribe: function() {
                            c.push =
                                f
                        }
                    };
                    b(a);
                    x(e.R, c);
                    return a
                }
            }

            function ne(a) {
                a = J(a);
                var c = a.C("dataLayer", []);
                a.D("dataLayer", c);
                return c
            }

            function en(a, c) {
                var b, d;
                I(c, A(T("ymetrikaEvent.type"), a)) || a.push((b = {}, b.ymetrikaEvent = (d = {}, d.type = c, d), b))
            }

            function rj(a, c) {
                var b = rd(a, c),
                    d = [],
                    e = [];
                if (!b) return null;
                var f = C([a, b.oe], Oq),
                    g = u(f, Pq);
                b.$.F(["initToParent"], function(h) {
                    g(d, b.children[h[1].counterId])
                }).F(["parentConnect"], function(h) {
                    g(e, b.Ga[h[1].counterId])
                });
                return {
                    $: b.$,
                    Hj: function(h, k) {
                        return new K(function(l, m) {
                            b.oe(h, k, function(p,
                                q) {
                                l([p, q])
                            });
                            U(a, u(Ta(), m), 5100, "is.o")
                        })
                    },
                    Sf: function(h) {
                        var k = {
                            Vf: [],
                            Be: [],
                            data: h
                        };
                        d.push(k);
                        return f(b.children, k, h)
                    },
                    Tf: function(h) {
                        var k = {
                            Vf: [],
                            Be: [],
                            data: h
                        };
                        e.push(k);
                        return f(b.Ga, k, h)
                    }
                }
            }

            function Pq(a, c, b) {
                c = ha(function(d) {
                    return !I(b.info.counterId, d.Be)
                }, c);
                x(function(d) {
                    var e;
                    b.info.counterId && a((e = {}, e[b.info.counterId] = b, e), d, d.data)
                }, c)
            }

            function Oq(a, c, b, d, e) {
                return (new K(function(f, g) {
                    var h = da(b),
                        k = w(d.resolve || Q, Sc(f)),
                        l = w(d.reject || Q, Sc(g));
                    d.resolve = k;
                    d.reject = l;
                    x(function(m) {
                        var p;
                        d.Be.push(+m);
                        var q = b[m],
                            r = U(a, u(Ta(), l), 5100, "is.m");
                        c(q.window, z(e, (p = {}, p.toCounter = Ha(m), p)), function(t, y) {
                            la(a, r);
                            d.Vf.push(m);
                            d.resolve && d.resolve(y)
                        })
                    }, h)
                }))["catch"](E(a, "if.b"))
            }

            function Qq(a) {
                var c = D,
                    b = null,
                    d = a.length;
                if (0 !== a.length && a[0]) {
                    var e = a.slice(-1)[0];
                    O(e) && (c = e, d = a.length + -1);
                    var f = a.slice(-2)[0];
                    O(f) && (c = f, b = e, d = a.length + -2);
                    d = a.slice(0, d);
                    return {
                        Pg: b,
                        cc: c,
                        X: 1 === d.length ? a[0] : td(d)
                    }
                }
            }

            function Xc(a, c, b, d, e) {
                var f = C([a, d, e], dg);
                return b.then(f, function(g) {
                    f();
                    Cd(a, c, g)
                })
            }

            function eg(a,
                c) {
                return {
                    N: function(b, d) {
                        var e, f, g = (b.M || {}).X,
                            h = b.ba;
                        h = void 0 === h ? {} : h;
                        if (g && (sj(c, g), !h.da && b.K && b.J)) {
                            var k = Ab(a, g),
                                l = tj(a),
                                m = b.K.C("pv");
                            k && !b.J.nohit && (vb(a, (e = {}, e.counterKey = L(c), e.name = "params", e.data = (f = {}, f.val = g, f), e)), m ? encodeURIComponent(k).length > Fa.qg ? l.push([b.K, g]) : b.J["site-info"] = k : (h.da = k, b.ba = h, b.Oc || (b.Oc = {}), b.Oc.hi = !0))
                        }
                        d()
                    },
                    Da: function(b, d) {
                        var e = tj(a),
                            f = za(a, c),
                            g = f && f.params;
                        g && (f = ha(w(Yc, Aa(b.K)), e), x(function(h) {
                            g(h[1]);
                            h = Me(a)(h, e);
                            e.splice(h, 1)
                        }, f));
                        d()
                    }
                }
            }

            function Ne(a,
                c) {
                return function(b) {
                    fg(a, c, b)
                }
            }

            function Rq(a, c) {
                gg(a)(function(b) {
                    delete b[c]
                })
            }

            function fg(a, c, b) {
                gg(a)(function(d) {
                    d[c] = z(d[c] || {}, b)
                })
            }

            function gg(a) {
                a = J(a);
                var c = a.C("dsjf") || Ga({});
                a.Ia("dsjf", c);
                return c
            }

            function Sq(a, c) {
                return function(b) {
                    var d, e, f = za(a, c);
                    if (f) {
                        var g = pc(a, L(c));
                        ka(b) ? Sa(da(b)) ? (b = uj(a, b)) && Sa(b) && f.params((d = {}, d.__ym = (e = {}, e.fpmh = b, e), d)) : g.log("fpeo") : g.log("fpno")
                    }
                }
            }

            function uj(a, c) {
                return N(function(b, d) {
                    var e = d[0],
                        f = d[1],
                        g = f;
                    f = ka(f);
                    if (!f && (mc(a, g) && (g = "" + g), !ia(g))) return b;
                    g = f ? uj(a, g) : g;
                    Sa(g) && b.push([e, g]);
                    return b
                }, [], La(c))
            }

            function vj(a, c, b) {
                void 0 === b && (b = 0);
                c = La(c);
                c = N(function(d, e) {
                    var f = e[0],
                        g = e[1],
                        h = ka(g);
                    if (!h && (mc(a, g) && (g = "" + g), !ia(g))) return d;
                    h ? g = vj(a, g, b + 1) : !b && I(f, Tq) ? g = K.resolve(g) : ("phone_number" === f ? g = Oh(a, g) : "email" === f && (g = Nh(g)), g = wj(a, g));
                    d.push(g.then(function(k) {
                        return [f, k]
                    }));
                    return d
                }, [], c);
                return K.all(c)
            }

            function Nh(a) {
                var c = ab(a).replace(/^\++/gm, "").toLowerCase(),
                    b = c.lastIndexOf("@");
                if (-1 === b) return c;
                a = c.substr(0, b);
                b = c.substr(b + 1);
                if (!b || !Uq(a)) return c;
                b = b.replace("googlemail.com", "gmail.com");
                xj(b) && (b = "yandex.ru");
                "yandex.ru" === b ? a = a.replace(hg, "-") : "gmail.com" === b && (a = a.replace(hg, ""));
                c = ib(a, "+"); - 1 !== c && (a = a.slice(0, c));
                return a + "@" + b
            }

            function Uq(a) {
                return 1 > a.length || 64 < a.length ? !1 : Li(function(c) {
                    if (1 > c.length) c = !1;
                    else if ('"' === c[0] && '"' === c[c.length - 1] && 2 < c.length) a: {
                        for (var b = 1; b + 2 < c.length; b += 1) {
                            var d = c.charCodeAt(b);
                            if (32 > d || 34 === d || 126 < d) {
                                c = !1;
                                break a
                            }
                            if (92 === d) {
                                if (b + 2 === c.length || 32 > c.charCodeAt(b + 1)) {
                                    c = !1;
                                    break a
                                }
                                b +=
                                    1
                            }
                        }
                        c = !0
                    }
                    else c = Vq.test(c) ? !0 : !1;
                    return c
                }, a.split("."))
            }

            function Oh(a, c) {
                var b = Wq(c),
                    d = Ub(c);
                return 10 > d.length || 13 < d.length || b.startsWith("+8") ? ab(c) : "8" === b[0] ? "7" + d.slice(1) : "+" === b[0] || mc(a, +b[0]) ? d : "7" + d
            }

            function wj(a, c) {
                return new K(function(b, d) {
                    var e = (new a.TextEncoder).encode(c);
                    a.crypto.subtle.digest("SHA-256", e).then(function(f) {
                        f = new a.Blob([f], {
                            type: "application/octet-binary"
                        });
                        var g = new a.FileReader;
                        g.onload = function(h) {
                            h = n(h, "target.result") || "";
                            var k = ib(h, ","); - 1 !== k ? b(h.substring(k +
                                1)) : d(Qa("fpm.i"))
                        };
                        g.readAsDataURL(f)
                    }, d)
                })
            }

            function za(a, c) {
                var b = J(a).C("counters", {}),
                    d = L(c);
                return b[d]
            }

            function nc(a, c, b, d, e) {
                return C([a, L(c), e ? [b + ".p", e] : b, d], Kb)
            }

            function Kb(a, c, b, d) {
                pc(a, c).log(b, d)
            }

            function Xq(a, c) {
                function b(d, e, f) {
                    var g, h;
                    vb(a, (g = {}, g.name = "log", g.counterKey = c, g.data = (h = {}, h.args = R(e) ? e : [e], h.type = d, h.variables = f, h), g))
                }
                return {
                    log: u("log", b),
                    error: u("error", b),
                    warn: u("warn", b)
                }
            }

            function pa(a, c) {
                var b = L(a);
                return yj()(Yq(b)).then(c)
            }

            function Zq(a, c, b) {
                var d, e;
                c = L(c);
                var f =
                    ig(a);
                b = z({
                    dh: f(Z)
                }, b);
                vb(a, (d = {}, d.counterKey = c, d.name = "counterSettings", d.data = (e = {}, e.settings = b, e), d));
                return yj()($q(c, b))
            }

            function $q(a, c) {
                return function(b) {
                    var d = b[a];
                    d ? (d.Gf = !0, d.Ff(c)) : b[a] = {
                        promise: K.resolve(c),
                        Gf: !0,
                        Ff: D
                    }
                }
            }

            function jg(a) {
                return !Dd(a) && kg(a)
            }

            function Nd(a) {
                return fb(a) ? u(a, ar) : !1
            }

            function Eb(a) {
                if (a.fetch) {
                    var c = n(a, "AbortController");
                    return C([a, c ? new c : void 0], br)
                }
                return !1
            }

            function kg(a) {
                var c = n(a, "navigator.sendBeacon");
                return c && Da("sendBeacon", c) ? C([a, H(c, n(a, "navigator"))],
                    cr) : !1
            }

            function cr(a, c, b, d) {
                return new K(function(e, f) {
                    var g;
                    if (!n(a, "navigator.onLine")) return f();
                    var h = z(d.$a, (g = {}, g["force-urlencoded"] = 1, g));
                    g = b + "?" + Fc(h) + (d.da ? "&" + d.da : "");
                    return 2E3 < g.length ? f(Ta("sb.tlq")) : c(g) ? e("") : f()
                })
            }

            function ar(a, c, b) {
                return new K(function(d, e) {
                    var f, g, h = "_ymjsp" + Xa(a),
                        k = z((f = {}, f.callback = h, f), b.$a),
                        l = C([a, h], dr);
                    a[h] = function(p) {
                        try {
                            l(), yc(m), d(p)
                        } catch (q) {
                            e(q)
                        }
                    };
                    k.wmode = "5";
                    var m = uc(a, (g = {}, g.src = zj(c, b, k), g));
                    if (!m) return l(), e(Qa("jp.s"));
                    f = u(m, yc);
                    f = w(f, u(Ta(b.ha),
                        e));
                    g = Od(a, f, b.Qa || 1E4);
                    g = C([a, g], la);
                    m.onload = g;
                    m.onerror = w(l, g, f)
                })
            }

            function dr(a, c) {
                try {
                    delete a[c]
                } catch (b) {
                    a[c] = void 0
                }
            }

            function Zc(a) {
                var c = fb(a);
                return c ? C([a, c], er) : !1
            }

            function er(a, c, b, d) {
                return new K(function(e, f) {
                    var g = fc(a),
                        h = c("img"),
                        k = w(u(h, yc), u(Ta(d.ha), f)),
                        l = Od(a, k, d.Qa || 3E3);
                    h.onerror = k;
                    h.onload = w(u(h, yc), u(null, e), C([a, l], la));
                    k = z({}, d.$a);
                    delete k.wmode;
                    h.src = zj(b, d, k);
                    Fd(a) && (z(h.style, {
                        position: "absolute",
                        visibility: "hidden",
                        width: "0px",
                        height: "0px"
                    }), g.appendChild(h))
                })
            }

            function br(a,
                c, b, d) {
                var e, f = z(d.Ab ? (e = {}, e.wmode = "7", e) : {}, d.$a),
                    g = c || {
                        signal: void 0,
                        abort: D
                    },
                    h = a.fetch(b + "?" + Fc(f), {
                        method: d.$c,
                        body: d.da,
                        credentials: !1 === d.Ie ? "omit" : "include",
                        headers: d.Za,
                        signal: g.signal
                    }),
                    k = u(d.ha, Ta);
                return new K(function(l, m) {
                    d.Qa && Od(a, function() {
                        try {
                            g.abort()
                        } catch (p) {}
                        m(k())
                    }, d.Qa);
                    return h.then(function(p) {
                        if (!p.ok) {
                            if (d.le) return Va(Aj(p));
                            fe(d.ha)
                        }
                        return d.le ? p.text() : d.Ab ? p.json() : null
                    }).then(l)["catch"](u(k(), m))
                })
            }

            function Fb(a) {
                var c;
                if (c = n(a, "XMLHttpRequest"))
                    if (c = "withCredentials" in
                        new a.XMLHttpRequest) {
                        a: {
                            if (fr.test(a.location.host) && a.opera && O(a.opera.version) && (c = a.opera.version(), "string" === typeof c && "12" === c.split(".")[0])) {
                                c = !0;
                                break a
                            }
                            c = !1
                        }
                        c = !c
                    }
                return c ? u(a, gr) : !1
            }

            function gr(a, c, b) {
                var d, e = new a.XMLHttpRequest,
                    f = b.da,
                    g = z(b.Ab ? (d = {}, d.wmode = "7", d) : {}, b.$a);
                return new K(function(h, k) {
                    e.open(b.$c || "GET", c + "?" + Fc(g), !0);
                    e.withCredentials = !1 !== b.Ie;
                    b.Qa && (e.timeout = b.Qa);
                    hr(La, Wb(function(m) {
                        e.setRequestHeader(m[0], m[1])
                    }))(b.Za);
                    var l = C([a, e, Ta(b.ha), b.Ab, b.le, h, k], ir);
                    e.onreadystatechange = l;
                    try {
                        e.send(f)
                    } catch (m) {}
                })
            }

            function ir(a, c, b, d, e, f, g, h) {
                if (4 === c.readyState)
                    if (200 === c.status || e || g(b), e) 200 === c.status ? f(c.responseText) : g(Aj(c));
                    else {
                        e = null;
                        if (d) try {
                            (e = qb(a, c.responseText)) || g(b)
                        } catch (k) {
                            g(b)
                        }
                        f(e)
                    }
                return h
            }

            function zj(a, c, b) {
                (b = Fc(b)) && (a += "?" + b);
                c.da && (a += (b ? "&" : "?") + c.da);
                return a
            }

            function jr(a, c, b) {
                var d = A(Yc, Xb[c] || Yb);
                x(function(e) {
                    return d.unshift(e)
                }, Oe);
                return A(w(Nc([a, b]), ma), d)
            }

            function Bj(a) {
                return {
                    N: function(c, b) {
                        var d = c.J;
                        if (!c.K || !d) return b();
                        var e = d["page-ref"],
                            f = d["page-url"];
                        e && f !== e ? d["page-ref"] = Cj(a, e) : delete d["page-ref"];
                        d["page-url"] = Cj(a, f).slice(0, Fa.sg);
                        return b()
                    }
                }
            }

            function Cj(a, c) {
                var b = S(a),
                    d = b.href,
                    e = b.host,
                    f = -1;
                if (!ia(c) || X(c)) return d;
                b = c.replace(Dj, "");
                if (-1 !== b.search(kr)) return b;
                var g = b.charAt(0);
                if ("?" === g && (f = d.search(/\?/), -1 === f) || "#" === g && (f = d.search(/#/), -1 === f)) return d + b;
                if (-1 !== f) return d.substr(0, f) + b;
                if ("/" === g) {
                    if (f = ib(d, e), -1 !== f) return d.substr(0, f + e.length) + b
                } else return d = d.split("/"), d[d.length - 1] =
                    b, G("/", d);
                return ""
            }

            function Pe(a, c) {
                return {
                    N: function(b, d) {
                        var e = Ej(c);
                        e = C([b, e, d], lr);
                        mr(a, c, e)
                    },
                    Da: function(b, d) {
                        var e = b.K,
                            f = Ej(c);
                        if (e) {
                            var g = f.ta;
                            f.We === e && g && (x(ma, g), f.ta = null)
                        }
                        d()
                    }
                }
            }

            function lr(a, c, b) {
                var d = a.K;
                d ? Xf(a) ? (c.We = d, b()) : c.ta ? c.ta.push(b) : b() : b()
            }

            function Xf(a) {
                return (a = a.K) && a.C("pv") && !a.C("ar")
            }

            function mr(a, c, b) {
                if (Qe(a) && sb(a)) {
                    var d = nr(c);
                    if (!d.Sh) {
                        d.Sh = !0;
                        c = rd(a, c);
                        if (!c) {
                            b();
                            return
                        }
                        d.ta = [];
                        var e = function() {
                            d.ta && (x(ma, d.ta), d.ta = null)
                        };
                        U(a, e, 3E3);
                        c.$.F(["initToChild"], e)
                    }
                    d.ta ?
                        d.ta.push(b) : b()
                } else b()
            }

            function Fj(a, c) {
                return {
                    N: function(b, d) {
                        var e = b.K;
                        if (e && (!c || c.Rf)) {
                            var f = a.document.title;
                            b.M && b.M.title && (f = b.M.title);
                            var g = Gc("getElementsByTagName", a.document);
                            "string" !== typeof f && g && (f = g("title"), f = (f = n(f, "0.innerHtml")) ? f : "");
                            f = f.slice(0, Fa.rg);
                            e.D("t", f)
                        }
                        d()
                    }
                }
            }

            function Qb(a) {
                return function(c, b) {
                    return {
                        N: function(d, e) {
                            var f = d.K,
                                g = d.J;
                            f && g && x(function(h) {
                                var k = Pd[h],
                                    l = "bi",
                                    m = f;
                                k || (k = lg[h], l = "tel", m = pe(d));
                                k && (k = B(l + ":" + h, k, null)(c, b, d), m.Wb(h, k))
                            }, a || or());
                            e()
                        }
                    }
                }
            }

            function pr(a, c) {
                var b = Qd(a);
                c.F(["initToParent"], function(d) {
                    var e = d[0];
                    d = d[1];
                    window.window && (b.children[d.counterId] = {
                        info: d,
                        window: e.source
                    })
                }).F(["initToChild"], function(d) {
                    var e = d[0];
                    d = d[1];
                    e.source === a.parent && c.R("parentConnect", [e, d])
                }).F(["parentConnect"], function(d) {
                    var e = d[1];
                    e.counterId && (b.Ga[e.counterId] = {
                        info: e,
                        window: d[0].source
                    })
                })
            }

            function qr(a) {
                if (Da("MutationObserver", a.MutationObserver)) {
                    var c = Qd(a).children,
                        b = new a.MutationObserver(function() {
                            x(function(d) {
                                n(c[d], "window.window") ||
                                    delete c[d]
                            }, da(c))
                        });
                    Nb(a)(Ra(D, function() {
                        b.observe(a.document.body, {
                            subtree: !0,
                            childList: !0
                        })
                    }))
                }
            }

            function rr(a, c) {
                return function(b, d) {
                    var e, f = {
                        oc: ja(a)(Z),
                        key: a.Math.random(),
                        dir: 0
                    };
                    b.length && (f.oc = Ha(b[0]), f.key = parseFloat(b[1]), f.dir = Ha(b[2]));
                    z(d, c);
                    var g = (e = {
                        data: d
                    }, e.__yminfo = G(":", ["__yminfo", f.oc, f.key, f.dir]), e);
                    return {
                        meta: f,
                        Zf: Ab(a, g) || ""
                    }
                }
            }

            function Nb(a, c) {
                function b(e) {
                    n(c, d) ? e() : U(a, u(e, b), 100)
                }
                void 0 === c && (c = a);
                var d = (c.nodeType ? "contentWindow." : "") + "document.body";
                return Ga(function(e,
                    f) {
                    b(f)
                })
            }

            function Rd(a, c) {
                var b = c.Sd,
                    d = b || "uid";
                b = b ? a.location.hostname : void 0;
                var e = Vc(a),
                    f = Oa(a),
                    g = ja(a)(mg),
                    h = Gj(a, c),
                    k = h[0];
                h = h[1];
                var l = e.C("d");
                Hj(a, c);
                var m = !1;
                !h && k && (h = k, m = !0);
                if (!h) h = G("", [g, Xa(a, 1E6, 999999999)]), m = !0;
                else if (!l || 15768E3 < g - Ha(l)) m = !0;
                m && !c.Ua && (e.D(d, h, 525600, b), e.D("d", "" + g, 525600, b));
                f.D(d, h);
                return h
            }

            function sr(a, c) {
                return !c.Ua && Hj(a, c)
            }

            function Gj(a, c) {
                var b = Oa(a),
                    d = Vc(a),
                    e = c.Sd || "uid";
                return [b.C(e), d.C(e)]
            }

            function Dc(a) {
                var c = J(a),
                    b = c.C("hitId");
                b || (b = Xa(a), c.D("hitId",
                    b));
                return b
            }

            function ke(a, c, b) {
                var d = Ma(c);
                return d && lj(a, c, ua(["p", tr[d], "c"]), Zf, b)
            }

            function je(a, c) {
                var b = oc(ng, a, c);
                if (!b) {
                    var d = oc("div", a, c);
                    d && (jb(ng + ",div", d).length || (b = d))
                }
                return b
            }

            function lj(a, c, b, d, e) {
                return N(function(f, g) {
                    var h = null;
                    g in Ij ? h = c.getAttribute && c.getAttribute(Ij[g]) : g in $c && (h = "p" === g ? $c[g](a, c, e) : "c" === g ? $c[g](a, c, d) : $c[g](a, c));
                    h && (h = h.slice(0, Jj[g] || 100), f[g] = og[g] ? "" + gc(h) : h);
                    return f
                }, {}, b)
            }

            function ii(a, c, b) {
                if (od(a)) return Ba(b.querySelectorAll(c));
                var d = Kj(c.split(" "),
                    b);
                return ha(function(e, f) {
                    return Pb(a)(e, d) === f
                }, d)
            }

            function Kj(a, c) {
                var b = ra([], a),
                    d = b.shift();
                if (!d) return [];
                d = c.getElementsByTagName(d);
                return b.length ? xc(u(b, Kj), Ba(d)) : Ba(d)
            }

            function dc(a, c) {
                if (c.querySelector) return c.querySelector(a);
                var b = jb(a, c);
                return b && b.length ? b[0] : null
            }

            function jb(a, c) {
                if (!c || !c.querySelectorAll) return [];
                var b = c.querySelectorAll(a);
                return b ? Ba(b) : []
            }

            function oj(a) {
                var c = null;
                try {
                    c = a.target || a.srcElement
                } catch (b) {}
                if (c) {
                    3 === c.nodeType && (c = c.parentNode);
                    for (a = c && c.nodeName &&
                        ("" + c.nodeName).toLowerCase(); n(c, "parentNode.nodeName") && ("a" !== a && "area" !== a || !c.href && !c.getAttribute("xlink:href"));) a = (c = c.parentNode) && c.nodeName && ("" + c.nodeName).toLowerCase();
                    return c.href ? c : null
                }
                return null
            }

            function uc(a, c) {
                var b = fb(a);
                if (b) {
                    var d = a.document,
                        e = b("script");
                    e.src = c.src;
                    e.type = c.type || "text/javascript";
                    e.charset = c.charset || "utf-8";
                    e.async = c.async || !0;
                    try {
                        var f = d.getElementsByTagName("head")[0];
                        if (!f) {
                            var g = d.getElementsByTagName("html")[0];
                            f = b("head");
                            g && g.appendChild(f)
                        }
                        f.insertBefore(e,
                            f.firstChild);
                        return e
                    } catch (h) {}
                }
            }

            function di(a, c) {
                var b = Lj(a);
                I(c, b.rb) && (b.rb = ha(w(Aa(c), Hc), b.rb), b.rb.length || (yc(b.ib), b.ib = null))
            }

            function ci(a, c, b) {
                var d = Lj(c);
                I(b, d.rb) || d.rb.push(b);
                if (Wa(d.ib)) {
                    b = fb(a);
                    if (!b) return null;
                    b = b("iframe");
                    z(b.style, {
                        display: "none",
                        width: "1px",
                        height: "1px",
                        visibility: "hidden"
                    });
                    b.src = c;
                    a = fc(a);
                    if (!a) return null;
                    a.appendChild(b);
                    d.ib = b
                } else(a = n(d.ib, "contentWindow")) && a.postMessage("frameReinit", "*");
                return d.ib
            }

            function ur(a, c) {
                var b = R(a) ? a : [a];
                c = c || document;
                if (c.querySelectorAll) {
                    var d = G(", ", A(function(e) {
                        return "." + e
                    }, b));
                    return Ba(c.querySelectorAll(d))
                }
                if (c.getElementsByClassName) return xc(w(Ea("getElementsByClassName", c), Ba), b);
                d = c.getElementsByTagName("*");
                b = "(" + G("|", b) + ")";
                return ha(u(b, ic), Ba(d))
            }

            function vf(a, c, b) {
                for (var d = "", e = Fe(), f = Ma(c) || "*"; c && c.parentNode && !I(f, ["BODY", "HTML"]);) d += e[f] || "*", d += Mj(a, c, b) || "", c = c.parentElement, f = Ma(c) || "*";
                return ab(d, 128)
            }

            function Mj(a, c, b) {
                if (a = Re(a, c)) {
                    a = a.childNodes;
                    for (var d = c && c.nodeName, e = 0, f = 0; f <
                        a.length; f += 1)
                        if (d === (a[f] && a[f].nodeName)) {
                            if (c === a[f]) return e;
                            b && a[f] === b || (e += 1)
                        }
                }
                return 0
            }

            function Re(a, c) {
                var b = n(a, "document");
                return c && c !== b.documentElement ? c === Ic(a) ? b.documentElement : n(c, "parentNode") : null
            }

            function Pf(a, c) {
                var b = pg(a, c),
                    d = b.left;
                b = b.top;
                var e = Se(a, c);
                return [d, b, e[0], e[1]]
            }

            function Se(a, c) {
                var b = n(a, "document");
                if (c === Ic(a) || c === b.documentElement) {
                    b = fc(a);
                    var d = Pc(a);
                    return [Math.max(b.scrollWidth, d[0]), Math.max(b.scrollHeight, d[1])]
                }
                return (b = Oc(c)) ? [b.width, b.height] : [c.offsetWidth,
                    c.offsetHeight
                ]
            }

            function pg(a, c) {
                var b = c,
                    d = n(a, "document"),
                    e = Ma(b);
                if (!b || !b.ownerDocument || "PARAM" === e || b === Ic(a) || b === d.documentElement) return {
                    left: 0,
                    top: 0
                };
                if (d = Oc(b)) return b = bg(a), {
                    left: Math.round(d.left + b.x),
                    top: Math.round(d.top + b.y)
                };
                for (e = d = 0; b;) d += b.offsetLeft, e += b.offsetTop, b = b.offsetParent;
                return {
                    left: d,
                    top: e
                }
            }

            function oc(a, c, b) {
                if (!(c && c.Element && c.Element.prototype && c.document && b)) return null;
                if (c.Element.prototype.closest && Da("closest", c.Element.prototype.closest) && b.closest) return b.closest(a);
                var d = pi(c);
                if (d) {
                    for (; b && 1 === b.nodeType && !d.call(b, a);) b = b.parentElement || b.parentNode;
                    return b && 1 === b.nodeType ? b : null
                }
                if (od(c)) {
                    for (a = Ba((c.document || c.ownerDocument).querySelectorAll(a)); b && 1 === b.nodeType && -1 === Pb(c)(b, a);) b = b.parentElement || b.parentNode;
                    return b && 1 === b.nodeType ? b : null
                }
                return null
            }

            function od(a) {
                return !(!Da("querySelectorAll", n(a, "Element.prototype.querySelectorAll")) || !a.document.querySelectorAll)
            }

            function Ah(a, c, b) {
                var d = c.top,
                    e = c.bottom,
                    f = c.left,
                    g = b.w;
                b = b.h;
                a = a.Math;
                c = a.min(a.max(c.right,
                    0), g) - a.min(a.max(f, 0), g);
                return (a.min(a.max(e, 0), b) - a.min(a.max(d, 0), b)) * c
            }

            function Nj(a) {
                return Te(a) && !$a(Aa(a.type), vr) ? Ue(a) ? !a.checked : !a.value : wr(a) ? !a.value : xr(a) ? 0 > a.selectedIndex : !0
            }

            function Ma(a) {
                if (a) try {
                    var c = a.nodeName;
                    if (ia(c)) return c;
                    c = a.tagName;
                    if (ia(c)) return c
                } catch (b) {}
            }

            function Oj(a, c) {
                var b = a.document.getElementsByTagName("form");
                return Pb(a)(c, Ba(b))
            }

            function yr(a, c, b) {
                b = Gc("dispatchEvent", b || a.document);
                var d = null,
                    e = n(a, "Event.prototype.constructor");
                if (e && (Da("(Event|Object|constructor)",
                        e) || qg(a) && "[object Event]" === "" + e)) try {
                    d = new a.Event(c)
                } catch (f) {
                    if ((a = Gc("createEvent", n(a, "document"))) && O(a)) {
                        try {
                            d = a(c)
                        } catch (g) {}
                        d && d.initEvent && d.initEvent(c, !1, !1)
                    }
                }
                d && b(d)
            }

            function Oc(a) {
                try {
                    return a.getBoundingClientRect && a.getBoundingClientRect()
                } catch (c) {
                    return "object" === typeof c && null !== c && 16389 === (c.wf && c.wf & 65535) ? {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        width: 0,
                        height: 0,
                        right: 0
                    } : null
                }
            }

            function bg(a) {
                var c = Ic(a),
                    b = n(a, "document");
                return {
                    x: a.pageXOffset || b.documentElement && b.documentElement.scrollLeft ||
                        c && c.scrollLeft || 0,
                    y: a.pageYOffset || b.documentElement && b.documentElement.scrollTop || c && c.scrollTop || 0
                }
            }

            function Pc(a) {
                var c = me(a);
                if (c) {
                    var b = c[2];
                    return [a.Math.round(c[0] * b), a.Math.round(c[1] * b)]
                }
                c = fc(a);
                return [n(c, "clientWidth") || a.innerWidth, n(c, "clientHeight") || a.innerHeight]
            }

            function me(a) {
                var c = n(a, "visualViewport.width"),
                    b = n(a, "visualViewport.height");
                a = n(a, "visualViewport.scale");
                return ca(c) || ca(b) ? null : [Math.floor(c), Math.floor(b), a]
            }

            function fc(a) {
                var c = n(a, "document") || {},
                    b = c.documentElement;
                return "CSS1Compat" === c.compatMode ? b : Ic(a) || b
            }

            function Ic(a) {
                a = n(a, "document");
                try {
                    return a.getElementsByTagName("body")[0]
                } catch (c) {
                    return null
                }
            }

            function ic(a, c) {
                try {
                    return (new RegExp("(?:^|\\s)" + a + "(?:\\s|$)")).test(c.className)
                } catch (b) {
                    return !1
                }
            }

            function Jc(a) {
                var c;
                try {
                    if (c = a.target || a.srcElement) !c.ownerDocument && c.documentElement ? c = c.documentElement : c.ownerDocument !== document && (c = null)
                } catch (b) {}
                return c
            }

            function yc(a) {
                var c = a && a.parentNode;
                c && c.removeChild(a)
            }

            function Mb(a) {
                return a ? a.innerText ||
                    "" : ""
            }

            function Sf(a) {
                if (ca(a)) return !1;
                a = a.nodeType;
                return 3 === a || 8 === a
            }

            function Pj(a, c, b) {
                void 0 === c && (c = "");
                void 0 === b && (b = "_ym");
                var d = "" + b + c;
                d && (d += "_");
                return {
                    Ld: zr(a),
                    C: function(e, f) {
                        var g = Qj(a, "" + d + e);
                        return Wa(g) && !X(f) ? f : g
                    },
                    D: function(e, f) {
                        Rj(a, "" + d + e, f);
                        return this
                    },
                    pc: function(e) {
                        Sj(a, "" + d + e);
                        return this
                    }
                }
            }

            function Rj(a, c, b) {
                var d = rg(a);
                a = Ab(a, b);
                if (!Wa(a)) try {
                    d.setItem(c, a)
                } catch (e) {}
            }

            function Qj(a, c) {
                var b = rg(a);
                try {
                    return qb(a, b.getItem(c))
                } catch (d) {}
                return null
            }

            function Sj(a, c) {
                var b =
                    rg(a);
                try {
                    b.removeItem(c)
                } catch (d) {}
            }

            function rg(a) {
                try {
                    return a.localStorage
                } catch (c) {}
                return null
            }

            function Ab(a, c, b) {
                try {
                    return a.JSON.stringify(c, null, b)
                } catch (d) {
                    return null
                }
            }

            function pe(a, c, b) {
                void 0 === b && (b = null);
                a.Ja || (a.Ja = wf());
                c && a.Ja.Wb(c, b);
                return a.Ja
            }

            function Ve(a) {
                return {
                    N: function(c, b) {
                        var d = a.document,
                            e = c.K;
                        if (e && sg(a)) {
                            var f = fa(a),
                                g = function(h) {
                                    sg(a) || (f.xb(d, Tj, g), b());
                                    return h
                                };
                            f.F(d, Tj, g);
                            e.D("pr", "1")
                        } else b()
                    }
                }
            }

            function Sd(a) {
                return function(c, b, d) {
                    return function(e, f) {
                        var g =
                            A(w(Yc, Nc([c, f]), ma), Uj[a] || []);
                        g = ra(g, d);
                        return Vj(c, b, g)(e)
                    }
                }
            }

            function Vj(a, c, b) {
                var d = Zb(a, c);
                return function(e) {
                    return Wj(b, e, !0).then(function() {
                        var f = e.na || {},
                            g = f.Kh,
                            h = void 0 === g ? "" : g;
                        g = f.Ba;
                        var k = void 0 === g ? "" : g;
                        f = f.Lh;
                        f = A(function(l) {
                            return Fa.Sa + "//" + ("" + h + l || jc) + "/" + k
                        }, void 0 === f ? [jc] : f);
                        return d(e, f)
                    }).then(function(f) {
                        var g = f.Rc;
                        f = f.ig;
                        e.Ci = g;
                        e.Gj = f;
                        return Wj(b, e).then(u(g, Q))
                    })
                }
            }

            function Zb(a, c) {
                return function(b, d) {
                    return Xj(a, c, d, b)
                }
            }

            function Xj(a, c, b, d, e, f) {
                var g;
                void 0 === e && (e = 0);
                void 0 === f && (f = 0);
                var h = z({
                        ha: []
                    }, d.ba),
                    k = c[f],
                    l = k[0];
                k = k[1];
                var m = b[e];
                h.Za && h.Za["Content-Type"] || !h.da || (h.Za = z({}, h.Za, (g = {}, g["Content-Type"] = "application/x-www-form-urlencoded", g)), h.da = "site-info=" + ue(h.da));
                h.$c = h.da ? "POST" : "GET";
                h.$a = Ar(a, d, l);
                h.Ba = (d.na || {}).Ba;
                h.ha.push(l);
                z(d.ba, h);
                g = "" + m + (d.Oc && d.Oc.hi ? "/1" : "");
                var p = 0;
                p = Br(a, g, h);
                return k(g, h).then(function(q) {
                    var r = p,
                        t, y;
                    vb(a, (t = {}, t.name = "requestSuccess", t.data = (y = {}, y.body = q, y.requestId = r, y), t));
                    return {
                        Rc: q,
                        ig: e
                    }
                })["catch"](function(q) {
                    var r =
                        p,
                        t, y;
                    vb(a, (t = {}, t.name = "requestFail", t.data = (y = {}, y.error = q, y.requestId = r, y), t));
                    r = f + 1 >= c.length;
                    t = e + 1 >= b.length;
                    r && t && Va(q);
                    return Xj(a, c, b, d, !t && r ? e + 1 : e, r ? 0 : f + 1)
                })
            }

            function Ar(a, c, b) {
                var d = z({}, c.J);
                a = ja(a);
                c.K && (d["browser-info"] = Ja(c.K.l()).D("st", a(mg)).Ha());
                !d.t && (c = c.Ja) && (c.D("ti", b), d.t = c.Ha());
                return d
            }

            function Br(a, c, b) {
                var d, e, f, g = Xa(a),
                    h = b.ha,
                    k = b.da,
                    l = b.Za,
                    m = b.$a;
                b = b.$c;
                vb(a, (d = {}, d.name = "request", d.data = (e = {}, e.url = c, e.requestId = g, e.senderParams = (f = {}, f.rBody = k, f.debugStack = h, f.rHeaders =
                    l, f.rQuery = m, f.verb = b, f), e), d));
                return g
            }

            function Yj(a, c, b, d) {
                a[c] || (a[c] = []);
                b && !ca(d) && Zj(a[c], b, d)
            }

            function Zj(a, c, b) {
                for (var d = [c, b], e = -1E4, f = 0; f < a.length; f += 1) {
                    var g = a[f],
                        h = g[0];
                    g = g[1];
                    if (b === g && h === c) return;
                    if (b < g && b >= e) {
                        a.splice(f, 0, d);
                        return
                    }
                    e = g
                }
                a.push(d)
            }

            function Wj(a, c, b) {
                void 0 === b && (b = !1);
                return new K(function(d, e) {
                    function f(k, l) {
                        l();
                        d()
                    }
                    var g = a.slice();
                    g.push({
                        N: f,
                        Da: f
                    });
                    var h = ec(g, function(k, l) {
                        var m = b ? k.N : k.Da;
                        if (m) try {
                            m(c, l)
                        } catch (p) {
                            h(Cr), e(p)
                        } else l()
                    });
                    h(ak)
                })
            }

            function Tb(a, c,
                b) {
                var d = b || "as";
                if (a.postMessage && !a.attachEvent) {
                    b = fa(a);
                    var e = "__ym__promise_" + Xa(a) + "_" + Xa(a),
                        f = D;
                    d = E(a, d, function(g) {
                        try {
                            var h = g.data
                        } catch (k) {
                            return
                        }
                        h === e && (f(), g.stopPropagation && g.stopPropagation(), c())
                    });
                    f = b.F(a, ["message"], d);
                    a.postMessage(e, "*")
                } else U(a, c, 0, d)
            }

            function uh(a, c, b, d, e) {
                void 0 === d && (d = 1);
                void 0 === e && (e = "itc");
                c = ec(c, b);
                nd(a, c, d)(Ra(E(a, e), D))
            }

            function nd(a, c, b, d) {
                void 0 === b && (b = 1);
                void 0 === d && (d = bk);
                tg = Infinity === b;
                return Ga(function(e, f) {
                    function g() {
                        try {
                            var k = c(d(a, b));
                            h = h.concat(k)
                        } catch (l) {
                            return e(l)
                        }
                        c(Dr);
                        if (c(Td)) return f(h), ck(a);
                        tg ? (c(d(a, 1E4)), f(h), ck(a)) : U(a, g, 100)
                    }
                    var h = [];
                    Er(g)
                })
            }

            function ck(a) {
                if (ug.length) {
                    var c = ug.shift();
                    tg ? c() : U(a, c, 100)
                } else vg = !1
            }

            function Er(a) {
                vg ? ug.push(a) : (vg = !0, a())
            }

            function If(a) {
                return Ga(function(c, b) {
                    b(a)
                })
            }

            function Gp(a) {
                return Ga(function(c, b) {
                    a.then(b, c)
                })
            }

            function Fr(a) {
                var c = [],
                    b = 0;
                return Ga(function(d, e) {
                    x(function(f, g) {
                        f(Ra(d, function(h) {
                            try {
                                c[g] = h, b += 1, b === a.length && e(c)
                            } catch (k) {
                                d(k)
                            }
                        }))
                    }, a)
                })
            }

            function Fp(a) {
                var c = [],
                    b = !1;
                return Ga(function(d, e) {
                    function f(g) {
                        c.push(g) === a.length && d(c)
                    }
                    x(function(g) {
                        g(Ra(f, function(h) {
                            if (!b) try {
                                e(h), b = !0
                            } catch (k) {
                                f(k)
                            }
                        }))
                    }, a)
                })
            }

            function Ra(a, c) {
                return function(b) {
                    return b(a, c)
                }
            }

            function ec(a, c) {
                return Ga({
                    Ta: a,
                    Od: c || Q,
                    ve: !1,
                    wa: 0
                })
            }

            function ak(a) {
                function c() {
                    function d() {
                        b = !0;
                        a.wa += 1
                    }
                    b = !1;
                    a.Od(a.Ta[a.wa], function() {
                        d()
                    });
                    b || (a.wa += 1, d = u(a, ak))
                }
                for (var b = !0; !Td(a) && b;) c()
            }

            function bk(a, c) {
                return function(b) {
                    var d = ja(a),
                        e = d(Z);
                    return dk(function(f, g) {
                        d(Z) - e >= c && g(ek)
                    })(b)
                }
            }

            function wg(a,
                c) {
                return function(b) {
                    var d = ja(a),
                        e = d(Z);
                    return xg(function(f) {
                        d(Z) - e >= c && ek(f)
                    })(b)
                }
            }

            function xg(a) {
                return function(c) {
                    for (var b; c.Ta.length && !Td(c);) b = c.Ta.pop(), b = c.Od(b, c.Ta), a(c);
                    return b
                }
            }

            function Gr(a) {
                Td(a) && Va(Qa("i"));
                var c = a.Od(a.Ta[a.wa]);
                a.wa += 1;
                return c
            }

            function Dr(a) {
                a.ve = !1
            }

            function ek(a) {
                a.ve = !0
            }

            function Cr(a) {
                a.wa = a.Ta.length
            }

            function Td(a) {
                return a.ve || a.Ta.length <= a.wa
            }

            function Cb(a) {
                a = ja(a);
                return Math.round(a(fk) / 50)
            }

            function fk(a) {
                var c = a.Aa,
                    b = c[1];
                a = c[0] && b ? b() : Z(a) - a.Mh;
                return Math.round(a)
            }

            function mg(a) {
                return Math.round(Z(a) / 1E3)
            }

            function rb(a) {
                return Math.floor(Z(a) / 1E3 / 60)
            }

            function Z(a) {
                var c = a.De;
                return 0 !== c ? c : yg(a.l, a.Aa)
            }

            function ig(a) {
                var c = fa(a),
                    b = gk(a),
                    d = {
                        l: a,
                        De: 0,
                        Aa: b,
                        Mh: yg(a, b)
                    },
                    e = b[1];
                b[0] && e || c.F(a, ["beforeunload", "unload"], function() {
                    0 === d.De && (d.De = yg(a, d.Aa))
                });
                return Ga(d)
            }

            function Hr(a) {
                return (10 > a ? "0" : "") + a
            }

            function Wi(a, c, b) {
                function d() {
                    f = 0;
                    g && (g = !1, f = U(a, d, b), e.R(h))
                }
                var e = Kd(a),
                    f, g = !1,
                    h;
                c.F(function(k) {
                    g = !0;
                    h = k;
                    f || d();
                    return D
                });
                return e
            }

            function Ir(a, c) {
                return a.clearInterval(c)
            }

            function Jr(a, c, b, d) {
                return a.setInterval(E(a, "i.err." + (d || "def"), c), b)
            }

            function U(a, c, b, d) {
                return Od(a, E(a, "d.err." + (d || "def"), c), b)
            }

            function ud(a) {
                var c = {};
                return {
                    F: function(b, d) {
                        x(function(e) {
                            n(c, e) || (c[e] = Kd(a));
                            c[e].F(d)
                        }, b);
                        return this
                    },
                    ga: function(b, d) {
                        x(function(e) {
                            n(c, e) && c[e].ga(d)
                        }, b);
                        return this
                    },
                    R: function(b, d) {
                        return n(c, b) ? E(a, "e." + d, c[b].R)(d) : []
                    }
                }
            }

            function Kd(a) {
                var c = [],
                    b = {};
                b.Bj = c;
                b.F = w(Ea("push", c), u(b, Q));
                b.ga = w(wb(Pb(a))(c), wb(Ea("splice", c))(1), u(b, Q));
                b.R = w(Q, wb(ma), Kr(c));
                return b
            }

            function hk(a, c, b, d, e, f) {
                a = Lr(a);
                var g = a.F,
                    h = a.ga;
                f = f ? h : g;
                if (c[f])
                    if (a.Mi) c[f](b, d, e);
                    else c[f]("on" + b, d)
            }

            function B(a, c, b) {
                return function() {
                    return E(arguments[0], a, c, b).apply(this, arguments)
                }
            }

            function E(a, c, b, d, e) {
                var f = Va,
                    g = b || f;
                return function() {
                    var h = d;
                    try {
                        h = g.apply(e || null, arguments)
                    } catch (k) {
                        Cd(a, c, k)
                    }
                    return h
                }
            }

            function yg(a, c) {
                var b = c || gk(a),
                    d = b[0];
                b = b[1];
                return !isNaN(d) && O(b) ? Math.round(b() + d) : a.Date.now ? a.Date.now() : (new a.Date).getTime()
            }

            function gk(a) {
                a = Ed(a);
                var c = n(a, "timing.navigationStart"),
                    b = n(a, "now");
                b && (b = H(b, a));
                return [c, b]
            }

            function Ed(a) {
                return n(a, "performance") || n(a, "webkitPerformance")
            }

            function Cd(a, c, b) {
                var d = "u.a.e",
                    e = "";
                b && ("object" === typeof b ? (b.unk && Va(b), d = b.message, e = "string" === typeof b.stack && b.stack.replace(/\n/g, "\\n") || "n.s.e.s") : d = "" + b);
                Mr(d) || $a(u(d, eb), Nr) || Or(d) && .1 <= a.Math.random() || x(w(Q, Nc(["jserrs", d, c, e]), ma), ik)
            }

            function fe() {
                var a = Pa(arguments);
                return Va(Ta(a))
            }

            function Ta(a) {
                var c = "";
                R(a) ? c = G(".", a) : ia(a) && (c = a);
                return Qa("err.kn(" + Fa.bc + ")" + c)
            }

            function Aj(a) {
                return Qa("http." +
                    a.status + ".st." + a.statusText + ".rt." + ("" + a.responseText).substring(0, 50))
            }

            function Pr(a) {
                this.message = a
            }

            function vb(a, c) {
                if (We(a)) {
                    var b = c.oa;
                    if (b) {
                        var d = b.split(":");
                        b = d[1];
                        d = zg(se(d[0]));
                        if ("1" === b || d) return
                    }
                    b = Qr(a);
                    1E3 === b.length && b.shift();
                    b.push(c)
                }
            }

            function qi(a, c, b) {
                Ag(a, "metrika_enabled", "1", 0, c, b, !0);
                var d = jk(a);
                (d = d && d.metrika_enabled) && kk(a, "metrika_enabled", c, b, !0);
                return !!d
            }

            function Ag(a, c, b, d, e, f, g) {
                void 0 === g && (g = !1);
                if (ri(a, ye, c)) {
                    var h = c + "=" + encodeURIComponent(b) + ";";
                    h += "" + Rr(a);
                    if (d) {
                        var k =
                            new Date;
                        k.setTime(k.getTime() + 6E4 * d);
                        h += "expires=" + k.toUTCString() + ";"
                    }
                    e && (d = e.replace(Sr, ""), h += "domain=" + d + ";");
                    try {
                        a.document.cookie = h + ("path=" + (f || "/")), g || (lk(a)[c] = b)
                    } catch (l) {}
                }
            }

            function ye(a, c) {
                var b = lk(a);
                return b ? b[c] || null : null
            }

            function jk(a) {
                try {
                    var c = a.document.cookie;
                    if (!ca(c)) {
                        var b = {};
                        x(function(d) {
                            d = d.split("=");
                            var e = d[1];
                            b[ab(d[0])] = ab(mk(e))
                        }, (c || "").split(";"));
                        return b
                    }
                } catch (d) {}
                return null
            }

            function ri(a, c, b) {
                return !Bg.length || I(b, Xe) ? !0 : N(function(d, e) {
                    return d && e(a, c, b)
                }, !0, Bg)
            }

            function Fc(a) {
                return a ? w(La, $f(function(c, b) {
                    var d = b[0],
                        e = b[1];
                    X(e) || ca(e) || c.push(d + "=" + ue(e));
                    return c
                }, []), Ce("&"))(a) : ""
            }

            function Tr(a) {
                return a ? w(Wb(function(c) {
                    c = c.split("=");
                    var b = c[1];
                    return [c[0], ca(b) ? void 0 : mk(b)]
                }), $f(function(c, b) {
                    c[b[0]] = b[1];
                    return c
                }, {}))(a.split("&")) : {}
            }

            function mk(a) {
                var c = "";
                try {
                    c = decodeURIComponent(a)
                } catch (b) {}
                return c
            }

            function ue(a) {
                try {
                    return encodeURIComponent(a)
                } catch (c) {}
                a = G("", ha(function(c) {
                    return 55296 >= c.charCodeAt(0)
                }, a.split("")));
                return encodeURIComponent(a)
            }

            function ab(a, c) {
                if (a) {
                    var b = nk ? nk.call(a) : ("" + a).replace(Dj, "");
                    return c && b.length > c ? b.substring(0, c) : b
                }
                return ""
            }

            function xj(a) {
                var c = a.match(ok);
                if (c) {
                    a = c[1];
                    if (c = c[2]) return I(c, Cg) ? c : !1;
                    if (a) return Cg[0]
                }
                return !1
            }

            function S(a) {
                return N(function(c, b) {
                    var d = n(a, "location." + b);
                    c[b] = d ? "" + d : "";
                    return c
                }, {}, Ur)
            }

            function pk(a) {
                return N(function(c, b) {
                    c[ge[b[0]].ea] = b[1];
                    return c
                }, {}, La(a))
            }

            function qc(a) {
                x(function(c) {
                    var b = c[1];
                    ge[c[0]] = {
                        ea: b.ea,
                        Pa: b.Pa
                    }
                }, La(a))
            }

            function km(a, c, b, d, e) {
                var f = th(a, b, d,
                    e);
                a = N(function(g, h) {
                    var k = h[1],
                        l = k.Pa;
                    k = f[k.ea];
                    g[h[0]] = l ? l(k) : k;
                    return g
                }, {}, La(c));
                sj(a, a.X || {});
                return a
            }

            function th(a, c, b, d) {
                var e;
                return ka(a) ? a : (e = {}, e.id = a, e.type = b, e.defer = d, e.params = c, e)
            }

            function Vr(a) {
                a = L(a);
                return rc[a] && rc[a].Ti || null
            }

            function qk(a) {
                a = L(a);
                return rc[a] && rc[a].Si
            }

            function sj(a, c) {
                var b = L(a),
                    d = n(c, "__ym.turbo_page"),
                    e = n(c, "__ym.turbo_page_id");
                rc[b] || (rc[b] = {});
                if (d || e) rc[b].Si = d, rc[b].Ti = e
            }

            function rk(a) {
                return Ye(a) || Bd(a) || /mobile/i.test(lb(a)) || !X(n(a, "orientation"))
            }

            function Af(a, c) {
                if (Ud(a) && c) {
                    var b = lb(a).match(Dg);
                    if (b && b.length) return +b[1] >= c
                }
                return !1
            }

            function Bf(a, c) {
                var b = lb(a);
                return b && (b = b.match(Wr)) && 1 < b.length ? Ha(b[1]) >= c : !1
            }

            function sg(a) {
                return I("prerender", A(u(n(a, "document"), n), ["webkitVisibilityState", "visibilityState"]))
            }

            function Xa(a, c, b) {
                var d = X(b);
                X(c) && d ? (d = 1, c = 1073741824) : d ? d = 1 : (d = c, c = b);
                return a.Math.floor(a.Math.random() * (c - d)) + d
            }

            function Xr() {
                var a = Pa(arguments),
                    c = a[0];
                for (a = a.slice(1); a.length;) {
                    var b = a.shift(),
                        d;
                    for (d in b) Lb(b, d) &&
                        (c[d] = b[d]);
                    Lb(b, "toString") && (c.toString = b.toString)
                }
                return c
            }

            function Yr(a) {
                return function(c) {
                    return c ? a(c) : []
                }
            }

            function sk(a) {
                return X(a) ? [] : Eg(function(c, b) {
                    c.push([b, a[b]]);
                    return c
                }, [], tk(a))
            }

            function tk(a) {
                var c = [],
                    b;
                for (b in a) Lb(a, b) && c.push(b);
                return c
            }

            function se(a) {
                try {
                    return parseInt(a, 10)
                } catch (c) {
                    return null
                }
            }

            function mc(a, c) {
                return a.isFinite(c) && !a.isNaN(c) && "[object Number]" === Object.prototype.toString.call(c)
            }

            function Zr(a) {
                for (var c = [], b = a.length - 1; 0 <= b; --b) c[a.length - 1 - b] = a[b];
                return c
            }

            function ra(a, c) {
                x(w(Q, Ea("push", a)), c);
                return a
            }

            function ze(a, c) {
                return Array.prototype.sort.call(c, a)
            }

            function Ze(a) {
                return a.splice(0, a.length)
            }

            function Ba(a) {
                return a ? R(a) ? a : Vd ? Vd(a) : "number" === typeof a.length && 0 <= a.length ? uk(a) : [] : []
            }

            function $r(a, c) {
                for (var b = 0; b < c.length; b += 1)
                    if (b in c && a.call(c, c[b], b)) return !0;
                return !1
            }

            function as(a, c) {
                return N(function(b, d, e) {
                    d = a(d, e);
                    return b.concat(R(d) ? d : [d])
                }, [], c)
            }

            function vk(a, c) {
                return N(function(b, d, e) {
                    b.push(a(d, e));
                    return b
                }, [], c)
            }

            function bs(a,
                c) {
                if (!Ud(a)) return !0;
                try {
                    c.call({
                        0: !0,
                        length: -Math.pow(2, 32) + 1
                    }, function() {
                        throw 1;
                    })
                } catch (b) {
                    return !1
                }
                return !0
            }

            function cs(a, c) {
                for (var b = "", d = 0; d < c.length; d += 1) b += "" + (d ? a : "") + c[d];
                return b
            }

            function ds(a, c) {
                return 1 <= wk(Aa(a), c).length
            }

            function es(a, c) {
                for (var b = 0; b < c.length; b += 1)
                    if (a.call(c, c[b], b)) return c[b]
            }

            function wk(a, c) {
                return Eg(function(b, d, e) {
                    a(d, e) && b.push(d);
                    return b
                }, [], c)
            }

            function Ad(a, c, b) {
                return b ? a : c
            }

            function fs(a, c) {
                return N(function(b, d, e) {
                    return b ? !!a(d, e) : !1
                }, !0, c)
            }

            function dg(a,
                c, b) {
                try {
                    if (O(c)) {
                        var d = Pa(arguments).slice(3);
                        ca(b) ? c.apply(null, d) : c.apply(b, d)
                    }
                } catch (e) {
                    Od(a, u(e, Va), 0)
                }
            }

            function Va(a) {
                throw a;
            }

            function Od(a, c, b) {
                return Gc("setTimeout", a)(c, b)
            }

            function la(a, c) {
                return Gc("clearTimeout", a)(c)
            }

            function Jd() {
                return []
            }

            function Kc() {
                return {}
            }

            function Gc(a, c) {
                var b = n(c, a),
                    d = n(c, "constructor.prototype." + a) || b;
                try {
                    if (d && d.apply) return function() {
                        return d.apply(c, arguments)
                    }
                } catch (e) {
                    return b
                }
                return d
            }

            function mb(a, c, b) {
                return function() {
                    var d = J(arguments[0]),
                        e = b ? "global" :
                        "m1331",
                        f = d.C(e, {}),
                        g = n(f, a);
                    g || (g = v(c), f[a] = g, d.D(e, f));
                    return g.apply(null, arguments)
                }
            }

            function td(a, c) {
                void 0 === c && (c = {});
                if (!a || 1 > a.length) return c;
                Bb(function(b, d, e) {
                    if (e === a.length - 1) return b;
                    e === a.length - 2 ? b[d] = a[e + 1] : Lb(b, d) || (b[d] = {});
                    return b[d]
                }, c, a);
                return c
            }

            function Wd(a) {
                a = a.Ya = a.Ya || {};
                var c = a._metrika = a._metrika || {};
                return {
                    Ia: function(b, d) {
                        Fg.call(c, b) || (c[b] = d);
                        return this
                    },
                    D: function(b, d) {
                        c[b] = d;
                        return this
                    },
                    C: function(b, d) {
                        var e = c[b];
                        return Fg.call(c, b) || X(d) ? e : d
                    }
                }
            }

            function Lb(a,
                c) {
                return ca(a) ? !1 : Fg.call(a, c)
            }

            function v(a, c) {
                var b = [],
                    d = [];
                var e = c ? c : Q;
                return function() {
                    var f = Pa(arguments),
                        g = e.apply(void 0, f),
                        h = qf(g, d);
                    if (-1 !== h) return b[h];
                    f = a.apply(void 0, f);
                    b.push(f);
                    d.push(g);
                    return f
                }
            }

            function Pb(a) {
                if (Gg) return Gg;
                var c = !1;
                try {
                    c = [].indexOf && 0 === [void 0].indexOf(void 0)
                } catch (d) {}
                var b = a.Array && a.Array.prototype && oa(a.Array.prototype.indexOf, "indexOf");
                a = void 0;
                return Gg = a = c && b ? function(d, e) {
                    return b.call(e, d)
                } : gs
            }

            function gs(a, c) {
                for (var b = 0; b < c.length; b += 1)
                    if (c[b] ===
                        a) return b;
                return -1
            }

            function ma(a, c) {
                return c ? a(c) : a()
            }

            function w() {
                var a = Pa(arguments),
                    c = a.shift();
                return function() {
                    var b = c.apply(void 0, arguments);
                    return N(xk, b, a)
                }
            }

            function $f(a, c) {
                return C([a, c], N)
            }

            function Eg(a, c, b) {
                for (var d = 0, e = b.length; d < e;) c = a(c, b[d], d), d += 1;
                return c
            }

            function gb(a) {
                return Ea("test", a)
            }

            function Ea(a, c) {
                return H(c[a], c)
            }

            function u(a, c) {
                return H(c, null, a)
            }

            function C(a, c) {
                return H.apply(void 0, ie([c, null], a))
            }

            function hs(a) {
                return function() {
                    var c = Pa(arguments);
                    return a.apply(c[0], [c[1]].concat(c.slice(2)))
                }
            }

            function is() {
                var a = Pa(arguments),
                    c = a[0],
                    b = a[1],
                    d = a.slice(2);
                return function() {
                    var e = ie(d, Pa(arguments));
                    if (Function.prototype.call) return Function.prototype.call.apply(c, ie([b], e));
                    if (b) {
                        for (var f = "_b"; b[f];) f += "_" + f.length;
                        b[f] = c;
                        e = b[f] && yk(f, e, b);
                        delete b[f];
                        return e
                    }
                    return yk(c, e)
                }
            }

            function yk(a, c, b) {
                void 0 === c && (c = []);
                b = b || {};
                var d = c.length,
                    e = a;
                O(e) && (e = "d", b[e] = a);
                var f;
                d ? 1 === d ? f = b[e](c[0]) : 2 === d ? f = b[e](c[0], c[1]) : 3 === d ? f = b[e](c[0], c[1], c[2]) : 4 === d && (f = b[e](c[0],
                    c[1], c[2], c[3])) : f = b[e]();
                return f
            }

            function Pa(a) {
                if (Vd) try {
                    return Vd(a)
                } catch (c) {}
                return uk(a)
            }

            function uk(a) {
                for (var c = a.length, b = [], d = 0; d < c; d += 1) b.push(a[d]);
                return b
            }

            function ka(a) {
                return !Wa(a) && !X(a) && "[object Object]" === Object.prototype.toString.call(a)
            }

            function ca(a) {
                return X(a) || Wa(a)
            }

            function O(a) {
                return "function" === typeof a
            }

            function wb(a) {
                return function(c) {
                    return function(b) {
                        return a(b, c)
                    }
                }
            }

            function sa(a) {
                return function(c) {
                    return function(b) {
                        return a(c, b)
                    }
                }
            }

            function xk(a, c) {
                return c(a)
            }

            function Iq(a) {
                return a.replace(/\^/g, "\\^").replace(/\$/g, "\\$").replace(hg, "\\.").replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\|/g, "\\|").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/\?/g, "\\?").replace(/\*/g, "\\*").replace(/\+/g, "\\+").replace(/\{/g, "\\{").replace(/\}/g, "\\}")
            }

            function js(a) {
                return "" + a
            }

            function eb(a, c) {
                return !(!a || -1 === ib(a, c))
            }

            function kc(a, c) {
                return ib(a, c)
            }

            function ks(a, c) {
                for (var b = 0, d = a.length - c.length, e = 0; e < a.length; e += 1) {
                    b = a[e] === c[b] ? b + 1 : 0;
                    if (b === c.length) return e -
                        c.length + 1;
                    if (!b && e > d) break
                }
                return -1
            }

            function ia(a) {
                return "string" === typeof a
            }

            function oa(a, c) {
                return Da(c, a) && a
            }

            function Da(a, c) {
                var b = $e(a, c);
                c && !b && Hg.push([a, c]);
                return b
            }

            function $e(a, c) {
                if (!c || "function" !== typeof c) return !1;
                try {
                    var b = "" + c
                } catch (h) {
                    return !1
                }
                var d = b.length;
                if (d > 35 + a.length) return !1;
                for (var e = d - 13, f = 0, g = 8; g < d; g += 1) {
                    f = "[native code]" [f] === b[g] || 7 === f && "-" === b[g] ? f + 1 : 0;
                    if (12 === f) return !0;
                    if (!f && g > e) break
                }
                return !1
            }

            function D() {}

            function Ig(a, c) {
                Ig = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof
                Array && function(b, d) {
                    b.__proto__ = d
                } || function(b, d) {
                    for (var e in d) d.hasOwnProperty(e) && (b[e] = d[e])
                };
                return Ig(a, c)
            }

            function Hc(a) {
                return !a
            }

            function bb(a, c) {
                return c
            }

            function Q(a) {
                return a
            }

            function Na(a, c) {
                function b() {
                    this.constructor = a
                }
                Ig(a, c);
                a.prototype = null === c ? Object.create(c) : (b.prototype = c.prototype, new b)
            }

            function ie() {
                for (var a = 0, c = 0, b = arguments.length; c < b; c++) a += arguments[c].length;
                a = Array(a);
                var d = 0;
                for (c = 0; c < b; c++)
                    for (var e = arguments[c], f = 0, g = e.length; f < g; f++, d++) a[d] = e[f];
                return a
            }

            function n(a,
                c) {
                return a ? N(function(b, d) {
                    if (ca(b)) return b;
                    try {
                        return b[d]
                    } catch (e) {}
                    return null
                }, a, c.split(".")) : null
            }

            function ls(a) {
                return "[object Array]" === Object.prototype.toString.call(a)
            }

            function ms() {}

            function ns(a, c) {
                return function() {
                    a.apply(c, arguments)
                }
            }

            function Ka(a) {
                if (!(this instanceof Ka)) throw new TypeError("Promises must be constructed via new");
                if ("function" !== typeof a) throw new TypeError("not a function");
                this.Ma = 0;
                this.Je = !1;
                this.Ra = void 0;
                this.Bb = [];
                zk(a, this)
            }

            function Ak(a, c) {
                for (; 3 === a.Ma;) a =
                    a.Ra;
                0 === a.Ma ? a.Bb.push(c) : (a.Je = !0, Ka.Ke(function() {
                    var b = 1 === a.Ma ? c.mi : c.ti;
                    if (null === b)(1 === a.Ma ? Jg : Xd)(c.promise, a.Ra);
                    else {
                        try {
                            var d = b(a.Ra)
                        } catch (e) {
                            Xd(c.promise, e);
                            return
                        }
                        Jg(c.promise, d)
                    }
                }))
            }

            function Jg(a, c) {
                try {
                    if (c === a) throw new TypeError("A promise cannot be resolved with itself.");
                    if (c && ("object" === typeof c || "function" === typeof c)) {
                        var b = c.then;
                        if (c instanceof Ka) {
                            a.Ma = 3;
                            a.Ra = c;
                            Kg(a);
                            return
                        }
                        if ("function" === typeof b) {
                            zk(ns(b, c), a);
                            return
                        }
                    }
                    a.Ma = 1;
                    a.Ra = c;
                    Kg(a)
                } catch (d) {
                    Xd(a, d)
                }
            }

            function Xd(a,
                c) {
                a.Ma = 2;
                a.Ra = c;
                Kg(a)
            }

            function Kg(a) {
                2 === a.Ma && 0 === a.Bb.length && Ka.Ke(function() {
                    a.Je || Ka.yg(a.Ra)
                });
                for (var c = 0, b = a.Bb.length; c < b; c++) Ak(a, a.Bb[c]);
                a.Bb = null
            }

            function os(a, c, b) {
                this.mi = "function" === typeof a ? a : null;
                this.ti = "function" === typeof c ? c : null;
                this.promise = b
            }

            function zk(a, c) {
                var b = !1;
                try {
                    a(function(d) {
                        b || (b = !0, Jg(c, d))
                    }, function(d) {
                        b || (b = !0, Xd(c, d))
                    })
                } catch (d) {
                    b || (b = !0, Xd(c, d))
                }
            }

            function kk(a, c, b, d, e) {
                void 0 === e && (e = !1);
                return Ag(a, c, "", -100, b, d, e)
            }

            function Qc(a, c, b) {
                void 0 === c && (c = "_ym_");
                void 0 === b && (b = "");
                var d = ps(a),
                    e = 1 === (d || "").split(".").length ? d : "." + d,
                    f = b ? "_" + b : "";
                return {
                    pc: function(g, h, k) {
                        kk(a, "" + c + g + f, h || e, k);
                        return this
                    },
                    C: function(g) {
                        return ye(a, "" + c + g + f)
                    },
                    D: function(g, h, k, l, m) {
                        Ag(a, "" + c + g + f, h, k, l || e, m);
                        return this
                    }
                }
            }

            function qb(a, c) {
                if (!c) return null;
                try {
                    return a.JSON.parse(c)
                } catch (b) {
                    return null
                }
            }

            function gc(a) {
                a = "" + a;
                for (var c = 2166136261, b = a.length, d = 0; d < b; d += 1) c ^= a.charCodeAt(d), c += (c << 1) + (c << 4) + (c << 7) + (c << 8) + (c << 24);
                return c >>> 0
            }

            function lm(a, c, b, d) {
                var e = Bk[b];
                return e ?
                    function() {
                        var f = Pa(arguments);
                        try {
                            var g = d.apply(void 0, f);
                            var h = J(a);
                            h.Ia("mt", {});
                            var k = h.C("mt"),
                                l = k[e];
                            k[e] = l ? l + 1 : 1
                        } catch (m) {
                            Va(m)
                        }
                        return g
                    } : d
            }

            function Tc(a, c) {
                var b = qs(a);
                return b ? (b.href = c, {
                    protocol: b.protocol,
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    hash: b.hash,
                    search: b.search,
                    query: b.search.replace(/^\?/, ""),
                    pathname: b.pathname || "/",
                    path: (b.pathname || "/") + b.search,
                    href: b.href
                }) : {}
            }

            function Ck(a) {
                return (a = S(a).hash.split("#")[1]) ? a.split("?")[0] : ""
            }

            function rs(a, c) {
                var b = Ck(a);
                Dk = Jr(a, function() {
                    var d =
                        Ck(a);
                    d !== b && (c(), b = d)
                }, 200, "t.h");
                return H(Ir, null, a, Dk)
            }

            function ss(a, c, b, d) {
                var e, f, g = c.ca,
                    h = c.Ge,
                    k = c.wc,
                    l = J(a),
                    m = Ja((e = {}, e.wh = 1, e.pv = 1, e));
                e = n(d, "isTrusted");
                d && !ca(e) && m.D("ite", tb(e));
                he(g) && a.Ya && a.Ya.Direct && m.D("ad", "1");
                h && m.D("ut", "1");
                g = l.C("lastReferrer");
                d = S(a).href;
                k = {
                    J: (f = {}, f["page-url"] = k || d, f["page-ref"] = g, f),
                    K: m
                };
                b(k, c)["catch"](E(a, "g.s"));
                l.D("lastReferrer", d)
            }

            function ts(a, c, b) {
                function d() {
                    r || (q = !0, t = !1, r = !0, f())
                }

                function e() {
                    m = !0;
                    k(!1);
                    c()
                }

                function f() {
                    la(a, l);
                    if (m) k(!1);
                    else {
                        var M = Math.max(0, b - (t ? y : y + p(Z) - F));
                        M ? l = U(a, e, M, "u.t.d.c") : e()
                    }
                }

                function g() {
                    t = q = r = !0;
                    y += p(Z) - F;
                    F = p(Z);
                    f()
                }

                function h() {
                    q || r || (y = 0);
                    F = p(Z);
                    q = r = !0;
                    t = !1;
                    f()
                }

                function k(M) {
                    M = M ? P.F : P.xb;
                    M(a, ["blur"], g);
                    M(a, ["focus"], h);
                    M(a.document, ["click", "mousemove", "keydown", "scroll"], d)
                }
                var l = 0,
                    m = !1;
                if (qg(a)) return l = U(a, c, b, "u.t.d"), C([a, l], la);
                var p = ja(a),
                    q = !1,
                    r = !1,
                    t = !0,
                    y = 0,
                    F = p(Z),
                    P = fa(a);
                k(!0);
                f();
                return function() {
                    la(a, l);
                    k(!1)
                }
            }

            function lf(a, c, b, d) {
                return function() {
                    if (za(a, c)) {
                        var e = Pa(arguments);
                        return d.apply(void 0,
                            e)
                    }
                }
            }

            function xb(a, c) {
                a = [a[0] >>> 16, a[0] & 65535, a[1] >>> 16, a[1] & 65535];
                c = [c[0] >>> 16, c[0] & 65535, c[1] >>> 16, c[1] & 65535];
                var b = [0, 0, 0, 0];
                b[3] += a[3] * c[3];
                b[2] += b[3] >>> 16;
                b[3] &= 65535;
                b[2] += a[2] * c[3];
                b[1] += b[2] >>> 16;
                b[2] &= 65535;
                b[2] += a[3] * c[2];
                b[1] += b[2] >>> 16;
                b[2] &= 65535;
                b[1] += a[1] * c[3];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[1] += a[2] * c[2];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[1] += a[3] * c[1];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[0] += a[0] * c[3] + a[1] * c[2] + a[2] * c[1] + a[3] * c[0];
                b[0] &= 65535;
                return [b[0] << 16 | b[1], b[2] << 16 | b[3]]
            }

            function sc(a,
                c) {
                a = [a[0] >>> 16, a[0] & 65535, a[1] >>> 16, a[1] & 65535];
                c = [c[0] >>> 16, c[0] & 65535, c[1] >>> 16, c[1] & 65535];
                var b = [0, 0, 0, 0];
                b[3] += a[3] + c[3];
                b[2] += b[3] >>> 16;
                b[3] &= 65535;
                b[2] += a[2] + c[2];
                b[1] += b[2] >>> 16;
                b[2] &= 65535;
                b[1] += a[1] + c[1];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[0] += a[0] + c[0];
                b[0] &= 65535;
                return [b[0] << 16 | b[1], b[2] << 16 | b[3]]
            }

            function ad(a, c) {
                c %= 64;
                if (32 === c) return [a[1], a[0]];
                if (32 > c) return [a[0] << c | a[1] >>> 32 - c, a[1] << c | a[0] >>> 32 - c];
                c -= 32;
                return [a[1] << c | a[0] >>> 32 - c, a[0] << c | a[1] >>> 32 - c]
            }

            function nb(a, c) {
                c %= 64;
                return 0 ===
                    c ? a : 32 > c ? [a[0] << c | a[1] >>> 32 - c, a[1] << c] : [a[1] << c - 32, 0]
            }

            function xa(a, c) {
                return [a[0] ^ c[0], a[1] ^ c[1]]
            }

            function Ek(a) {
                a = xa(a, [0, a[0] >>> 1]);
                a = xb(a, [4283543511, 3981806797]);
                a = xa(a, [0, a[0] >>> 1]);
                a = xb(a, [3301882366, 444984403]);
                return a = xa(a, [0, a[0] >>> 1])
            }

            function us(a, c) {
                void 0 === c && (c = 210);
                var b = a || "",
                    d = c || 0,
                    e = b.length - b.length % 16;
                d = {
                    T: [0, d],
                    V: [0, d]
                };
                for (var f = 0; f < e; f += 16) {
                    var g = d,
                        h = [a.charCodeAt(f + 4) & 255 | (a.charCodeAt(f + 5) & 255) << 8 | (a.charCodeAt(f + 6) & 255) << 16 | (a.charCodeAt(f + 7) & 255) << 24, a.charCodeAt(f) &
                            255 | (a.charCodeAt(f + 1) & 255) << 8 | (a.charCodeAt(f + 2) & 255) << 16 | (a.charCodeAt(f + 3) & 255) << 24
                        ],
                        k = [a.charCodeAt(f + 12) & 255 | (a.charCodeAt(f + 13) & 255) << 8 | (a.charCodeAt(f + 14) & 255) << 16 | (a.charCodeAt(f + 15) & 255) << 24, a.charCodeAt(f + 8) & 255 | (a.charCodeAt(f + 9) & 255) << 8 | (a.charCodeAt(f + 10) & 255) << 16 | (a.charCodeAt(f + 11) & 255) << 24];
                    h = xb(h, af);
                    h = ad(h, 31);
                    h = xb(h, bf);
                    g.T = xa(g.T, h);
                    g.T = ad(g.T, 27);
                    g.T = sc(g.T, g.V);
                    g.T = sc(xb(g.T, [0, 5]), [0, 1390208809]);
                    k = xb(k, bf);
                    k = ad(k, 33);
                    k = xb(k, af);
                    g.V = xa(g.V, k);
                    g.V = ad(g.V, 31);
                    g.V = sc(g.V, g.T);
                    g.V = sc(xb(g.V, [0, 5]), [0, 944331445])
                }
                e = b.length % 16;
                f = b.length - e;
                g = [0, 0];
                h = [0, 0];
                switch (e) {
                    case 15:
                        h = xa(h, nb([0, b.charCodeAt(f + 14)], 48));
                    case 14:
                        h = xa(h, nb([0, b.charCodeAt(f + 13)], 40));
                    case 13:
                        h = xa(h, nb([0, b.charCodeAt(f + 12)], 32));
                    case 12:
                        h = xa(h, nb([0, b.charCodeAt(f + 11)], 24));
                    case 11:
                        h = xa(h, nb([0, b.charCodeAt(f + 10)], 16));
                    case 10:
                        h = xa(h, nb([0, b.charCodeAt(f + 9)], 8));
                    case 9:
                        h = xa(h, [0, b.charCodeAt(f + 8)]), h = xb(h, bf), h = ad(h, 33), h = xb(h, af), d.V = xa(d.V, h);
                    case 8:
                        g = xa(g, nb([0, b.charCodeAt(f + 7)], 56));
                    case 7:
                        g = xa(g,
                            nb([0, b.charCodeAt(f + 6)], 48));
                    case 6:
                        g = xa(g, nb([0, b.charCodeAt(f + 5)], 40));
                    case 5:
                        g = xa(g, nb([0, b.charCodeAt(f + 4)], 32));
                    case 4:
                        g = xa(g, nb([0, b.charCodeAt(f + 3)], 24));
                    case 3:
                        g = xa(g, nb([0, b.charCodeAt(f + 2)], 16));
                    case 2:
                        g = xa(g, nb([0, b.charCodeAt(f + 1)], 8));
                    case 1:
                        g = xa(g, [0, b.charCodeAt(f)]), g = xb(g, af), g = ad(g, 31), g = xb(g, bf), d.T = xa(d.T, g)
                }
                d.T = xa(d.T, [0, b.length]);
                d.V = xa(d.V, [0, b.length]);
                d.T = sc(d.T, d.V);
                d.V = sc(d.V, d.T);
                d.T = Ek(d.T);
                d.V = Ek(d.V);
                d.T = sc(d.T, d.V);
                d.V = sc(d.V, d.T);
                return ("00000000" + (d.T[0] >>> 0).toString(16)).slice(-8) +
                    ("00000000" + (d.T[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (d.V[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (d.V[1] >>> 0).toString(16)).slice(-8)
            }

            function Yd(a, c, b) {
                var d = c.getAttribute("itemtype");
                b = jb('[itemprop~="' + b + '"]', c);
                return d ? ha(function(e) {
                    return e.parentNode && oc("[itemtype]", a, e.parentNode) === c
                }, b) : b
            }

            function hb(a, c, b) {
                return (a = Yd(a, c, b)) && a.length ? a[0] : null
            }

            function cb(a) {
                if (!a) return "";
                a = R(a) ? a : [a];
                return a.length ? a[0].getAttribute("content") || Mb(a[0]) : ""
            }

            function Fk(a) {
                return a ? a.attributes &&
                    a.getAttribute("datetime") ? a.getAttribute("datetime") : cb(a) : ""
            }

            function xd(a, c, b) {
                a = c && (eb(c.className, "ym-disable-keys") || eb(c.className, "-metrika-nokeys"));
                return b && c ? a || !!ur(["ym-disable-keys", "-metrika-nokeys"], c).length : a
            }

            function Lf(a, c) {
                return Te(c) ? "password" === c.type || c.name && I(c.name.toLowerCase(), Gk) || c.id && I(c.id.toLowerCase(), Gk) : !1
            }

            function Hk(a, c) {
                var b = Math.max(0, Math.min(c, 65535));
                ra(a, [b >> 8, b & 255])
            }

            function Vb(a, c) {
                ra(a, [c & 255])
            }

            function kb(a, c, b) {
                return -1 !== Pb(a)(b, vs) ? (Vb(c, b), !1) : !0
            }

            function V(a, c) {
                for (var b = Math.max(0, c | 0); 127 < b;) ra(a, [b & 127 | 128]), b >>= 7;
                ra(a, [b])
            }

            function Lg(a, c) {
                V(a, c.length);
                for (var b = 0; b < c.length; b += 1) V(a, c.charCodeAt(b))
            }

            function Mg(a, c) {
                var b = c;
                255 < b.length && (b = b.substr(0, 255));
                a.push(b.length);
                for (var d = 0; d < b.length; d += 1) Hk(a, b.charCodeAt(d))
            }

            function ws(a, c) {
                var b = [];
                if (kb(a, b, 27)) return [];
                V(b, c);
                return b
            }

            function xs(a, c) {
                var b = Ma(c);
                if (!b) return c[Ya] = -1, null;
                var d = +c[Ya];
                if (!isFinite(d) || 0 >= d) return null;
                if (c.attributes)
                    for (var e = c; e;) {
                        if (e.attributes.mj) return null;
                        e = e.parentElement
                    }
                e = 64;
                var f = Re(a, c),
                    g = f && f[Ya] ? f[Ya] : 0;
                0 > g && (g = 0);
                b = (b || "").toUpperCase();
                var h = ys()[b];
                h || (e |= 2);
                var k = Mj(a, c);
                k || (e |= 4);
                var l = Pf(a, c);
                (f = f ? Pf(a, f) : null) && l[0] === f[0] && l[1] === f[1] && l[2] === f[2] && l[3] === f[3] && (e |= 8);
                Ac[d].yf = l[0] + "x" + l[1];
                Ac[d].size = l[2] + "x" + l[3];
                c.id && "string" === typeof c.id && (e |= 32);
                f = [];
                if (kb(a, f, 1)) return null;
                V(f, d);
                Vb(f, e);
                V(f, g);
                h ? Vb(f, h) : Mg(f, b);
                k && V(f, k);
                e & 8 || (V(f, l[0]), V(f, l[1]), V(f, l[2]), V(f, l[3]));
                e & 32 && Mg(f, c.id);
                Vb(f, 0);
                return f
            }

            function zs(a, c) {
                var b =
                    c[Ya];
                if (!b || 0 > b || !Nf(c) || !c.form || oi(a, c.form)) return [];
                var d = Oj(a, c.form);
                if (0 > d) return [];
                if (Te(c)) {
                    var e = {
                        text: 0,
                        color: 0,
                        oc: 0,
                        qj: 0,
                        "datetime-local": 0,
                        email: 0,
                        wf: 0,
                        Fj: 0,
                        search: 0,
                        Kj: 0,
                        time: 0,
                        url: 0,
                        month: 0,
                        Mj: 0,
                        password: 2,
                        Ej: 3,
                        oj: 4,
                        file: 6,
                        image: 7
                    };
                    e = e[c.type]
                } else {
                    e = {
                        jj: 1,
                        kj: 5
                    };
                    var f = Ma(c);
                    e = X(f) ? "" : e[f]
                }
                if ("number" !== typeof e) return [];
                f = -1;
                for (var g = c.form.elements, h = g.length, k = 0, l = 0; k < h; k += 1)
                    if (g[k].name === c.name) {
                        if (g[k] === c) {
                            f = l;
                            break
                        }
                        l += 1
                    }
                if (0 > f) return [];
                g = [];
                if (kb(a, g, 7)) return [];
                V(g, b);
                V(g,
                    d);
                V(g, e);
                Lg(g, c.name || "");
                V(g, f);
                return g
            }

            function zc(a, c, b) {
                void 0 === b && (b = []);
                for (var d = []; c && !yo(a, c, b); c = Re(a, c)) d.push(c);
                x(function(e) {
                    Ac.counter += 1;
                    var f = Ac.counter;
                    e[Ya] = f;
                    Ac[f] = {};
                    f = xs(a, e);
                    e = zs(a, e);
                    f && e && (ra(b, f), ra(b, e))
                }, As(d));
                return b
            }

            function Bs(a) {
                var c = a.qa;
                if (!wd || c && !c.fromElement) return li(a)
            }

            function Cs(a) {
                var c = a.qa;
                if (c && !c.toElement) return Of(a)
            }

            function Ik(a) {
                var c = Jc(a.qa);
                if (c && xe(c)) {
                    var b = ki(a, c),
                        d = b.concat;
                    var e = Cb(a.l),
                        f = [];
                    kb(a.l, f, 17) ? a = [] : (V(f, e), V(f, c[Ya]), a = f);
                    return d.call(b, a)
                }
            }

            function Jk(a) {
                var c = a.l,
                    b = a.qa.target;
                if (b && xe(b)) {
                    c = zc(c, b);
                    var d = c.concat;
                    var e = Cb(a.l),
                        f = [];
                    kb(a.l, f, 18) ? a = [] : (V(f, e), V(f, b[Ya]), a = f);
                    return d.call(c, a)
                }
            }

            function Kk(a) {
                var c = a.l,
                    b = Jc(a.qa);
                if (!b || Lf(c, b) || xd(c, b)) return [];
                if (Nf(b)) {
                    var d = J(c).C("isEU"),
                        e = Uc(c, b, d),
                        f = e.Va;
                    d = e.qb;
                    e = e.hb;
                    if (Ue(b)) var g = b.checked;
                    else g = b.value, g = f ? G("", Lk(g.split(""))) : g;
                    c = zc(c, b);
                    f = c.concat;
                    var h = Cb(a.l);
                    d = d && !e;
                    e = [];
                    kb(a.l, e, 39) ? a = [] : (V(e, h), V(e, b[Ya]), Mg(e, String(g)), Vb(e, d ? 1 : 0), a = e);
                    return f.call(c,
                        a)
                }
            }

            function cf(a) {
                var c = a.l,
                    b = a.qa,
                    d = Jc(b);
                if (!d || "SCROLLBAR" === d.nodeName) return [];
                var e = [],
                    f = u(e, ra);
                d && xe(d) ? f(ki(a, d)) : f(zc(c, d));
                var g = mj(c, b);
                f = e.concat;
                a = Cb(a.l);
                var h = b.type,
                    k = [g.x, g.y];
                g = b.which;
                b = b.button;
                var l;
                var m = Se(c, d);
                var p = m[0];
                for (m = m[1]; d && (!p || !m);)
                    if (d = Re(c, d)) m = Se(c, d), p = m[0], m = m[1];
                d ? (p = d[Ya], !p || 0 > p ? c = [] : (m = (l = {}, l.mousemove = 2, l.click = 32, l.dblclick = 33, l.mousedown = 4, l.mouseup = 30, l.touch = 12, l)[h]) ? (l = [], d = pg(c, d), kb(c, l, m) ? c = [] : (V(l, a), V(l, p), V(l, Math.max(0, k[0] - d.left)), V(l,
                    Math.max(0, k[1] - d.top)), /^mouse(up|down)|click$/.test(h) && (c = g || b, Vb(l, 2 > c ? 1 : c === (g ? 2 : 4) ? 4 : 2)), c = l)) : c = []) : c = [];
                return f.call(e, c)
            }

            function Ds(a) {
                var c = null,
                    b = a.l,
                    d = b.document;
                if (b.getSelection) {
                    d = void 0;
                    try {
                        d = b.getSelection()
                    } catch (g) {
                        return []
                    }
                    if (Wa(d)) return [];
                    var e = "" + d;
                    c = d.anchorNode
                } else d.selection && d.selection.createRange && (d = d.selection.createRange(), e = d.text, c = d.parentElement());
                if ("string" !== typeof e) return [];
                try {
                    for (; c && 1 !== c.nodeType;) c = c.parentNode
                } catch (g) {
                    return []
                }
                if (!c) return [];
                d =
                    Uc(b, c).Va || xd(b, c, !0);
                c = c.getElementsByTagName("*");
                for (var f = 0; f < c.length && !d;) d = c[f], d = Uc(b, d).Va || xd(b, d, !0), f += 1;
                if (e !== Ng) return Ng = e, d = d ? G("", Lk(e.split(""))) : e, e = Cb(a.l), 0 === d.length ? d = b = "" : 100 >= d.length ? (b = d, d = "") : 200 >= d.length ? (b = d.substr(0, 100), d = d.substr(100)) : (b = d.substr(0, 97), d = d.substr(d.length - 97)), c = [], kb(a.l, c, 29) ? a = [] : (V(c, e), Lg(c, b), Lg(c, d), a = c), a
            }

            function Es(a) {
                return cf(a).concat(Ds(a) || [])
            }

            function Mk(a) {
                return (a.shiftKey ? 2 : 0) | (a.ctrlKey ? 4 : 0) | (a.altKey ? 1 : 0) | (a.metaKey ? 8 : 0) |
                    (a.ctrlKey || a.altKey ? 16 : 0)
            }

            function Nk(a) {
                var c = [];
                Og || (Og = !0, Ng && ra(c, ws(a.l, Cb(a.l))), Tb(a.l, function() {
                    Og = !1
                }, "fv.c"));
                return c
            }

            function Ok(a, c, b, d) {
                c = Jc(c);
                if (!c || Qf(a, c)) return [];
                var e = Uc(a, c),
                    f = e.qb,
                    g = e.hb;
                e = e.Va;
                var h = J(a);
                if (!g && (f && h.C("isEU") || xd(a, c))) a = [];
                else {
                    f = zc(a, c);
                    g = f.concat;
                    var k = Cb(a);
                    h = [];
                    if (kb(a, h, 38)) a = [];
                    else {
                        V(h, k);
                        Hk(h, b);
                        Vb(h, d);
                        a = c[Ya];
                        if (!a || 0 > a) a = 0;
                        V(h, a);
                        Vb(h, e ? 1 : 0);
                        a = h
                    }
                    a = g.call(f, a)
                }
                return a
            }

            function Fs(a) {
                var c = a.l,
                    b = a.qa,
                    d = b.keyCode,
                    e = Mk(b),
                    f = [],
                    g = u(f, ra);
                if ({
                        3: 1,
                        8: 1,
                        9: 1,
                        13: 1,
                        16: 1,
                        17: 1,
                        18: 1,
                        19: 1,
                        20: 1,
                        27: 1,
                        33: 1,
                        34: 1,
                        35: 1,
                        36: 1,
                        37: 1,
                        38: 1,
                        39: 1,
                        40: 1,
                        45: 1,
                        46: 1,
                        91: 1,
                        92: 1,
                        93: 1,
                        106: 1,
                        110: 1,
                        111: 1,
                        144: 1,
                        145: 1
                    }[d] || 112 <= d && 123 >= d || 96 <= d && 105 >= d || e & 16) 19 === d && 4 === (e & -17) && (d = 144), g(Ok(c, b, d, e | 16)), Pg = !1, Tb(c, function() {
                    Pg = !0
                }, "fv.kd"), !(67 === d && e & 4) || e & 1 || e & 2 || g(Nk(a));
                return f
            }

            function Gs(a) {
                var c = a.l;
                a = a.qa;
                var b = [];
                Pg && !Qg && 0 !== a.which && (ra(b, Ok(c, a, a.charCode || a.keyCode, Mk(a))), Qg = !0, Tb(c, function() {
                    Qg = !1
                }, "fv.kp"));
                return b
            }

            function Pk(a) {
                var c = a.l,
                    b = Jc(a.qa);
                if (!b ||
                    oi(c, b)) return [];
                var d = [];
                if ("FORM" === b.nodeName) {
                    for (var e = b.elements, f = 0; f < e.length; f += 1) Nj(e[f]) || ra(d, zc(c, e[f]));
                    a = Cb(a.l);
                    e = Oj(c, b);
                    if (0 > e) c = [];
                    else {
                        f = b.elements;
                        var g = f.length;
                        b = [];
                        for (var h = 0; h < g; h += 1)
                            if (!Nj(f[h])) {
                                var k = f[h][Ya];
                                k && 0 < k && b.push(k)
                            }
                        f = [];
                        if (kb(c, f, 11)) c = [];
                        else {
                            V(f, a);
                            V(f, e);
                            V(f, b.length);
                            for (c = 0; c < b.length; c += 1) V(f, b[c]);
                            c = f
                        }
                    }
                    ra(d, c)
                }
                return d
            }

            function Hs(a) {
                var c = a.flush;
                a = Jc(a.qa);
                "BODY" === Ma(a) && c()
            }

            function Qn(a, c) {
                var b, d = Jc(c),
                    e = Fa.jc,
                    f = Wd(a);
                if (d && ic("ym-advanced-informer",
                        d)) {
                    var g = f.C("ifc", 0) + 1;
                    f.D("ifc", g);
                    g = d.getAttribute("data-lang");
                    var h = Ha(d.getAttribute("data-cid") || "");
                    if (h || 0 === h)(e = n(a, "Ya." + e + ".informer")) ? e((b = {}, b.i = d, b.id = h, b.lang = g, b)) : f.D("ib", !0), b = c || window.event, b.preventDefault ? b.preventDefault() : b.returnValue = !1
                }
            }

            function sh(a, c, b, d) {
                return function() {
                    var e = Pa(arguments);
                    e = d.apply(void 0, e);
                    return X(e) ? za(a, c) : e
                }
            }

            function rh(a, c, b, d) {
                return E(a, "cm." + b, d)
            }

            function jm(a, c, b, d, e) {
                return b.length && e ? C(N(function(f, g, h) {
                    return b[h] ? f.concat(C([a,
                        c, d
                    ], g)) : f
                }, [], b), w)()(e) : e
            }
            var bd = {
                    construct: "Metrika2",
                    callbackPostfix: "2",
                    version: "dgbrch0rsio13bnakr1zjys4f",
                    host: "mc.yandex.ru"
                },
                Hg = [],
                hg = /\./g,
                Qk = oa(String.prototype.indexOf, "indexOf"),
                ib = Qk ? function(a, c) {
                    return Qk.call(a, c)
                } : ks,
                Aa = sa(function(a, c) {
                    return a === c
                }),
                Sc = sa(function(a, c) {
                    a(c);
                    return c
                }),
                Ga = sa(xk),
                Wa = Aa(null),
                X = Aa(void 0),
                Vd = oa(Array.from, "from"),
                Rk = oa(Function.prototype.bind, "bind"),
                H = Rk ? hs(Rk) : is,
                Sk = oa(Array.prototype.reduce, "reduce"),
                Bb = Sk ? function(a, c, b) {
                    return Sk.call(b, a, c)
                } :
                Eg,
                N = Bb,
                hr = w,
                Ge = w(Q, ma),
                Gg, qf = Pb(window),
                fn = wb(qf),
                Fg = Object.prototype.hasOwnProperty,
                J = v(Wd),
                T = wb(n),
                Sa = T("length"),
                Nc = sa(C),
                Vi = sa(Ea),
                Tk = oa(Array.prototype.every, "every"),
                Li = Tk ? function(a, c) {
                    return Tk.call(c, a)
                } : fs,
                Ob = C([1, null], Ad),
                tb = C([1, 0], Ad),
                Gb = Boolean,
                Uk = oa(Array.prototype.filter, "filter"),
                ha = Uk ? function(a, c) {
                    return Uk.call(c, a)
                } : wk,
                ua = u(Gb, ha),
                Is = sa(ha),
                Vk = oa(Array.prototype.find, "find"),
                ub = Vk ? function(a, c) {
                    return Vk.call(c, a)
                } : es,
                Wk = oa(Array.prototype.includes, "includes"),
                I = Wk ? function(a,
                    c, b) {
                    return Wk.call(c, a, b)
                } : ds,
                vc = wb(I),
                Xk = oa(Array.prototype.join, "join"),
                G = Xk ? function(a, c) {
                    return Xk.call(c, a)
                } : cs,
                Ce = sa(G),
                Yk = v(function(a) {
                    var c = n(a, "navigator") || {};
                    a = n(c, "userAgent") || "";
                    c = n(c, "vendor") || "";
                    return {
                        mf: -1 < ib(c, "Apple"),
                        jg: a
                    }
                }),
                lb = v(T("navigator.userAgent")),
                Dg = /Firefox\/([0-9]+)/i,
                Ud = v(function(a) {
                    var c = n(a, "document.documentElement.style"),
                        b = n(a, "InstallTrigger");
                    a = -1 !== (n(a, "navigator.userAgent") || "").toLowerCase().search(Dg);
                    Dg.lastIndex = 0;
                    return !(!(c && "MozAppearance" in c) ||
                        ca(b)) || a
                }),
                Zk = oa(Array.isArray, "isArray"),
                R = Zk ? function(a) {
                    return Zk(a)
                } : ls,
                $k = oa(Array.prototype.map, "map"),
                A = $k && bs(window, Array.prototype.map) ? function(a, c) {
                    return c && 0 < c.length ? $k.call(c, a) : []
                } : vk,
                x = A,
                al = oa(Array.prototype.flatMap, "flatMap"),
                xc = al ? function(a, c) {
                    return al.call(c, a)
                } : as,
                Wb = sa(A),
                Kr = wb(A),
                bl = oa(Array.prototype.some, "some"),
                $a = bl ? function(a, c) {
                    return bl.call(c, a)
                } : $r,
                Me = v(Pb),
                Yc = T("0"),
                Js = sa(ze),
                cl = oa(Array.prototype.reverse, "reverse"),
                As = cl ? function(a) {
                    return cl.call(a)
                } : Zr,
                dl =
                wb(parseInt),
                Ha = dl(10),
                Ae = dl(2),
                el = oa(Object.keys, "keys"),
                fl = oa(Object.entries, "entries"),
                La = fl ? Yr(fl) : sk,
                da = el ? function(a) {
                    return el(a)
                } : tk,
                gl = oa(Object.values, "values"),
                Ks = w(sk, u(T("1"), vk)),
                yh = gl ? function(a) {
                    return gl(a)
                } : Ks,
                z = Object.assign || Xr,
                ji = sa(function(a, c) {
                    return z({}, a, c)
                }),
                qd = v(w(T("String.fromCharCode"), u("fromCharCode", Da), Hc)),
                Ye = v(w(lb, gb(/ipad|iphone|ipod/i))),
                Vf = v(function(a) {
                    return n(a, "navigator.platform") || ""
                }),
                Fd = v(function(a) {
                    a = Yk(a);
                    var c = a.jg;
                    return a.mf && !c.match("CriOS")
                }),
                Ls = gb(/Android.*Version\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]|Android.*Version\/[0-9][0-9.]*\s(?:Mobile\s)?Safari\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]*|; wv\).*Chrome\/[0-9][0-9.]*\sMobile/),
                Ms = gb(/; wv\)/),
                Dd = v(function(a) {
                    a = lb(a);
                    return Ms(a) || Ls(a)
                }),
                Ns = /Chrome\/(\d+)\./,
                Os = v(function(a) {
                    return (a = (n(a, "navigator.userAgent") || "").match(Ns)) && a.length ? 76 <= Ha(a[1]) : !1
                }),
                Bd = v(function(a) {
                    var c = (lb(a) || "").toLowerCase();
                    a = Vf(a);
                    return eb(c, "android") && eb(c, "mobile") && /^android|linux armv/i.test(a)
                }),
                Ps =
                "other none unknown wifi ethernet bluetooth cellular wimax mixed".split(" "),
                Qs = v(function(a) {
                    var c = n(a, "navigator.connection.type");
                    if (X(c)) return null;
                    a = Me(a)(c, Ps);
                    return -1 === a ? c : "" + a
                }),
                qg = v(w(T("document.addEventListener"), Hc)),
                hl = v(function(a) {
                    var c = n(a, "navigator") || {};
                    return N(function(b, d) {
                        return b || n(c, d)
                    }, "", ["language", "userLanguage", "browserLanguage", "systemLanguage"])
                }),
                Dh = v(function(a) {
                    var c = n(a, "navigator") || {};
                    a = hl(a);
                    ia(a) || (a = "", c = n(c, "languages.0"), ia(c) && (a = c));
                    return a.toLowerCase().split("-")[0]
                }),
                sb = v(function(a) {
                    return (n(a, "top") || a) !== a
                }),
                Rs = v(T("top.contentWindow")),
                Ss = v(function(a) {
                    var c = !1;
                    try {
                        c = a.navigator.javaEnabled()
                    } catch (b) {}
                    return c
                }),
                Ts = v(function(a) {
                    var c = "__webdriver_evaluate __selenium_evaluate __webdriver_script_function __webdriver_script_func __webdriver_script_fn __fxdriver_evaluate __driver_unwrapped __webdriver_unwrapped __driver_evaluate __selenium_unwrapped __fxdriver_unwrapped".split(" "),
                        b = n(a, "external");
                    b = n(b, "toString") ? "" + b.toString() : "";
                    b = -1 !== ib(b, "Sequentum");
                    var d = n(a, "document.documentElement"),
                        e = ["selenium", "webdriver", "driver"];
                    return !!($a(u(a, n), ["_selenium", "callSelenium", "_Selenium_IDE_Recorder"]) || $a(u(n(a, "document"), n), c) || b || d && $a(H(d.getAttribute, d), e))
                }),
                Us = v(function(a) {
                    return !!($a(u(a, n), ["_phantom", "__nightmare", "callPhantom"]) || /(PhantomJS)|(HeadlessChrome)/.test(lb(a)) || n(a, "navigator.webdriver") || n(a, "isChrome") && !n(a, "chrome"))
                }),
                Vs = v(function(a) {
                    return !(!n(a, "ia_document.shareURL") || !n(a, "ia_document.referrer"))
                }),
                Zd = v(function(a) {
                    var c =
                        lb(a) || "",
                        b = c.match(/Mac OS X ([0-9]+)_([0-9]+)/);
                    b = b ? [+b[1], +b[2]] : [0, 0];
                    c = c.match(/iPhone OS ([1-9]+)_([0-9]+)/);
                    return 14 <= (c ? +c[1] : 0) ? !0 : (Ye(a) || 10 < b[0] || 10 === b[0] && 13 <= b[1]) && Fd(a)
                }),
                Wr = /Edg\/(\d+)\./,
                Qe = v(function(a) {
                    return Zd(a) || Af(a, 68) || Bf(a, 79)
                }),
                Ws = bd.construct,
                jc = bd.host,
                Rg = qg(window),
                Fa = {
                    ug: 24226447,
                    ng: 26302566,
                    xg: 51533966,
                    hj: 65446441,
                    Sa: "https:",
                    bc: "1331",
                    jc: Ws,
                    sg: Rg ? 512 : 2048,
                    qg: Rg ? 512 : 2048,
                    rg: Rg ? 100 : 400,
                    ij: 100,
                    vg: "noindex"
                },
                $d = [],
                L = v(function(a) {
                    return a.id + ":" + a.ca
                }),
                rc = {},
                he = Aa("1"),
                Xs = setTimeout;
            Ka.prototype["catch"] = function(a) {
                return this.then(null, a)
            };
            Ka.prototype.then = function(a, c) {
                var b = new this.constructor(ms);
                Ak(this, new os(a, c, b));
                return b
            };
            Ka.prototype["finally"] = function(a) {
                var c = this.constructor;
                return this.then(function(b) {
                    return c.resolve(a()).then(function() {
                        return b
                    })
                }, function(b) {
                    return c.resolve(a()).then(function() {
                        return c.reject(b)
                    })
                })
            };
            Ka.all = function(a) {
                return new Ka(function(c, b) {
                    function d(h, k) {
                        try {
                            if (k && ("object" === typeof k || "function" === typeof k)) {
                                var l =
                                    k.then;
                                if ("function" === typeof l) {
                                    l.call(k, function(m) {
                                        d(h, m)
                                    }, b);
                                    return
                                }
                            }
                            e[h] = k;
                            0 === --f && c(e)
                        } catch (m) {
                            b(m)
                        }
                    }
                    if (!a || "undefined" === typeof a.length) return b(new TypeError("Promise.all accepts an array"));
                    var e = Array.prototype.slice.call(a);
                    if (0 === e.length) return c([]);
                    for (var f = e.length, g = 0; g < e.length; g++) d(g, e[g])
                })
            };
            Ka.resolve = function(a) {
                return a && "object" === typeof a && a.constructor === Ka ? a : new Ka(function(c) {
                    c(a)
                })
            };
            Ka.reject = function(a) {
                return new Ka(function(c, b) {
                    b(a)
                })
            };
            Ka.race = function(a) {
                return new Ka(function(c,
                    b) {
                    if (!a || "undefined" === typeof a.length) return b(new TypeError("Promise.race accepts an array"));
                    for (var d = 0, e = a.length; d < e; d++) Ka.resolve(a[d]).then(c, b)
                })
            };
            Ka.Ke = "function" === typeof setImmediate && function(a) {
                setImmediate(a)
            } || function(a) {
                Xs(a, 0)
            };
            Ka.yg = function(a) {
                "undefined" !== typeof console && console && console.warn("Possible Unhandled Promise Rejection:", a)
            };
            var K = window.Promise,
                Ys = oa(K, "Promise"),
                il = oa(n(K, "resolve"), "resolve"),
                jl = oa(n(K, "reject"), "reject"),
                kl = oa(n(K, "all"), "all");
            if (Ys && il && jl &&
                kl) {
                var df = function(a) {
                    return new Promise(a)
                };
                df.resolve = H(il, K);
                df.reject = H(jl, K);
                df.all = H(kl, K);
                K = df
            } else K = Ka;
            var mf = [],
                ld = [],
                W = [],
                Za = [],
                Sg = [],
                Lc = [],
                zg = vc([26812653]),
                Zs = v(w(T("id"), zg), L),
                $b = {
                    id: "id",
                    Ge: "ut",
                    ca: "type",
                    Sd: "ldc",
                    Ua: "nck",
                    wc: "url",
                    kh: "referrer"
                },
                $s = /^\d+$/,
                cd = {
                    id: function(a) {
                        a = "" + (a || "0");
                        $s.test(a) || (a = "0");
                        try {
                            var c = Ha(a)
                        } catch (b) {
                            c = 0
                        }
                        return c
                    },
                    ca: function(a) {
                        return "" + (a || 0 === a ? a : "0")
                    },
                    Ua: Gb,
                    Ge: Gb
                };
            $b.md = "defer";
            cd.md = Gb;
            $b.X = "params";
            cd.X = function(a) {
                return ka(a) || R(a) ? a : null
            };
            $b.Fe = "userParams";
            $b.fg = "triggerEvent";
            cd.fg = Gb;
            $b.Rf = "sendTitle";
            cd.Rf = function(a) {
                return !!a || X(a)
            };
            $b.Ae = "trackHash";
            cd.Ae = Gb;
            $b.dg = "trackLinks";
            $b.Ug = "enableAll";
            var ge = N(function(a, c) {
                    var b = c[0];
                    a[b] = {
                        ea: c[1],
                        Pa: cd[b]
                    };
                    return a
                }, {}, La($b)),
                Ur = "hash host hostname href pathname port protocol search".split(" "),
                Cg = "ru by kz az kg lv md tj tm uz ee fr lt com co.il com.ge com.am com.tr com.ru".split(" "),
                ok = /(?:^|\.)(?:(ya\.ru)|(?:yandex)\.(\w+|com?\.\w+))$/,
                Ke = v(function(a) {
                    return (a ? a.replace(/^www\./,
                        "") : "").toLowerCase()
                }),
                Hi = v(function(a) {
                    a = S(a).hostname;
                    var c = !1;
                    a && (c = -1 !== a.search(ok));
                    return c
                }),
                ll = w(S, T("protocol"), Aa("https:")),
                Rr = v(function(a) {
                    return Os(a) && ll(a) ? "SameSite=None;Secure;" : ""
                }),
                Dj = /^\s+|\s+$/g,
                nk = oa(String.prototype.trim, "trim"),
                Tg = sa(function(a, c) {
                    return c.replace(a, "")
                }),
                Zi = Tg(/\s/g),
                Ub = Tg(/\D/g),
                Xe = ["metrika_enabled"],
                Bg = [],
                lk = mb("gsc", jk),
                Sr = /:\d+$/,
                ps = v(function(a) {
                    var c = (S(a).host || "").split(".");
                    return 1 === c.length ? c[0] : N(function(b, d, e) {
                        e += 1;
                        2 <= e && !b && (e = G(".", c.slice(-e)),
                            qi(a, e) && (b = e));
                        return b
                    }, "", c)
                }),
                Vc = v(Qc),
                We = v(function(a) {
                    var c = Vc(a),
                        b = "1" === c.C("debug"),
                        d = -1 < kc(S(a).href, "_ym_debug=1") || -1 < kc(S(a).href, "_ym_debug=2"),
                        e = a._ym_debug;
                    !e && !d || b || (a = S(a), c.D("debug", "1", void 0, a.host));
                    return !!(b || e || d)
                }),
                Qr = mb("debuggerEvents", Jd, !0),
                Nr = ["http.0.st..rt.", "network error occurred", "send beacon", "Content Security Policy", "DOM Exception 18"],
                ae, Qa = function(a) {
                    return function(c, b) {
                        void 0 === b && (b = !1);
                        if (ae) var d = new ae(c);
                        else Da("Error", a.Error) ? (ae = a.Error, d = new a.Error(c)) :
                            (ae = Pr, d = new ae(c));
                        b && (d.unk = !0);
                        return d
                    }
                }(window),
                Or = gb(/^http./),
                Mr = gb(/^err.kn/),
                ik = [],
                Lr = v(function(a) {
                    a = !(!a.addEventListener || !a.removeEventListener);
                    return {
                        Mi: a,
                        F: a ? "addEventListener" : "attachEvent",
                        ga: a ? "removeEventListener" : "detachEvent"
                    }
                }),
                at = v(function(a) {
                    var c = !1;
                    if (!a.addEventListener) return c;
                    try {
                        var b = Object.defineProperty({}, "passive", {
                            get: function() {
                                c = !0;
                                return 1
                            }
                        });
                        a.addEventListener("test", D, b)
                    } catch (d) {}
                    return c
                }),
                bt = sa(function(a, c) {
                    return a ? z({
                            capture: !0,
                            passive: !0
                        }, c || {}) :
                        !!c
                }),
                fa = v(function(a) {
                    var c = at(a),
                        b = bt(c),
                        d = {};
                    return z(d, {
                        F: function(e, f, g, h) {
                            x(function(k) {
                                var l = b(h);
                                hk(a, e, k, g, l, !1)
                            }, f);
                            return H(d.xb, d, e, f, g, h)
                        },
                        xb: function(e, f, g, h) {
                            x(function(k) {
                                var l = b(h);
                                hk(a, e, k, g, l, !0)
                            }, f)
                        }
                    })
                }),
                ja = v(ig),
                dk = sa(function(a, c) {
                    for (var b = []; !Td(c);) {
                        var d = Gr(c);
                        a(d, function(e) {
                            return e(c)
                        });
                        b.push(d)
                    }
                    return b
                }),
                ml = sa(function(a, c) {
                    return Ga(function(b, d) {
                        return c(b, function(e) {
                            try {
                                d(a(e))
                            } catch (f) {
                                b(f)
                            }
                        })
                    })
                }),
                Ug = sa(function(a, c) {
                    return Ga(function(b, d) {
                        return c(b, function(e) {
                            try {
                                a(e)(Ra(b,
                                    d))
                            } catch (f) {
                                b(f)
                            }
                        })
                    })
                }),
                ug = [],
                vg = !1,
                tg = !1,
                nl = sa(function(a, c) {
                    var b = c || {};
                    return {
                        l: u(b, Q),
                        C: function(d, e) {
                            var f = b[d];
                            return X(f) && !X(e) ? e : f
                        },
                        D: function(d, e) {
                            b[d] = e;
                            return this
                        },
                        Wb: function(d, e) {
                            return "" === e || ca(e) ? this : this.D(d, e)
                        },
                        Ha: u(b, a)
                    }
                }),
                Ja = nl(function(a) {
                    var c = "";
                    a = Bb(function(b, d) {
                        var e = d[0],
                            f = "" + e + ":" + d[1];
                        "t" === e ? c = f : b.push(f);
                        return b
                    }, [], La(a));
                    c && a.push(c);
                    return G(":", a)
                }),
                Vg, Uj = (Vg = {}, Vg.w = [
                    [function(a, c) {
                        return {
                            N: function(b, d) {
                                var e, f = b.J;
                                f = (e = {}, e["page-url"] = f && f["page-url"] ||
                                    "", e.charset = "utf-8", e);
                                "0" !== c.ca && (f["cnt-class"] = c.ca);
                                b.K || (b.K = Ja());
                                e = b.K;
                                var g = b.ba;
                                f = {
                                    na: {
                                        Ba: "watch/" + c.id
                                    },
                                    ba: z(void 0 === g ? {} : g, {
                                        Ab: !!e.C("pv") && !e.C("ar") && !e.C("wh")
                                    }),
                                    J: z(b.J || {}, f)
                                };
                                z(b, f);
                                d()
                            }
                        }
                    }, 1]
                ], Vg),
                Wg = u(Uj, Yj),
                ob = Sd("w"),
                Tj = ["webkitvisibilitychange", "visibilitychange"],
                wf = nl(function(a) {
                    a = La(a);
                    return G("", A(function(c) {
                        var b = c[0];
                        c = c[1];
                        return Wa(c) ? "" : b + "(" + c + ")"
                    }, a))
                }),
                ol = "A B BIG BODY BUTTON DD DIV DL DT EM FIELDSET FORM H1 H2 H3 H4 H5 H6 HR I IMG INPUT LI OL P PRE SELECT SMALL SPAN STRONG SUB SUP TABLE TBODY TD TEXTAREA TFOOT TH THEAD TR U UL ABBR AREA BLOCKQUOTE CAPTION CENTER CITE CODE CANVAS DFN EMBED FONT INS KBD LEGEND LABEL MAP OBJECT Q S SAMP STRIKE TT ARTICLE AUDIO ASIDE FOOTER HEADER MENU METER NAV PROGRESS SECTION TIME VIDEO NOINDEX NOBR MAIN svg circle clippath ellipse defs foreignobject g glyph glyphref image line lineargradient marker mask path pattern polygon polyline radialgradient rect set text textpath title".split(" "),
                Jq = /^\s*(data|javascript):/i,
                pj = new RegExp(G("", ["\\.(" + G("|", "3gp 7z aac ac3 acs ai avi ape apk asf bmp bz2 cab cdr crc32 css csv cue divx dmg djvu? doc(x|m|b)? emf eps exe flac? flv iso swf gif t?gz jpe?g? js m3u8? m4a mp(3|4|e?g?) m4v md5 mkv mov msi ods og(g|m|v) psd rar rss rtf sea sfv sit sha1 svg tar tif?f torrent ts txt vob wave? wma wmv wmf webm ppt(x|m|b)? xls(x|m|b)? pdf phps png xpi g?zip".split(" ")) + ")$"]), "i"),
                Ua, Bk = (Ua = {}, Ua.hit = "h", Ua.params = "p", Ua.reachGoal = "g", Ua.userParams = "up",
                    Ua.trackHash = "th", Ua.accurateTrackBounce = "atb", Ua.notBounce = "nb", Ua.addFileExtension = "fe", Ua.extLink = "el", Ua.file = "fc", Ua.trackLinks = "tl", Ua.destruct = "d", Ua.setUserID = "ui", Ua.getClientID = "ci", Ua.clickmap = "cm", Ua.enableAll = "ea", Ua),
                ct = v(function() {
                    var a = 0;
                    return function() {
                        return a += 1
                    }
                }),
                dt = w(L, ct, ma),
                lg = {
                    mc: function(a) {
                        a = Wd(a).C("mt", {});
                        a = La(a);
                        return a.length ? N(function(c, b, d) {
                            return "" + c + (d ? "-" : "") + b[0] + "-" + b[1]
                        }, "", a) : null
                    },
                    clc: function(a) {
                        var c = J(a).C("cls", {
                                ic: 0,
                                x: 0,
                                y: 0
                            }),
                            b = c.ic,
                            d = c.x;
                        c = c.y;
                        return b ? b + "-" + a.Math.floor(d / b) + "-" + a.Math.floor(c / b) : b + "-" + d + "-" + c
                    },
                    rqnt: function(a, c, b) {
                        a = b.J;
                        return !a || a.nohit ? null : dt(c)
                    }
                },
                zr = v(function(a) {
                    Rj(a, "_ymBRC", "1");
                    var c = "1" !== Qj(a, "_ymBRC");
                    c || Sj(a, "_ymBRC");
                    return c
                }),
                Oa = v(Pj),
                dd = v(Pj, function(a, c, b) {
                    return "" + c + b
                }),
                et = v(T("document.documentElement")),
                ft = v(function(a) {
                    a = n(a, "document") || {};
                    return ("" + (a.characterSet || a.charset || "")).toLowerCase()
                }),
                fb = v(w(T("document"), u("createElement", Gc))),
                pi = v(function(a) {
                    var c = n(a, "Element.prototype");
                    return c ?
                        (a = ub(function(b) {
                            var d = c[b];
                            return !!d && Da(b, d)
                        }, ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"])) ? c[a] : null : null
                }),
                gt = Aa("INPUT"),
                Te = w(Ma, gt),
                ht = Aa("TEXTAREA"),
                wr = w(Ma, ht),
                it = Aa("SELECT"),
                xr = w(Ma, it),
                Ue = w(T("type"), gb(/^(checkbox|radio)$/)),
                Nf = w(Ma, gb(/^INPUT|SELECT|TEXTAREA$/)),
                xe = w(Ma, gb(/^INPUT|SELECT|TEXTAREA|BUTTON$/)),
                Rf = "INPUT CHECKBOX RADIO TEXTAREA SELECT PROGRESS".split(" "),
                vr = ["submit", "image", "hidden"],
                Fe = v(function() {
                    for (var a = 59, c = {},
                            b = 0; b < ol.length; b += 1) c[ol[b]] = String.fromCharCode(a), a += 1;
                    return c
                }),
                Lj = v(function(a) {
                    return {
                        tj: a,
                        ib: null,
                        rb: []
                    }
                }),
                Jj = {},
                og = {};
            Jj.p = 500;
            var Ij = {
                i: "id",
                n: "name",
                h: "href",
                ty: "type"
            };
            og.h = !0;
            og.c = !0;
            var $c = {};
            $c.p = vf;
            $c.c = function(a, c, b) {
                (a = ab(n(c, "textContent"))) && b && (b = b(c), b.length && $a(w(T("textContent"), ab, Aa(a)), b) && (a = ""));
                Te(c) && (a = ab(c.getAttribute && c.getAttribute("value") || a));
                return a
            };
            var ed, ng = "button," + G(",", A(function(a) {
                    return 'input[type="' + a + '"]'
                }, ["button", "submit", "reset", "file"])) +
                ",a",
                Zf = u(ng, jb),
                tr = (ed = {}, ed.A = "h", ed.BUTTON = "i", ed.DIV = "i", ed.INPUT = "ty", ed),
                pl = /\/$/,
                Hj = mb("r", function(a, c) {
                    var b = Gj(a, c),
                        d = b[0];
                    return !b[1] && d
                }),
                Qd = v(function() {
                    return {
                        Ga: {},
                        pending: {},
                        children: {}
                    }
                }),
                Xg = T("postMessage"),
                jt = B("s.f", function(a, c, b, d, e) {
                    c = c(d);
                    var f = Qd(a),
                        g = G(":", [c.meta.oc, c.meta.key]);
                    if (Xg(b)) {
                        f.pending[g] = e;
                        try {
                            b.postMessage(c.Zf, "*")
                        } catch (h) {
                            delete f.pending[g];
                            return
                        }
                        U(a, function() {
                            delete f.pending[g]
                        }, 5E3, "if.s")
                    }
                }),
                kt = B("s.fh", function(a, c, b, d, e, f) {
                    var g = null,
                        h = null,
                        k =
                        Qd(a),
                        l = null;
                    try {
                        g = qb(a, f.data), h = g.__yminfo, l = g.data
                    } catch (m) {
                        return
                    }
                    if (!ca(h) && h.substring && "__yminfo" === h.substring(0, 8) && !ca(l) && (g = h.split(":"), 4 === g.length))
                        if (h = c.id, c = g[1], a = g[2], g = g[3], !R(l) && l.type && "0" === g && l.counterId) {
                            if (!l.toCounter || l.toCounter == h) {
                                k = null;
                                try {
                                    k = f.source
                                } catch (m) {}!Wa(k) && Xg(k) && (f = d.R(l.type, [f, l]), e = A(w(Q, ji(e)), f.concat([{}])), l = b([c, a, l.counterId], e), k.postMessage(l.Zf, "*"))
                            }
                        } else g === "" + h && R(l) && ha(function(m) {
                                return !(!m.hid || !m.counterId)
                            }, l).length === l.length &&
                            (b = k.pending[G(":", [c, a])]) && b.apply(null, [f].concat(l))
                }),
                rd = v(function(a, c) {
                    var b, d = Gc("getElementsByTagName", n(a, "document")),
                        e = Qd(a),
                        f = Xg(a),
                        g = ud(a),
                        h = fa(a);
                    if (!d || !f) return null;
                    d = d.call(a.document, "iframe");
                    f = (b = {}, b.counterId = c.id, b.hid = "" + Dc(a), b);
                    Qe(a) && (f.duid = Rd(a, c));
                    pr(a, g);
                    qr(a);
                    b = rr(a, f);
                    var k = C([a, u([], b)], jt);
                    x(function(l) {
                        var m = null;
                        try {
                            m = l.contentWindow
                        } catch (p) {}
                        m && k(m, {
                            type: "initToChild"
                        }, function(p, q) {
                            g.R("initToParent", [p, q])
                        })
                    }, d);
                    sb(a) && k(a.parent, {
                        type: "initToParent"
                    }, function(l,
                        m) {
                        g.R("parentConnect", [l, m])
                    });
                    h.F(a, ["message"], C([a, c, b, g, f], kt));
                    return {
                        $: g,
                        Ga: e.Ga,
                        children: e.children,
                        oe: k
                    }
                }, w(bb, L)),
                sd = v(function(a, c) {
                    if (!Qe(a) || !sb(a)) return Rd(a, c);
                    var b = rd(a, c);
                    return b && b.Ga[c.id] ? b.Ga[c.id].info.duid || Rd(a, c) : Rd(a, c)
                }, function(a, c) {
                    return "{" + c.Sd + c.Ua
                }),
                lt = v(w(ja, Ga(function(a) {
                    return -(new a.l.Date).getTimezoneOffset()
                }))),
                mt = w(ja, Ga(function(a) {
                    a = new a.l.Date;
                    return G("", A(Hr, [a.getFullYear(), a.getMonth() + 1, a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds()]))
                })),
                nt = w(ja, Ga(mg)),
                ql = v(w(ja, Ga(function(a) {
                    return a.Aa[0]
                }))),
                ot = v(function(a) {
                    a = J(a);
                    var c = a.C("counterNum", 0) + 1;
                    a.D("counterNum", c);
                    return c
                }, w(bb, L)),
                qa, Pd = (qa = {}, qa.vf = u(bd.version, Q), qa.nt = Qs, qa.fu = function(a, c, b) {
                        var d = b.J;
                        if (!d) return null;
                        c = (n(a, "document.referrer") || "").replace(pl, "");
                        b = (d["page-ref"] || "").replace(pl, "");
                        d = d["page-url"];
                        a = S(a).href !== d;
                        c = c !== b;
                        b = 0;
                        a && c ? b = 3 : c ? b = 1 : a && (b = 2);
                        return b
                    }, qa.en = ft, qa.la = hl, qa.ut = function(a, c, b) {
                        var d = b.M;
                        b = b.J;
                        d = d && d.Hc;
                        b && (Hi(a) || c.Ge || d) && (b.ut =
                            Fa.vg);
                        return null
                    }, qa.v = u(Fa.bc, Q), qa.cn = ot, qa.dp = function(a) {
                        var c = J(a),
                            b = c.C("bt", {});
                        if (X(c.C("bt"))) {
                            var d = n(a, "navigator.getBattery");
                            try {
                                b.p = d && d.call(a.navigator)
                            } catch (e) {}
                            c.D("bt", b);
                            b.p && b.p.then && b.p.then(E(a, "bi:dp.p", function(e) {
                                b.aj = n(e, "charging") && 0 === n(e, "chargingTime")
                            }))
                        }
                        return tb(b.aj)
                    }, qa.ls = v(function(a, c) {
                        var b = dd(a, c.id),
                            d = ja(a),
                            e = b.C("lsid");
                        return +e ? e : (d = Xa(a, 0, d(Z)), b.D("lsid", d), d)
                    }, bb), qa.hid = Dc, qa.phid = function(a, c) {
                        if (!sb(a)) return null;
                        var b = rd(a, c);
                        if (!b) return null;
                        var d = da(b.Ga);
                        return d.length ? b.Ga[d[0]].info.hid : null
                    }, qa.z = lt, qa.i = mt, qa.et = nt, qa.c = w(T("navigator.cookieEnabled"), Ob), qa.rn = w(Q, Xa), qa.rqn = function(a, c, b) {
                        b = b.J;
                        if (!b || b.nohit) return null;
                        c = L(c);
                        a = dd(a, c);
                        c = (a.C("reqNum", 0) || 0) + 1;
                        a.D("reqNum", c);
                        if (a.C("reqNum") === c) return c;
                        a.pc("reqNum");
                        return null
                    }, qa.u = sd, qa.w = function(a) {
                        a = Pc(a);
                        return a[0] + "x" + a[1]
                    }, qa.s = function(a) {
                        var c = n(a, "screen");
                        if (c) {
                            a = n(c, "width");
                            var b = n(c, "height");
                            c = n(c, "colorDepth") || n(c, "pixelDepth");
                            return G("x", [a, b, c])
                        }
                        return null
                    },
                    qa.sk = T("devicePixelRatio"), qa.ifr = w(sb, Ob), qa.j = w(Ss, Ob), qa.sti = function(a) {
                        return sb(a) && Rs(a) ? "1" : null
                    }, qa),
                or = v(function() {
                    return ra(da(Pd), da(lg))
                }),
                nr = v(Kc, L),
                Ej = v(function() {
                    return {
                        We: null,
                        ta: []
                    }
                }, L),
                kr = /^[a-z][\w.+-]+:/i,
                Yg, Yb = [
                    [Ve, 1],
                    [Pe, 2],
                    [Qb(), 3],
                    [Fj, 4]
                ],
                Oe = [],
                yb = u(Yb, Zj),
                Xb = (Yg = {}, Yg.h = Yb, Yg),
                aa = u(Xb, Yj);
            yb(Bj, -100);
            var fr = /[^a-z0-9.:-]/,
                Zg, $g = {},
                rl = ua([jg && [jg, 0], Eb && [Eb, 1],
                    [Fb, 2], Nd && [Nd, 3],
                    [Zc, 4]
                ]),
                tc = ua([jg, Eb, Fb, Nd, Zc]),
                ah = [Fb];
            ah.unshift(Eb);
            ah.push(Nd);
            var sl = ua(ah),
                fd = ua([Zc]);
            ua([Eb, Fb]);
            var pt = ua([Eb, Zc]),
                tl = ua([Eb, Fb, Nd, Zc]),
                ya = (Zg = {}, Zg.h = sl, Zg),
                bh = v(function(a, c) {
                    var b = $g["*"] ? $g["*"] : c && $g[c];
                    b || (b = c ? ya[c] || [] : tc);
                    b = N(function(d, e) {
                        var f = e(a);
                        if (f) {
                            var g = ub(w(Yc, Aa(e)), rl);
                            g && d.push([g[1], f])
                        }
                        return d
                    }, [], b);
                    b.length || fe();
                    return b
                }, bb),
                ch, qt = H(K.reject, K, Ta()),
                Ca = (ch = {}, ch.h = ob, ch),
                va = B("g.sen", function(a, c, b) {
                    var d = bh(a, c);
                    b = b ? jr(a, c, b) : [];
                    var e = Ca[c],
                        f = e ? e(a, d, b) : ob(a, d, b);
                    return function() {
                        var g = Pa(arguments),
                            h = g[0];
                        g = g.slice(1);
                        var k = h.ba;
                        h = z(h, {
                            ba: z(void 0 ===
                                k ? {} : k, {
                                    ha: [c]
                                })
                        });
                        return f.apply(null, [h].concat(g))
                    }
                }, qt),
                Yq = sa(function(a, c) {
                    if (!c[a]) {
                        var b, d = new K(function(e) {
                            b = e
                        });
                        c[a] = {
                            Ff: b,
                            promise: d,
                            Gf: !1
                        }
                    }
                    return c[a].promise
                }),
                yj = v(w(Kc, Ga)),
                rt = B("dc.init", function(a, c) {
                    return c && zg(se(c.split(":")[0])) ? {
                        log: D,
                        warn: D,
                        error: D
                    } : Xq(a, c)
                }),
                pc = v(rt, bb),
                nm = B("h.p", function(a, c) {
                    var b, d, e = va(a, "h", c),
                        f = c.wc || "" + S(a).href,
                        g = c.kh || a.document.referrer,
                        h = {
                            K: Ja((b = {}, b.pv = 1, b)),
                            J: (d = {}, d["page-url"] = f, d["page-ref"] = g, d),
                            M: {}
                        };
                    h.M.X = c.X;
                    h.M.Fe = c.Fe;
                    c.md && h.J && (h.J.nohit =
                        "1");
                    return e(h, c).then(function(k) {
                        var l;
                        k && (c.md || nc(a, c, "h", (l = {}, l.id = c.id, l.url = f, l.ref = g, l), c.X)(), Tb(a, C([a, c, k], Zq)))
                    })["catch"](E(a, "h.g.s"))
                }),
                dh = ["yandex_metrika_callback" + bd.callbackPostfix, "yandex_metrika_callbacks" + bd.callbackPostfix],
                st = B("cb.i", function(a) {
                    var c = dh[0],
                        b = dh[1];
                    if (O(a[c])) a[c]();
                    "object" === typeof a[b] && x(function(d, e) {
                        a[b][e] = null;
                        dg(a, d)
                    }, a[b]);
                    x(function(d) {
                        try {
                            delete a[d]
                        } catch (e) {
                            a[d] = void 0
                        }
                    }, dh)
                }),
                Vq = /^[a-zA-Z0-9'!#$%&*+-/=?^_`{|}~]+$/,
                ul = v(function(a) {
                    return !!n(a,
                        "crypto.subtle.digest") && !!n(a, "TextEncoder") && !!n(a, "FileReader") && !!n(a, "Blob")
                }),
                Wq = Tg(/[^\d+()]/g),
                Tq = ["yandex_cid", "yandex_public_id"],
                tt = B("fpm", function(a, c) {
                    if (!ll(a)) return D;
                    var b = L(c);
                    if (!ul(a)) return Kb(a, b, "ns"), D;
                    var d = za(a, c);
                    return d ? function(e) {
                        return (new K(function(f, g) {
                            return ka(e) ? da(e).length ? f(vj(a, e).then(function(h) {
                                var k, l;
                                h && h.length && d.params((k = {}, k.__ym = (l = {}, l.fpp = h, l), k))
                            }, D)) : g(Ta("fpm.l")) : g(Ta("fpm.o"))
                        }))["catch"](E(a, "fpm.en"))
                    } : D
                }),
                ef = sa(function(a, c) {
                    var b = {};
                    gg(a)(function(d) {
                        b = d[c] || {}
                    });
                    return b
                }),
                ut = B("c.c.cc", function(a) {
                    var c = J(a),
                        b = w(ef(a), function(d) {
                            var e, f = (e = {}, e.clickmap = !!d.clickmap, e);
                            return z({}, d, f)
                        });
                    return E(a, "g.c.cc", w(H(c.C, c, "counters", {}), da, Wb(b)))
                }),
                vt = B("gt.c.rs", function(a, c) {
                    var b, d = L(c),
                        e = c.id,
                        f = c.ca,
                        g = c.Kg,
                        h = c.Ae,
                        k = C([a, d], Rq);
                    fg(a, d, (b = {}, b.id = e, b.type = +f, b.clickmap = g, b.trackHash = !!h, b));
                    return k
                }),
                tj = v(Jd),
                Md = v(Kc, L),
                wt = B("pa.int", function(a, c) {
                    var b;
                    return b = {}, b.params = function() {
                        var d, e, f, g = Pa(arguments),
                            h = Qq(g);
                        if (!h) return null;
                        g = h.Pg;
                        var k = h.X;
                        h = h.cc;
                        if (!ka(k) && !R(k)) return null;
                        var l = va(a, "1", c),
                            m = Md(c).url,
                            p = !Zs(c),
                            q = "pa",
                            r = (d = {}, d.id = c.id, d);
                        d = k;
                        var t = "";
                        if (t = n(k, "__ym.user_id")) q = "pau", r.uid = t;
                        I("__ymu", da(k)) && (q = "paup");
                        d.__ym && (d = z({}, k), d.__ym = N(function(y, F) {
                            var P = n(k, "__ym." + F);
                            P && (y[F] = P);
                            return y
                        }, {}, $d), da(d.__ym).length || delete d.__ym, p = !!da(d).length);
                        d = t ? void 0 : JSON.stringify(d);
                        d = nc(a, c, q, r, d);
                        l = l({
                            M: {
                                X: k
                            },
                            K: Ja((e = {}, e.pa = 1, e.ar = 1, e)),
                            J: (f = {}, f["page-url"] = m || S(a).href, f)
                        }, c).then(p ? d : D);
                        return Xc(a, "p.s",
                            l, h, g)
                    }, b
                }),
                re = v(rj, w(bb, L)),
                xt = B("y.p", function(a, c) {
                    var b = rj(a, c);
                    if (b) {
                        var d = ne(a),
                            e = C([a, b, c], Mq);
                        Fh(a, d, function(f) {
                            f.F(["params"], e)
                        });
                        b.$.F(["params"], w(T("1"), e))
                    }
                }),
                qs = v(function(a) {
                    if (a = fb(a)) return a("a")
                }),
                vl = {
                    xj: gb(/[/&=?#]/)
                },
                He = B("go.in", function(a, c, b, d) {
                    var e;
                    void 0 === b && (b = "goal");
                    return e = {}, e.reachGoal = function(f, g, h, k) {
                        var l, m, p;
                        if (!f || vl[b] && vl[b](f)) return null;
                        var q = g,
                            r = h || D;
                        O(g) && (r = g, q = void 0, k = h);
                        var t = nc(a, c, "gr", (l = {}, l.id = c.id, l.goal = f, l), q),
                            y = "goal" === b;
                        g = va(a, "g", c);
                        l = Lq(a, c, f, b);
                        h = l[0];
                        l = l[1];
                        q = g({
                            M: {
                                X: q
                            },
                            K: Ja((m = {}, m.ar = 1, m)),
                            J: (p = {}, p["page-url"] = h, p["page-ref"] = l, p)
                        }, c).then(function() {
                            var F, P;
                            y && t();
                            vb(a, (F = {}, F.counterKey = L(c), F.name = "event", F.data = (P = {}, P.schema = b, P.name = f, P), F));
                            d && d()
                        });
                        return Xc(a, "g.s", q, r, k)
                    }, e
                }),
                yt = B("guid.int", function(a, c) {
                    var b;
                    return b = {}, b.getClientID = function(d) {
                        var e = Rd(a, c);
                        d && dg(a, d, null, e);
                        return e
                    }, b
                }),
                Dk, zt = B("th.e", function(a, c) {
                    function b() {
                        g || (k = Lb(a, "onhashchange") ? fa(a).F(a, ["hashchange"], h) : rs(a, h))
                    }
                    var d, e = va(a,
                            "t", c),
                        f = Ne(a, L(c)),
                        g = !1,
                        h = E(a, "h.h.ch", H(ss, null, a, c, e)),
                        k = D;
                    c.Ae && (b(), g = !0);
                    e = E(a, "tr.hs.h", function(l) {
                        var m;
                        l ? b() : k();
                        g = !!l;
                        f((m = {}, m.trackHash = g, m))
                    });
                    return d = {}, d.trackHash = e, d.u = k, d
                }),
                At = sa(function(a, c) {
                    ia(c) ? a.push(c) : x(w(Q, Ea("push", a)), c)
                }),
                Ld = mb("retryReqs", function(a) {
                    var c = Oa(a),
                        b = c.C("retryReqs", {}),
                        d = ja(a)(Z);
                    x(function(e) {
                        var f = e[0];
                        e = e[1];
                        (!e || !e.time || e.time + 864E5 < d) && delete b[f]
                    }, La(b));
                    c.D("retryReqs", b);
                    return b
                }, !0),
                eh = w(kc, Aa(0)),
                wl = wb(eh),
                Bt = [wl("watch"), wl("clmap")],
                Ct =
                B("g.r", function(a) {
                    var c = ja(a),
                        b = Ld(a),
                        d = c(Z),
                        e = Dc(a);
                    return Bb(function(f, g) {
                        var h = g[0],
                            k = g[1];
                        k && $a(Ga(k.resource), Bt) && !k.d && k.ghid && k.ghid !== e && k.time && 500 < d - k.time && k.time + 864E5 > d && 2 >= k.browserInfo.rqnl && (k.d = 1, h = {
                            protocol: k.protocol,
                            host: k.host,
                            Ba: k.resource,
                            yi: k.postParams,
                            X: k.params,
                            Cg: k.browserInfo,
                            vj: k.ghid,
                            time: k.time,
                            Tb: Ha(h),
                            Ng: k.counterId,
                            ca: k.counterType
                        }, k.telemetry && (h.Ja = k.telemetry), f.push(h));
                        return f
                    }, [], La(b))
                }),
                Dt = B("nb.p", function(a, c) {
                    function b(F) {
                        l() || (F = "number" === typeof F ?
                            F : 15E3, y = ts(a, d(!1), F), m())
                    }

                    function d(F) {
                        return function(P) {
                            var M, na, wa;
                            void 0 === P && (P = (M = {}, M.ctx = {}, M.callback = D, M));
                            if (F || !r && !k.Ld) {
                                r = !0;
                                m();
                                y && y();
                                var Db = p(Z);
                                M = (Ha(k.C("lastHit")) || 0) < Db - 18E5;
                                var Id = .1 > Math.random();
                                k.D("lastHit", Db);
                                Db = Ja((na = {}, na.nb = 1, na.cl = t, na.ar = 1, na));
                                na = Md(c);
                                na = {
                                    J: (wa = {}, wa["page-url"] = na.url || S(a).href, wa),
                                    K: Db,
                                    M: {
                                        force: F
                                    }
                                };
                                wa = pc(a, L(c)).warn;
                                !P.callback && P.ctx && wa("nbnc");
                                (wa = F || M || Id) || (wa = a.location.href, M = a.document.referrer, wa = !(wa && M ? qj(wa) === qj(M) : !wa && !M));
                                if (wa) return wa = g(na, c), Xc(a, "l.o.l", wa, P.callback, P.ctx)
                            }
                            return null
                        }
                    }
                    var e, f, g = va(a, "n", c),
                        h = L(c),
                        k = dd(a, c.id),
                        l = u(u(h, ef(a)), w(ma, T("accurateTrackBounce"))),
                        m = u((e = {}, e.accurateTrackBounce = !0, e), Ne(a, h)),
                        p = ja(a),
                        q = p(Z),
                        r = !1,
                        t = 0,
                        y;
                    pa(c, function(F) {
                        t = F.dh - q
                    });
                    c.Le && b(c.Le);
                    e = (f = {}, f.notBounce = d(!0), f.u = y, f);
                    e.accurateTrackBounce = b;
                    return e
                }),
                Eq = sa(ic)("(ym-disable-clickmap|ym-clickmap-ignore)"),
                Et = B("clm.p", function(a, c) {
                    if (qd(a)) return D;
                    var b = va(a, "m", c),
                        d = L(c),
                        e = ja(a),
                        f = e(Z),
                        g = u(u(d, ef(a)), w(ma,
                            T("clickmap"))),
                        h, k = null;
                    d = E(a, "clm.p.c", function(l) {
                        var m = g();
                        if (m) {
                            var p = J(a),
                                q = p.C("cls", {
                                    ic: 0,
                                    x: 0,
                                    y: 0
                                });
                            p.D("cls", {
                                ic: q.ic + 1,
                                x: q.x + l.clientX,
                                y: q.y + l.clientY
                            });
                            p = "object" === typeof m ? m : {};
                            q = p.filter;
                            m = p.isTrackHash || !1;
                            var r = A(function(y) {
                                return ("" + y).toUpperCase()
                            }, p.ignoreTags || []);
                            X(h) && (h = p.quota || null);
                            var t = !!p.quota;
                            l = {
                                element: Fq(a, l),
                                position: mj(a, l),
                                button: Gq(l),
                                time: e(Z)
                            };
                            p = S(a).href;
                            if (Dq(a, l, k, r, q)) {
                                if (t) {
                                    if (!h) return;
                                    --h
                                }
                                r = Se(a, l.element);
                                q = r[0];
                                r = r[1];
                                t = pg(a, l.element);
                                q = ["rn", Xa(a),
                                    "x", Math.floor(65535 * (l.position.x - t.left) / (q || 1)), "y", Math.floor(65535 * (l.position.y - t.top) / (r || 1)), "t", Math.floor((l.time - f) / 100), "p", vf(a, l.element), "X", l.position.x, "Y", l.position.y
                                ];
                                q = G(":", q);
                                m && (q += ":wh:1");
                                Cq(a, p, q, b, c);
                                k = l
                            }
                        }
                    });
                    return fa(a).F(n(a, "document"), ["click"], d)
                }),
                Ft = B("trigger.in", function(a, c) {
                    c.fg && Tb(a, C([a, "yacounter" + c.id + "inited"], yr), "t.i")
                }),
                Gt = B("c.m.p", function(a, c) {
                    var b, d = L(c);
                    return b = {}, b.clickmap = u(Ne(a, d), Bq), b
                }),
                Oi = u("form", oc),
                jq = u("form", jb),
                Aq = v(w(bb, wb(pa)(T("settings.form_goals"))),
                    bb),
                Ht = B("s.f.i", function(a, c) {
                    var b, d = [],
                        e = [],
                        f = fa(a);
                    d.push(f.F(a, ["click"], E(a, "s.f.c", C([a, c, e], zq))));
                    d.push(f.F(a, ["submit"], E(a, "s.f.e", function(g) {
                        var h = n(g, "target");
                        g = n(g, "isTrusted");
                        jj(!0, a, c, e, h, g)
                    })));
                    kj(a, c, "fgi", (b = {}, b.id = c.id, b));
                    return C([Ge, d], x)
                }),
                It = B("s.f.i", function(a, c) {
                    return pa(c, function(b) {
                        var d;
                        if (n(b, "settings.button_goals")) return b = fa(a).F(a, ["click"], E(a, "c.t.c", w(C([a, c], lf(a, c, "", yq))))), nc(a, c, "gbi", (d = {}, d.id = c.id, d))(), b
                    })
                }),
                ac, be, fh, gd, Hb, ag = (ac = {}, ac.transaction_id =
                    "id", ac.item_brand = "brand", ac.index = "position", ac.item_variant = "variant", ac.value = "revenue", ac.item_category = "category", ac.item_list_name = "list", ac),
                lc = (be = {}, be.item_id = "id", be.item_name = "name", be.promotion_name = "coupon", be),
                xq = (fh = {}, fh.promotion_name = "name", fh),
                xl = (gd = {}, gd.promotion_name = "name", gd.promotion_id = "id", gd.item_id = "product_id", gd.item_name = "product_name", gd),
                uq = "currencyCode add delete remove purchase checkout detail impressions click promoView promoClick".split(" "),
                vq = (Hb = {}, Hb.view_item = {
                    event: "detail",
                    xa: lc,
                    La: "products"
                }, Hb.add_to_cart = {
                    event: "add",
                    xa: lc,
                    La: "products"
                }, Hb.remove_from_cart = {
                    event: "remove",
                    xa: lc,
                    La: "products"
                }, Hb.begin_checkout = {
                    event: "checkout",
                    xa: lc,
                    La: "products"
                }, Hb.purchase = {
                    event: "purchase",
                    xa: lc,
                    La: "products"
                }, Hb.view_item_list = {
                    event: "impressions",
                    xa: lc
                }, Hb.select_item = {
                    event: "click",
                    La: "products",
                    xa: lc
                }, Hb.view_promotion = {
                    event: "promoView",
                    La: "promotions",
                    xa: xl
                }, Hb.select_promotion = {
                    event: "promoClick",
                    La: "promotions",
                    xa: xl
                }, Hb),
                ij = B("dl.w", function(a, c, b) {
                    function d() {
                        var g =
                            n(a, c);
                        (e = R(g) && Le(a, g, b)) || (f = U(a, d, 1E3, "ec.dl"))
                    }
                    var e, f = 0;
                    d();
                    return function() {
                        return la(a, f)
                    }
                }),
                Jt = B("p.e", function(a, c) {
                    var b = za(a, c);
                    if (b) {
                        var d = J(a);
                        b = b.params;
                        var e = E(a, "h.ee", C([a, L(c), b], sq));
                        return c.sd ? (d.D("ecs", 0), hj(a, c.sd, e)) : pa(c, function(f) {
                            if ((f = n(f, "settings.ecommerce")) && ia(f)) return d.D("ecs", 1), hj(a, f, e)
                        })
                    }
                }),
                ej = v(function(a) {
                    return G("[^\\d<>]*", a.split(""))
                }),
                Hn = v(function(a) {
                    return new RegExp(ej(a), "g")
                }),
                pq = /\S/,
                Yi = u(["style", "display:inline;margin:0;padding:0;font-size:inherit;color:inherit;line-height:inherit"],
                    td),
                yl = v(function(a) {
                    return qd(a) || !od(a)
                }),
                Kt = B("phc.h", function(a, c) {
                    if (!rk(a) && !yl(a)) return pa(c, function(b) {
                        if (!n(b, "settings.phchange")) {
                            var d = Oa(a),
                                e = eb(S(a).search, "_ym_hide_phones=1") || d.C("hide_phones", 0);
                            b = n(b, "settings.phhide");
                            e && !b && (b = ["*"], d.D("hide_phones", 1));
                            b && Qi(a, c, b)
                        }
                    })["catch"](E(a, "phc.hs"))
                }),
                zl = v(function(a) {
                    a = S(a);
                    a = Tr(a.search.substring(1));
                    a["_ym_status-check"] = a["_ym_status-check"] || "";
                    a._ym_lang = a._ym_lang || "ru";
                    return a
                }),
                Ti = w(zl, T("_ym_status-check"), Ha),
                Lt = w(zl,
                    T("_ym_lang")),
                gq = /^http:\/\/([\w\-.]+\.)?webvisor\.com\/?$/,
                hq = /^https:\/\/([\w\-.]+\.)?metri[kc]a\.yandex\.(ru|by|kz|com|com\.tr)\/?$/,
                Si = gb(/^https:\/\/(yastatic\.net\/s3\/metrika|s3\.mds\.yandex\.net\/internal-metrika-betas|[\w-]+\.dev\.webvisor\.com|[\w-]+\.dev\.metrika\.yandex\.ru)\/(\w|-|\/|(\.)(?!\.))+\.js$/),
                lq = ["form", "button", "phone", "status"],
                gh = [],
                iq = v(function(a, c, b) {
                    x(w(Nc([a, c, b]), ma), gh);
                    if (b.inline) {
                        c = Ri(b);
                        var d = b.data;
                        b = b.id;
                        Ni(a, c, void 0 === b ? "" : b, void 0 === d ? "" : d)
                    } else b.resource &&
                        Si(b.resource) && (a._ym__postMessageEvent = c, a._ym__inpageMode = b.inpageMode, a._ym__initMessage = b.initMessage, mq(a, b.resource))
                }, function(a, c, b) {
                    return b.id
                }),
                Mt = B("cs.init", function(a, c) {
                    var b, d = Ti(a);
                    if (d && c.id === d && "0" === c.ca) {
                        var e = Ri((b = {}, b.lang = Lt(a), b.fileId = "status", b));
                        U(a, C([a, e, "" + d], Ni), 0, "cs")
                    }
                }),
                Nt = B("suid.int", function(a, c) {
                    var b;
                    return b = {}, b.setUserID = function(d, e, f) {
                        if (ia(d) || mc(a, d)) {
                            var g = za(a, c);
                            d = td(["__ym", "user_id", d]);
                            g.params(d, e || D, f)
                        } else pc(a, L(c)).error("wuid")
                    }, b
                }),
                Wc = {
                    position: "absolute"
                },
                Mi = {
                    position: "fixed"
                },
                Yf = {
                    borderRadius: "50%"
                },
                Ot = mb("siteStatistics", function(a, c) {
                    if (!rk(a)) return Nb(a)(Ra(D, C([c, w(T("settings.sm"), Aa(1), C([C([a, c.id], eq), D], Ad), ma)], pa)))
                }),
                Pt = B("up.int", function(a, c) {
                    var b;
                    return b = {}, b.userParams = E(a, "up.c", function(d, e, f) {
                        var g, h = za(a, c),
                            k = pc(a, L(c)).warn;
                        h ? ka(d) ? (d = (g = {}, g.__ymu = d, g), (g = h.params) && g(d, e || D, f)) : k("wup") : k("nci")
                    }), b
                }),
                Qt = /[\*\.\?\(\)]/g,
                Rt = v(function(a, c, b) {
                    var d;
                    try {
                        var e = b.replace("\\s", " ").replace(Qt, "");
                        pc(a, "").warn("nnw",
                            (d = {}, d.name = e, d))
                    } catch (f) {}
                }, bb),
                St = B("r.nn", function(a) {
                    We(a) && Le(a, Hg, function(c) {
                        c.za.F(function(b) {
                            Rt(a, b[1], b[0]);
                            Hg.splice(100)
                        })
                    })
                }),
                Tt = B("e.a.p", function(a, c) {
                    var b, d = za(a, c);
                    d = C([w(Q, Ga(!0)), ua(A(u(d, n), ["clickmap", "trackLinks", "accurateTrackBounce"]))], A);
                    c.Ug && d();
                    return b = {}, b.enableAll = d, b
                }),
                Ut = v(Kc, L),
                Vt = B("fpi", function(a) {
                    var c = Ed(a);
                    if (c && !a.document.hidden) {
                        var b = J(a).Ia;
                        b("fpe", 1);
                        var d = fa(a).F(a, ["visibilitychange", "webkitvisibilitychange"], function() {
                            a.document.hidden && (b("fht",
                                c.now()), d())
                        })
                    }
                }),
                Wt = v(function(a) {
                    a = n(a, "console");
                    var c = n(a, "log");
                    c = $e("log", c) ? H(c, a) : D;
                    var b = n(a, "warn");
                    b = $e("warn", b) ? H(b, a) : c;
                    var d = n(a, "error");
                    a = $e("error", d) ? H(d, a) : c;
                    return {
                        log: c,
                        error: a,
                        warn: b
                    }
                }),
                Xt = u("add", De),
                Yt = u("remove", De),
                Zt = u("detail", De),
                $t = u("purchase", De),
                au = "FB_IAB FBAV OKApp GSA/ yandex yango uber EatsKit YKeyboard iOSAppUslugi YangoEats PassportSDK".split(" "),
                tf = v(function(a) {
                    var c = Yk(a);
                    a = c.jg;
                    if (!c.mf) return !1;
                    c = Ea("indexOf", a);
                    c = $a(w(c, Aa(-1), Hc), au);
                    var b = /CFNetwork\/[0-9][0-9.]*.*Darwin\/[0-9][0-9.]*/.test(a),
                        d = /YaBrowser\/[\d.]+/.test(a),
                        e = /Mobile/.test(a);
                    return c || b || d && e || !/Safari/.test(a) && e
                }),
                jn = v(function(a) {
                    var c = lb(a);
                    return c ? eb(c, "YangoEats") || Dd(a) : !1
                }),
                cq = /([0-9\\.]+) Safari/,
                bu = /\sYptp\/\d\.(\d+)\s/,
                Al = v(function(a) {
                    var c;
                    a: {
                        if ((c = lb(a)) && (c = bu.exec(c)) && 1 < c.length) {
                            c = Ha(c[1]);
                            break a
                        }
                        c = 0
                    }
                    return 50 <= c && 99 >= c || Bf(a, 79) ? !1 : !Zd(a) || tf(a)
                }),
                Bl = "monospace;sans-serif;serif;Andale Mono;Arial;Arial Black;Arial Hebrew;Arial MT;Arial Narrow;Arial Rounded MT Bold;Arial Unicode MS;Bitstream Vera Sans Mono;Book Antiqua;Bookman Old Style;Calibri;Cambria;Cambria Math;Century;Century Gothic;Century Schoolbook;Comic Sans;Comic Sans MS;Consolas;Courier;Courier New;Garamond;Geneva;Georgia;Helvetica;Helvetica Neue;Impact;Lucida Bright;Lucida Calligraphy;Lucida Console;Lucida Fax;LUCIDA GRANDE;Lucida Handwriting;Lucida Sans;Lucida Sans Typewriter;Lucida Sans Unicode;Microsoft Sans Serif;Monaco;Monotype Corsiva;MS Gothic;MS Outlook;MS PGothic;MS Reference Sans Serif;MS Sans Serif;MS Serif;MYRIAD;MYRIAD PRO;Palatino;Palatino Linotype;Segoe Print;Segoe Script;Segoe UI;Segoe UI Light;Segoe UI Semibold;Segoe UI Symbol;Tahoma;Times;Times New Roman;Times New Roman PS;Trebuchet MS;Verdana;Wingdings;Wingdings 2;Wingdings 3".split(";"),
                cu = v(function(a) {
                    a = fb(a)("canvas");
                    var c = n(a, "getContext");
                    if (!c) return null;
                    try {
                        var b = H(c, a)("2d");
                        b.font = "72px mmmmmmmmmmlli";
                        var d = b.measureText("mmmmmmmmmmlli").width;
                        return function(e) {
                            b.font = "72px " + e;
                            return b.measureText("mmmmmmmmmmlli").width === d
                        }
                    } catch (e) {
                        return null
                    }
                }),
                Cl = oa(String.prototype.repeat, "repeat"),
                gi = Cl ? function(a, c) {
                    return Cl.call(a, c)
                } : $p,
                ai = u(!0, function(a, c, b, d) {
                    b = c.length && (b - d.length) / c.length;
                    if (0 >= b) return d;
                    c = gi(c, b);
                    return a ? c + d : d + c
                }),
                af = [2277735313, 289559509],
                bf = [1291169091,
                    658871167
                ],
                du = B("p.cd", function(a) {
                    if (Bd(a) || Ye(a)) {
                        var c = Oa(a);
                        if (ca(c.C("jn"))) {
                            c.D("jn", !1);
                            var b = a.chrome || Fd(a) ? function() {} : /./;
                            a = Wt(a);
                            b.toString = function() {
                                c.D("jn", !0);
                                return "Yandex.Metrika counter is initialized"
                            };
                            a.log("%c%s", "color: inherit", b)
                        }
                    }
                }),
                eu = v(function(a) {
                    a = n(a, "navigator.plugins");
                    return !!(a && Sa(a) && $a(w(T("name"), gb(/Chrome PDF Viewer/)), a))
                }),
                Rb = sa(function(a, c) {
                    return J(c).C(a, null)
                }),
                Xp = {
                    "*": "+",
                    "-": "/",
                    lj: "=",
                    "+": "*",
                    "/": "-",
                    "=": "_"
                },
                fu = v(function(a) {
                    return O(n(a, "yandex.getSiteUid")) ?
                        a.yandex.getSiteUid() : null
                }),
                gu = v(u("panoramaId", Be)),
                hu = v(function(a) {
                    return Be("pubcid.org", a) || Be("_pubCommonId", a)
                }),
                iu = v(u("_sharedid", Be)),
                ju = v(function(a, c) {
                    if (c.Ua) return null;
                    var b = Qc(a, "").C("_ga");
                    return b && md(le(b))
                }, w(bb, L)),
                Tp = [
                    ["domainLookupEnd", "domainLookupStart"],
                    ["connectEnd", "connectStart"],
                    ["responseStart", "requestStart"],
                    ["responseEnd", "responseStart"],
                    ["fetchStart", "navigationStart"],
                    ["redirectEnd", "redirectStart"],
                    [function(a, c) {
                        return n(c, "redirectCount") || n(a, "navigation.redirectCount")
                    }],
                    ["domInteractive", "domLoading"],
                    ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
                    ["domComplete", "navigationStart"],
                    ["loadEventStart", "navigationStart"],
                    ["loadEventEnd", "loadEventStart"],
                    ["domContentLoadedEventStart", "navigationStart"]
                ],
                zb, Sp = [
                    ["domainLookupEnd", "domainLookupStart"],
                    ["connectEnd", "connectStart"],
                    ["responseStart", "requestStart"],
                    ["responseEnd", "responseStart"],
                    ["fetchStart"],
                    ["redirectEnd", "redirectStart"],
                    ["redirectCount"],
                    ["domInteractive", "responseEnd"],
                    ["domContentLoadedEventEnd",
                        "domContentLoadedEventStart"
                    ],
                    ["domComplete"],
                    ["loadEventStart"],
                    ["loadEventEnd", "loadEventStart"],
                    ["domContentLoadedEventStart"]
                ],
                Ji = (zb = {}, zb.responseEnd = 1, zb.domInteractive = 1, zb.domContentLoadedEventStart = 1, zb.domContentLoadedEventEnd = 1, zb.domComplete = 1, zb.loadEventStart = 1, zb.loadEventEnd = 1, zb.unloadEventStart = 1, zb.unloadEventEnd = 1, zb.secureConnectionStart = 1, zb),
                Vp = v(Jd),
                Pp = v(Kc),
                Qp = v(function(a) {
                    var c = n(a, "webkitRequestFileSystem");
                    if (O(c) && !Bd(a)) return (new K(H(c, a, 0, 0))).then(function() {
                        var d =
                            n(a, "navigator.storage") || {};
                        return d.estimate ? d.estimate() : {}
                    }).then(function(d) {
                        return (d = d.quota) && 12E7 > d ? !0 : !1
                    })["catch"](u(!0, Q));
                    if (Ud(a)) return c = n(a, "navigator.serviceWorker"), K.resolve(X(c));
                    c = n(a, "openDatabase");
                    if (Fd(a) && O(c)) {
                        var b = !1;
                        try {
                            c(null, null, null, null)
                        } catch (d) {
                            b = !0
                        }
                        return K.resolve(b)
                    }
                    return K.resolve(!n(a, "indexedDB") && (n(a, "PointerEvent") || n(a, "MSPointerEvent")))
                }),
                ku = /(\?|&)turbo_uid=([\w\d]+)($|&)/,
                lu = v(function(a, c) {
                    var b = Vc(a),
                        d = S(a).search.match(ku);
                    return d && 2 <= d.length ?
                        (d = d[2], c.Ua || b.D("turbo_uid", d), d) : (b = b.C("turbo_uid")) ? b : ""
                }),
                Ap = [
                    [
                        ["'(-$&$&$'", 30102, 0],
                        ["'(-$&$&$'", 29009, 0]
                    ],
                    [
                        ["oWdZ[nc[jh_YW$Yec", 30103, 1],
                        ["oWdZ[nc[jh_YW$Yec", 29010, 1]
                    ]
                ],
                Bp = [
                    [
                        ["oWdZ[nc[jh_YW$Yec", 30103, 1]
                    ],
                    [
                        ["oWdZ[nc[jh_YW$Yec", 29010, 1]
                    ]
                ],
                Ii = {
                    J: {
                        t: 'UV|L7,!"T[rwe&D_>ZIb\\aW#98Y.PC6k'
                    }
                },
                xp = {
                    ag: 60,
                    error: 15
                },
                wp = {
                    ag: 5,
                    error: 1
                },
                Gi = {
                    id: 42822899,
                    ca: "0"
                },
                mu = B("pa.plgn", function(a, c) {
                    var b = re(a, c);
                    b && b.$.F(["pluginInfo"], E(a, "c.plgn", function() {
                        var d = J(a);
                        d.D("cmc", d.C("cmc", 0) + 1);
                        return pk(c)
                    }))
                }),
                Sb, pb, bn = (Sb = {}, Sb.am = "com.am", Sb.tr = "com.tr", Sb.ge = "com.ge", Sb.il = "co.il", Sb["\u0440\u0444"] = "ru", Sb["xn--p1ai"] = "ru", Sb["\u0431\u0435\u043b"] = "by", Sb["xn--90ais"] = "by", Sb),
                Dl = {
                    "mc.edadeal.ru": /^([^/]+\.)?edadeal\.ru$/,
                    "mc.yandexsport.ru": /^([^/]+\.)?yandexsport\.ru$/,
                    "mc.kinopoisk.ru": /^([^/]+\.)?kinopoisk\.ru$/
                },
                cn = (pb = {}, pb.ka = "ge", pb.ro = "md", pb.tg = "tj", pb.tk = "tm", pb.et = "ee", pb.hy = "com.am", pb.he = "co.li", pb.ky = "kg", pb.be = "by", pb.tr = "com.tr", pb.kk = "kz", pb),
                El = /^https?:\/\//,
                nu = {
                    1882689622: 1,
                    2318205080: 1,
                    3115871109: 1,
                    3604875100: 1,
                    339366994: 1,
                    2890452365: 1,
                    849340123: 1,
                    173872646: 1,
                    2343947156: 1,
                    655012937: 1,
                    3724710748: 1,
                    3364370932: 1,
                    1996539654: 1,
                    2065498185: 1,
                    823651274: 1,
                    12282461: 1,
                    1555719328: 1,
                    1417229093: 1,
                    138396985: 1,
                    3015043526: 1
                },
                Fl = v(function() {
                    return N(function(a, c) {
                        var b = gc(c + "/tag.js");
                        a[b] = 1;
                        return a
                    }, {}, ["mc.yandex.ru/metrika", "mc.yandex.com/metrika", "cdn.jsdelivr.net/npm/yandex-metrica-watch"])
                }),
                ou = v(function(a) {
                    a = Ed(a);
                    if (!a || !O(a.getEntriesByType)) return null;
                    a = a.getEntriesByType("resource");
                    var c = Fl();
                    return (a = ub(function(b) {
                        b = b.name.replace(El, "").split("?")[0];
                        b = gc(b);
                        return c[b]
                    }, a)) ? tb(a.transferSize) : null
                }),
                Kp = "ar:1:pv:1:v:" + Fa.bc + ":vf:" + bd.version,
                Lp = Fa.Sa + "//" + jc + "/watch/" + Fa.ng,
                Gl = {},
                pu = B("exps.int", function(a, c) {
                    var b;
                    return b = {}, b.experiments = function(d, e, f) {
                        var g, h;
                        void 0 === e && (e = D);
                        if (d && 0 < d.length) {
                            var k = va(a, "e", c),
                                l = Md(c).url;
                            d = k({
                                K: Ja((g = {}, g.ex = 1, g.ar = 1, g)),
                                J: (h = {}, h["page-url"] = l || S(a).href, h.exp = d, h)
                            }, c);
                            return Xc(a, "exps.s", d, e, f)
                        }
                    }, b
                }),
                uf = [],
                qu = B("p.fh", function(a,
                    c) {
                    var b, d;
                    void 0 === c && (c = !0);
                    var e = Oa(a),
                        f = ja(a),
                        g = e.C("wasSynced"),
                        h = {
                            id: 3,
                            ca: "0"
                        };
                    return c && g && g.time + 864E5 > f(Z) ? K.resolve(g) : va(a, "f", h)({
                        K: Ja((b = {}, b.pv = 1, b)),
                        J: (d = {}, d["page-url"] = S(a).href, d["page-ref"] = a.document.referrer, d)
                    }, h).then(function(k) {
                        var l;
                        k = (l = {}, l.time = f(Z), l.params = n(k, "settings"), l.bkParams = n(k, "userData"), l);
                        e.D("wasSynced", k);
                        return k
                    })["catch"](E(a, "f.h"))
                }),
                ru = sa(function(a, c) {
                    0 === parseFloat(n(c, "settings.c_recp")) && (a.Td.D("ymoo" + a.oa, a.cg(rb)), a.nd && a.nd.destruct && a.nd.destruct())
                }),
                zf = w(T("settings.pcs"), Aa("1")),
                Hl = jc.split("."),
                su = Hl.pop(),
                Il = G(".", Hl),
                an = v(function(a) {
                    a = S(a).hostname.split(".");
                    return a[a.length - 1]
                }),
                Ch = v(function(a) {
                    return -1 !== S(a).hostname.search(/(?:^|\.)(?:ya|yandex|beru|kinopoisk|edadeal)\.(?:\w+|com?\.\w+)$/)
                }),
                tu = /^(.*\.)?((yandex(-team)?)\.(com?\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\.ru|ya\.(ru|cc)|yadi\.sk|yastatic\.net|.*\.yandex|turbopages\.org|turbo\.site|diplodoc\.(com|tech)|datalens\.tech)$/,
                qe = v(function(a) {
                    a = S(a).hostname;
                    var c = !1;
                    a && (c = -1 !== a.search(tu));
                    return c
                }),
                uu = /^(.*\.)?((yandex(-team)?)\.(com?\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\.ru|ya\.(ru|cc)|yadi\.sk|.*\.yandex|turbopages\.org|turbo\.site)$/,
                Dp = v(function(a) {
                    a = S(a).hostname;
                    var c = !1;
                    a && (c = -1 !== a.search(uu));
                    return c
                }),
                Jl = Fa.Sa + "//" + jc + "/metrika",
                ve = Jl + "/metrika_match.html",
                ff, Hp = (ff = {}, ff.s = "p", ff["8"] = "i", ff),
                Ep = mb("csp", function(a, c) {
                    return va(a, "s", c)({}, ["https://ymetrica1.com/watch/3/1"])
                }),
                hh = "et w v z i u vf".split(" "),
                Kl = Sd("wv"),
                vu = Sd("pub"),
                vi = function() {
                    function a(c,
                        b) {
                        this.l = c;
                        this.type = b
                    }
                    a.isEnabled = function(c) {
                        return !!c.JSON
                    };
                    a.prototype.Ha = function(c) {
                        return If(Ab(this.l, c))
                    };
                    a.prototype.ub = function(c) {
                        var b = c.data;
                        "string" !== typeof b && (b = Ab(this.l, c.data));
                        return b
                    };
                    a.prototype.lb = function(c) {
                        return encodeURIComponent(c).length
                    };
                    a.prototype.se = function(c, b) {
                        for (var d = Math.ceil(c.length / b), e = [], f = 0; f < b; f += 1) e.push(c.slice(f * d, d * (f + 1)));
                        return e
                    };
                    return a
                }(),
                rp = v(function(a) {
                    function c(f, g, h, k) {
                        d[0] = g;
                        h[k] = e[3];
                        h[k + 1] = e[2];
                        h[k + 2] = e[1];
                        h[k + 3] = e[0]
                    }

                    function b(f,
                        g, h, k) {
                        d[0] = g;
                        h[k] = e[0];
                        h[k + 1] = e[1];
                        h[k + 2] = e[2];
                        h[k + 3] = e[3]
                    }
                    if ("undefined" === typeof a.Float32Array || "undefined" === typeof a.Uint8Array) return sp;
                    var d = new Float32Array([-0]),
                        e = new Uint8Array(d.buffer);
                    return 128 === e[3] ? b : c
                }),
                np = Ei(!1),
                mp = Ei(!0),
                ba, Mc, Ll = (ba = {}, ba.mousemove = 0, ba.mouseup = 1, ba.mousedown = 2, ba.click = 3, ba.scroll = 4, ba.windowblur = 5, ba.windowfocus = 6, ba.focus = 7, ba.blur = 8, ba.eof = 9, ba.selection = 10, ba.change = 11, ba.input = 12, ba.touchmove = 13, ba.touchstart = 14, ba.touchend = 15, ba.touchcancel = 16, ba.touchforcechange =
                    17, ba.zoom = 18, ba.resize = 19, ba.keystroke = 20, ba.deviceRotation = 21, ba.fatalError = 22, ba.hashchange = 23, ba.stylechange = 24, ba.articleInfo = 25, ba.publishersHeader = 26, ba.pageData = 27, ba.mutationAdd = 28, ba.mutationRemove = 29, ba.mutationTextChange = 30, ba.mutationAttributesChange = 31, ba),
                Ml = (Mc = {}, Mc.page = 0, Mc.event = 1, Mc.mutation = 2, Mc.publishers = 3, Mc.activity = 4, Mc),
                ui = function() {
                    function a(c, b) {
                        var d, e, f = this;
                        this.isSync = !1;
                        this.Fb = [];
                        this.Wg = (d = {}, d.ad = "mutationAdd", d.re = "mutationRemove", d.tc = "mutationTextChange",
                            d.ac = "mutationAttributesChange", d.page = "pageData", d);
                        this.Rg = (e = {}, e.ad = "addedNodesMutation", e.re = "removedNodesMutation", e.tc = "textChangeMutation", e.ac = "attributesChangeMutation", e.touchmove = "touchEvent", e.touchstart = "touchEvent", e.touchend = "touchEvent", e.touchforcechange = "touchEvent", e.touchcancel = "touchEvent", e.resize = "resizeEvent", e.scroll = "scrollEvent", e.change = "changeEvent", e.mousemove = "mouseEvent", e.mousedown = "mouseEvent", e.mouseup = "mouseEvent", e.click = "mouseEvent", e.focus = "focusEvent", e.blur =
                            "focusEvent", e.deviceRotation = "deviceRotationEvent", e.zoom = "zoomEvent", e.keystroke = "keystrokesEvent", e.selection = "selectionEvent", e.stylechange = "styleChangeEvent", e.fatalError = "fatalErrorEvent", e.pageData = "page", e);
                        this.rh = function(g) {
                            var h = g.type;
                            return g.event || "publishersHeader" !== h && "articleInfo" !== h ? {
                                type: Ml[h],
                                event: Ll[f.Wg[g.event] || g.event]
                            } : {
                                type: Ml.publishers,
                                event: Ll[h]
                            }
                        };
                        this.uf = function(g) {
                            var h = !X(g.partNum),
                                k = f.rh(g);
                            k = {
                                stamp: g.stamp,
                                type: k.type,
                                event: k.event,
                                frameId: g.frameId,
                                chunk: h ?
                                    g.data : void 0,
                                partNum: g.partNum,
                                end: g.end
                            };
                            !h && g.data && (h = f.Rg[g.event] || g.event || g.type) && (k[h] = g.data);
                            return k
                        };
                        this.l = c;
                        this.type = b
                    }
                    a.prototype.Ha = function(c, b) {
                        var d = this;
                        void 0 === b && (b = !1);
                        var e = ec(c, this.uf),
                            f = this.isSync || b ? Infinity : 10;
                        e = nd(this.l, e, f);
                        var g = [e];
                        this.Fb.push(e);
                        return e(Ug(function(h) {
                            h = xi(d.l, cp, {
                                Ai: h
                            });
                            h = nd(d.l, h, f, wg);
                            g.push(h);
                            d.Fb.push(h);
                            return h
                        }))(Ug(function(h) {
                            h = wi(d.l, h.slice(-4));
                            h = nd(d.l, h, f, wg);
                            g.push(h);
                            d.Fb.push(h);
                            return h
                        }))(ml(function(h) {
                            h = h[h.length - 1];
                            x(function(k) {
                                k = Me(d.l)(k, d.Fb);
                                d.Fb.splice(k, 1)
                            }, g);
                            return h
                        }))
                    };
                    a.prototype.ub = function(c) {
                        return xi(this.l, yi, this.uf(c))(xg(D))
                    };
                    a.prototype.lb = function(c) {
                        return c[0]
                    };
                    a.prototype.se = function(c, b) {
                        for (var d = wi(this.l, c)(xg(D)), e = Math.ceil(d.length / b), f = [], g = 0; g < b; g += 1) f.push(d.slice(g * e, e * (g + 1)));
                        return f
                    };
                    a.isEnabled = function(c) {
                        var b = We(c),
                            d = !1;
                        try {
                            d = (d = 2 === (new c.Blob(["\u00e4"])).size) && 2 === (new c.Blob([new c.Uint8Array([1, 2])])).size
                        } catch (e) {}
                        return !b && d && !(!c.Uint8Array || !n(c, "Uint8Array.prototype.slice"))
                    };
                    return a
                }(),
                Nl = "resize scroll mousemove mousedown click windowfocus keydown orientationchange change focus touchmove touchstart".split(" "),
                wu = "id pageTitle stamp chars authors updateDate publicationDate pageUrlCanonical topics rubric".split(" "),
                xu = function() {
                    function a(c, b, d, e, f) {
                        var g = this;
                        this.Ec = !1;
                        this.meta = {};
                        this.scroll = {
                            x: 0,
                            y: 0
                        };
                        this.involvedTime = this.sf = 0;
                        this.Ud = this.Af = "";
                        this.fa = [];
                        this.pe = this.Ka = 0;
                        this.yb = {
                            h: 0,
                            w: 0
                        };
                        this.buffer = [];
                        this.og = wu;
                        this.flush = function() {
                            g.pe = U(g.l, g.flush,
                                2500);
                            var h = g.Cd();
                            if (g.buffer.length || h) {
                                var k = Ze(g.buffer);
                                h && k.push(h);
                                g.Af = g.Ud;
                                g.ma.Ha(k)(Ra(E(g.l, "p.b.st"), function(l) {
                                    l && g.Vb(l)
                                }))
                            }
                        };
                        this.Vb = e;
                        this.ma = d;
                        this.$b = H(this.$b, this);
                        this.Cd = H(this.Cd, this);
                        this.flush = H(this.flush, this);
                        this.l = c;
                        this.oa = f;
                        this.Sc = b;
                        this.Pd = "pai" + b.id;
                        this.Jb();
                        this.Se = fa(this.l);
                        this.time = ja(this.l);
                        this.hg();
                        this.Fd = J(this.l);
                        this.Ee = null
                    }
                    a.prototype.start = function() {
                        this.pe = U(this.l, this.flush, 2500);
                        if (!this.Ec) {
                            this.Ki();
                            var c = this.Fd.C(this.Pd, []),
                                b = !c.length;
                            c.push(H(this.Xh, this));
                            this.Fd.Ia(this.Pd, c);
                            b && this.Jf();
                            this.Ee = fa(this.l).F(this.l, ["click"], H(this.Ii, this));
                            this.$b({
                                type: "page",
                                target: this.l
                            })
                        }
                    };
                    a.prototype.stop = function() {
                        this.Yi();
                        this.Ec = !0;
                        this.flush();
                        la(this.l, this.pe)
                    };
                    a.prototype.pf = function(c) {
                        return oc("html", this.l, c) !== this.l.document.documentElement
                    };
                    a.prototype.Jf = function() {
                        var c = this;
                        E(this.l, "p.ic" + this.Sc.id, function() {
                            if (!c.Ec) {
                                var b = c.Fd.C(c.Pd),
                                    d = c.Sc.bh();
                                x(function(e) {
                                        var f = A(function(g) {
                                            return z({}, g)
                                        }, d);
                                        O(e) && e(f)
                                    },
                                    b);
                                c.Ka = U(c.l, H(c.Jf, c), 1E3, "p")
                            }
                        })()
                    };
                    a.prototype.Xh = function(c) {
                        this.Ec || (this.Zi(c), this.$i(), this.Gg())
                    };
                    a.prototype.Lg = function(c, b) {
                        return (c.me || 0) <= (b.me || 0) ? b : c
                    };
                    a.prototype.Ii = function(c) {
                        if (this.fa.length) {
                            c = oj(c);
                            var b = S(this.l).hostname,
                                d;
                            if (d = c) d = Ke(c.hostname) === Ke(b);
                            d && (c = N(this.Lg, this.fa[0], this.fa).id, b = Dc(this.l), dd(this.l, this.oa.split(":")[0]).D("pai", c + "-" + b))
                        }
                    };
                    a.prototype.$b = function(c) {
                        var b = this;
                        E(this.l, "p.ec." + this.Sc.id, function() {
                            var d, e;
                            try {
                                var f = c.type;
                                var g = c.target
                            } catch (p) {
                                return
                            }
                            var h =
                                "page" === f;
                            if ("scroll" === f || h) {
                                var k = [b.l, b.l.document, b.l.document.documentElement, Ic(b.l)];
                                I(g, k) && b.Jb()
                            }("resize" === f || h) && b.hg();
                            f = b.time(Z);
                            var l = Math.min(f - b.sf, 5E3);
                            b.involvedTime += Math.round(l);
                            b.sf = f;
                            if (b.meta && b.scroll && b.yb) {
                                var m = b.yb.h * b.yb.w;
                                b.fa = A(function(p) {
                                    var q = z({}, p),
                                        r = b.meta[q.id],
                                        t = Oc(p.Eb);
                                    if (!r || b.pf(q.element) || !t) return q;
                                    p = b.l.Math;
                                    r = p.max((b.scroll.y + b.yb.h - r.y) / r.height, 0);
                                    var y = t.height * t.width;
                                    t = Ah(b.l, t, b.yb);
                                    q.me = t / m;
                                    q.visibility = t / y;
                                    if (.9 <= q.visibility || .1 <= q.me) q.involvedTime +=
                                        l;
                                    q.maxScrolled = p.round(1E4 * r) / 1E4;
                                    return q
                                }, b.fa);
                                vb(b.l, (d = {}, d.name = "publishers", d.counterKey = b.oa, d.data = (e = {}, e.involvedTime = b.involvedTime, e.contentItems = A(function(p) {
                                    var q;
                                    return z((q = {}, q.contentElement = p.Eb, q), p)
                                }, b.fa), e), d))
                            }
                        })()
                    };
                    a.prototype.Zi = function(c) {
                        var b = A(function(d) {
                            return d.id
                        }, this.fa);
                        this.fa = this.fa.concat(ha(function(d) {
                            return !I(d.id, b)
                        }, c))
                    };
                    a.prototype.hg = function() {
                        var c = me(this.l) || Pc(this.l);
                        this.yb = {
                            w: c[0],
                            h: c[1]
                        }
                    };
                    a.prototype.$i = function() {
                        var c = this;
                        E(this.l, "p.um." +
                            this.Sc.id,
                            function() {
                                var b = [];
                                c.Jb();
                                c.meta = Bb(function(d, e) {
                                    var f;
                                    if (c.pf(e.element)) b.push(e), delete d[e.id];
                                    else {
                                        var g = (f = {}, f.id = e.id, f.involvedTime = Math.max(e.involvedTime, 0), f.maxScrolled = e.maxScrolled || 0, f.chars = e.update ? e.update("chars") || 0 : 0, f);
                                        e.Eb && (f = Oc(e.Eb)) && (g.x = Math.max(Math.round(f.left) + c.scroll.x, 0), g.y = Math.max(Math.round(f.top) + c.scroll.y, 0), g.width = Math.round(f.width), g.height = Math.round(f.height));
                                        d[e.id] = g
                                    }
                                    return d
                                }, {}, c.fa);
                                x(function(d) {
                                    d = Me(c.l)(d, c.fa);
                                    c.fa.splice(d,
                                        1)
                                }, b)
                            })()
                    };
                    a.prototype.Cd = function() {
                        var c, b, d = A(u(this.meta, n), da(this.meta));
                        return d.length && (this.Ud = Ab(this.l, d), this.Af !== this.Ud) ? (c = {}, c.type = "publishersHeader", c.data = (b = {}, b.articleMeta = d || [], b.involvedTime = this.involvedTime, b), c) : null
                    };
                    a.prototype.Gg = function() {
                        var c = this;
                        if (this.fa.length) {
                            var b = A(function(d) {
                                var e, f = N(function(g, h) {
                                    d[h] && (g[h] = d[h]);
                                    return g
                                }, {}, c.og);
                                d.Uf = !0;
                                return e = {}, e.type = "articleInfo", e.stamp = f.stamp, e.data = f, e
                            }, ha(function(d) {
                                return !d.Uf
                            }, this.fa));
                            b.length &&
                                (this.buffer = this.buffer.concat(b), Kb(this.l, this.oa, ["pdf", b]))
                        }
                    };
                    a.prototype.Ki = function() {
                        this.Se.F(this.l, Nl, this.$b)
                    };
                    a.prototype.Yi = function() {
                        this.Ee && this.Ee();
                        this.Se.xb(this.l, Nl, this.$b)
                    };
                    a.prototype.Jb = function() {
                        this.scroll = {
                            x: this.l.pageXOffset || n(this.l, "document.documentElement.scrollLeft") || 0,
                            y: this.l.pageYOffset || n(this.l, "document.documentElement.scrollLeft") || 0
                        }
                    };
                    return a
                }(),
                ce, ih = (ce = {}, ce[1] = 500, ce[2] = 500, ce[3] = 0, ce),
                yu = ["topics", "rubric", "authors"],
                jh = function() {
                    function a(c,
                        b) {
                        var d, e = this;
                        this.id = "a";
                        this.Kd = !1;
                        this.Gb = {};
                        this.tb = {
                            "schema.org": "Article NewsArticle Movie BlogPosting Review Recipe Answer".split(" "),
                            xf: ["article"]
                        };
                        this.Ce = (d = {}, d.Answer = 3, d.Review = 2, d);
                        this.Ve = v(function(f, g, h) {
                            var k;
                            Kb(e.l, e.oa, "pfi", (k = {}, k.field = f, k.itemField = g, k.value = h, k))
                        }, function(f, g, h) {
                            return "" + f + g + h
                        });
                        this.bj = function(f) {
                            yu.forEach(function(g) {
                                f[g] && (f[g] = f[g].reduce(function(h, k) {
                                    var l = k.name,
                                        m = k.position;
                                    if (!l) return e.Ve(g, "name", l), h;
                                    if ("string" === typeof m) {
                                        l = se(m);
                                        if (null ===
                                            l || e.l.isNaN(l)) return e.Ve(g, "position", m), h;
                                        k.position = l
                                    }
                                    h.push(k);
                                    return h
                                }, []))
                            });
                            return f
                        };
                        this.Mg = v(function(f, g) {
                            var h;
                            Kb(e.l, e.oa, ["pcs", g], (h = {}, h.chars = g.chars, h.limit = ih[g.type], h))
                        });
                        this.l = c;
                        this.root = fc(c);
                        this.oa = b
                    }
                    a.prototype.Na = function(c) {
                        return c.element
                    };
                    a.prototype.bf = function(c, b) {
                        var d = this,
                            e;
                        E(this.l, "P.s." + b, function() {
                            e = d.Gb[b].call(d, c)
                        })();
                        return e
                    };
                    a.prototype.zi = function(c) {
                        var b = z({}, c);
                        this.Kd && !b.id && I(c.type, [3, 2]) && (c = G(", ", A(T("name"), b.authors || [])), b.pageTitle =
                            c + ": " + b.pageTitle);
                        b.pageTitle || (b.pageTitle = this.Bh(b.Eb));
                        b.pageUrlCanonical || (c = b.id, b.pageUrlCanonical = ("string" !== typeof c ? 0 : /^(https?:)\/\//.test(c)) ? b.id : this.zh());
                        b.id || (b.id = b.pageTitle || b.pageUrlCanonical);
                        return b
                    };
                    a.prototype.Ea = function(c) {
                        var b = this,
                            d = {},
                            e = this.Na(c);
                        if (!e) return null;
                        d.type = c.type;
                        x(function(g) {
                            d[g] = b.bf(c, g)
                        }, da(this.Gb));
                        var f = ja(this.l);
                        d.stamp = f(fk);
                        d.element = c.element;
                        d.Eb = e;
                        d = this.bj(this.zi(d));
                        d.id = d.id ? gc(d.id) : 1;
                        d.update = function(g) {
                            return b.Na(c) ? b.bf(c,
                                g) : void 0
                        };
                        return d
                    };
                    a.prototype.Bh = function(c) {
                        for (var b = 1; 5 >= b; b += 1) {
                            var d = cb(dc("h" + b, c));
                            if (d) return d
                        }
                    };
                    a.prototype.zh = function() {
                        var c = dc('[rel="canonical"]', this.root);
                        if (c) return c.href
                    };
                    a.prototype.gf = function() {
                        return 1
                    };
                    a.prototype.vc = function() {
                        return []
                    };
                    a.prototype.bh = function() {
                        var c = this,
                            b = this.vc(),
                            d = 1;
                        return Bb(function(e, f) {
                            var g = c.Ea({
                                element: f,
                                type: c.gf(f)
                            }) || [];
                            R(g) || (g = [g]);
                            g = Bb(function(h, k) {
                                var l = h.values,
                                    m = h.jf;
                                k && k.chars > ih[k.type] && !I(k.id, m) ? (l.push(k), m.push(k.id)) : k &&
                                    k.chars <= ih[k.type] && c.Mg(k.id, k);
                                return {
                                    values: l,
                                    jf: m
                                }
                            }, {
                                values: [],
                                jf: A(T("id"), e)
                            }, g).values;
                            return e.concat(A(function(h) {
                                var k;
                                h = z((k = {
                                    index: d,
                                    Uf: !1
                                }, k.involvedTime = 0, k), h);
                                d += 1;
                                return h
                            }, g))
                        }, [], b)
                    };
                    return a
                }(),
                Ol = function(a) {
                    function c() {
                        var b, d = null !== a && a.apply(this, arguments) || this;
                        d.id = "j";
                        d.Kd = !0;
                        d.Pe = G(",", ['script[type="application/ld+json"]', 'script[type="application/json+ld"]', 'script[type="ld+json"]', 'script[type="json+ld"]']);
                        d.Gb = (b = {}, b.id = function(e) {
                            var f = e.data["@id"];
                            e = e.data.mainEntity ||
                                e.data.mainEntityOfPage;
                            !f && ka(e) && (f = e["@id"]);
                            return f
                        }, b.chars = function(e) {
                            var f = e.data;
                            return ia(f.text) ? f.text.length : Mb(this.Na(e)).length
                        }, b.authors = function(e) {
                            e = e.data;
                            var f = [];
                            f = f.concat(this.uc(e, "author"));
                            f = f.concat(this.uc(e.mainEntity, "author"));
                            return f.concat(this.uc(e.mainEntityOfPage, "author"))
                        }, b.pageTitle = function(e) {
                            var f = e.data,
                                g = f.headline || "";
                            f.alternativeHeadline && (g += " " + f.alternativeHeadline);
                            "" === g && (f.name ? g = f.name : f.itemReviewed && (g = f.itemReviewed));
                            3 === e.type && ka(f.parentItem) &&
                                (g = f.parentItem.text);
                            return g
                        }, b.updateDate = function(e) {
                            return e.data.dateModified || ""
                        }, b.publicationDate = function(e) {
                            return e.data.datePublished || ""
                        }, b.pageUrlCanonical = function(e) {
                            return e.data.url
                        }, b.topics = function(e) {
                            return this.uc(e.data, "about", ["name", "alternateName"])
                        }, b.rubric = function(e) {
                            var f = this,
                                g = this.Na(e);
                            e = ua(A(function(h) {
                                h = qb(f.l, Mb(h));
                                if (ka(h) || R(h)) {
                                    var k = f.cf(h);
                                    if (k) return N(function(l, m) {
                                        return l ? l : ka(m) && "BreadcrumbList" === m["@type"] ? m : l
                                    }, null, k);
                                    if ("BreadcrumbList" ===
                                        h["@type"]) return h
                                }
                                return null
                            }, [e.element].concat(jb(this.Pe, document.body === g ? document.documentElement : g))));
                            return e.length && (e = e[0].itemListElement, R(e)) ? ua(A(function(h) {
                                return ka(h) && h.item && ka(h.item) && !f.l.isNaN(h.position) ? {
                                    name: h.item.name || h.name,
                                    position: h.position
                                } : null
                            }, e)) : []
                        }, b);
                        return d
                    }
                    Na(c, a);
                    c.prototype.uc = function(b, d, e) {
                        void 0 === e && (e = ["name"]);
                        if (!b || !b[d]) return [];
                        b = R(b[d]) ? b[d] : [b[d]];
                        b = ua(A(function(f) {
                            return f ? "string" === typeof f ? f : N(function(g, h) {
                                    return g || "" + f[h]
                                }, "",
                                e) : null
                        }, b));
                        return A(function(f) {
                            var g;
                            return g = {}, g.name = f, g
                        }, b)
                    };
                    c.prototype.Na = function(b) {
                        var d = b.element,
                            e = b.data || {};
                        b = e["@id"];
                        var f = e.url;
                        e = null;
                        f && ia(f) && (e = this.Ue(f));
                        !e && b && ia(b) && (e = this.Ue(b));
                        e || (e = b = d.parentNode, !oc("head", this.l, d) && b && 0 !== Mb(b).length) || (e = this.l.document.body);
                        return e
                    };
                    c.prototype.Ue = function(b) {
                        try {
                            var d = Tc(this.l, b).hash;
                            if (d) {
                                var e = dc(d, this.l.document.body);
                                if (e) return e
                            }
                        } catch (f) {}
                        return null
                    };
                    c.prototype.$d = function(b) {
                        return this.Ce[b["@type"]] || 1
                    };
                    c.prototype.Ea =
                        function(b) {
                            var d = this,
                                e = b.element,
                                f = b.data;
                            if (!f && (f = qb(this.l, Mb(e)), !f || !/schema\.org/.test(f["@context"]) && !R(f))) return null;
                            var g = this.cf(f);
                            if (g) return A(function(k) {
                                return ka(k) && I(k["@type"], d.tb["schema.org"]) ? a.prototype.Ea.call(d, {
                                    element: e,
                                    data: k,
                                    type: d.$d(k)
                                }) : null
                            }, g);
                            b.data = f;
                            if ("QAPage" === b.data["@type"]) {
                                var h = b.data.mainEntity || b.data.mainEntityOfPage;
                                if (!h) return null
                            }
                            "Question" === b.data["@type"] && (h = b.data);
                            return h ? (b = xc(u(h, n), ["acceptedAnswer", "suggestedAnswer"]), A(function(k) {
                                var l;
                                if (!ka(k) || !I(k["@type"], d.tb["schema.org"])) return null;
                                k = {
                                    element: e,
                                    type: d.$d(k),
                                    data: z((l = {}, l.parentItem = h, l), k)
                                };
                                return a.prototype.Ea.call(d, k)
                            }, b)) : I(b.data["@type"], this.tb["schema.org"]) ? a.prototype.Ea.call(this, z(b, {
                                type: this.$d(b.data)
                            })) : null
                        };
                    c.prototype.vc = function() {
                        return jb(this.Pe, this.root)
                    };
                    c.prototype.cf = function(b) {
                        if (R(b)) return b;
                        if (b && R(b["@graph"])) return b["@graph"]
                    };
                    return c
                }(jh),
                kh = function(a) {
                    function c() {
                        var b, d = null !== a && a.apply(this, arguments) || this;
                        d.id = "s";
                        d.Kd = !0;
                        d.Xi = Ea("exec", new RegExp("schema.org\\/(" + G("|", da(d.Ce)) + ")$"));
                        d.Gb = (b = {}, b.id = function(e) {
                                e = e.element;
                                var f = hb(this.l, e, "identifier");
                                return f ? cb(f) : (f = hb(this.l, e, "mainEntityOfPage")) && f.getAttribute("itemid") ? f.getAttribute("itemid") : null
                            }, b.chars = function(e) {
                                var f = 0;
                                e = e.element;
                                for (var g = ["articleBody", "reviewBody", "recipeInstructions", "description", "text"], h = 0; h < g.length; h += 1) {
                                    var k = hb(this.l, e, g[h]);
                                    if (k) {
                                        f = cb(k).length;
                                        break
                                    }
                                }
                                e = Mb(e);
                                0 === f && e && (f += e.length);
                                return f
                            }, b.topics = function(e) {
                                var f =
                                    this,
                                    g = Yd(this.l, e.element, "about");
                                return A(function(h) {
                                    var k = {
                                        name: cb(h)
                                    };
                                    if (g = hb(f.l, h, "name")) k.name = cb(g);
                                    return k
                                }, g)
                            }, b.rubric = function(e) {
                                var f = this;
                                (e = dc('[itemtype$="schema.org/BreadcrumbList"]', e.element)) || (e = dc('[itemtype$="schema.org/BreadcrumbList"]', this.root));
                                return e ? A(function(g) {
                                    return {
                                        name: cb(hb(f.l, g, "name")),
                                        position: cb(hb(f.l, g, "position"))
                                    }
                                }, Yd(this.l, e, "itemListElement")) : []
                            }, b.updateDate = function(e) {
                                return (e = hb(this.l, e.element, "dateModified")) ? Fk(e) : ""
                            }, b.publicationDate =
                            function(e) {
                                return (e = hb(this.l, e.element, "datePublished")) ? Fk(e) : ""
                            }, b.pageUrlCanonical = function(e) {
                                e = Yd(this.l, e.element, "url");
                                if (e.length) {
                                    var f = e[0];
                                    return f.href ? f.href : cb(e)
                                }
                                return null
                            }, b.pageTitle = function(e) {
                                var f = "",
                                    g = e.element,
                                    h = hb(this.l, g, "headline");
                                h && (f += cb(h));
                                (h = hb(this.l, g, "alternativeHeadline")) && (f += " " + cb(h));
                                "" === f && ((h = hb(this.l, g, "name")) || (h = hb(this.l, g, "itemReviewed")), h && (f += cb(h)));
                                3 === e.type && (e = oc('[itemtype$="schema.org/Question"]', this.l, g)) && (e = hb(this.l, e, "text")) &&
                                    (f += cb(e));
                                return f
                            }, b.authors = function(e) {
                                var f = this;
                                e = Yd(this.l, e.element, "author");
                                return A(function(g) {
                                    var h, k = (h = {}, h.name = "", h);
                                    /.+schema.org\/(Person|Organization)/.test(g.getAttribute("itemtype") || "") && (h = hb(f.l, g, "name")) && (k.name = cb(h));
                                    k.name || (k.name = g.getAttribute("content") || Mb(g) || g.getAttribute("href"));
                                    return k
                                }, e)
                            }, b);
                        return d
                    }
                    Na(c, a);
                    c.prototype.gf = function(b) {
                        b = b.getAttribute("itemtype") || "";
                        return (b = this.Xi(b)) ? this.Ce[b[1]] : 1
                    };
                    c.prototype.Ea = function(b) {
                        return b.element && Mb(b.element).length ?
                            a.prototype.Ea.call(this, b) : null
                    };
                    c.prototype.vc = function() {
                        var b = G(",", A(function(d) {
                            return '[itemtype$="schema.org/' + d + '"]'
                        }, this.tb["schema.org"]));
                        return jb(b, this.root)
                    };
                    return c
                }(jh),
                Pl = function(a) {
                    function c(b, d) {
                        var e, f = a.call(this, b, d) || this;
                        f.id = "o";
                        f.Gb = (e = {}, e.chars = function(g) {
                                g = this.Na(g);
                                return Mb(g).length
                            }, e.authors = function(g) {
                                return this.yd(g.data.author)
                            }, e.pageTitle = function(g) {
                                return this.zc(g.data.title) || ""
                            }, e.updateDate = function(g) {
                                return this.zc(g.data.modified_time)
                            }, e.publicationDate =
                            function(g) {
                                return this.zc(g.data.published_time)
                            }, e.pageUrlCanonical = function(g) {
                                return this.zc(g.data.url)
                            }, e.rubric = function(g) {
                                return this.yd(g.data.section)
                            }, e.topics = function(g) {
                                return this.yd(g.data.tag)
                            }, e);
                        f.Vg = new RegExp("^(og:)?((" + G("|", f.tb.xf) + "):)?");
                        return f
                    }
                    Na(c, a);
                    c.prototype.yd = function(b) {
                        var d;
                        return b ? R(b) ? A(function(e) {
                            var f;
                            return f = {}, f.name = e ? "" + e : null, f
                        }, b) : [(d = {}, d.name = b ? "" + b : null, d)] : []
                    };
                    c.prototype.zc = function(b) {
                        return R(b) ? b.length ? "" + b[0] : null : b ? "" + b : null
                    };
                    c.prototype.vc =
                        function() {
                            var b = jb('meta[property="og:type"]', this.l.document.body);
                            return [this.l.document.head].concat(b)
                        };
                    c.prototype.qh = function(b) {
                        var d = this,
                            e = b.element,
                            f = {},
                            g = this.Na(b);
                        e = jb("meta[property]", e === this.l.document.head ? e : g);
                        if (e.length) x(function(h) {
                            try {
                                if (h.parentNode === g || h.parentNode === d.l.document.head) {
                                    var k = h.getAttribute("property").replace(d.Vg, ""),
                                        l = cb(h);
                                    f[k] ? R(f[k]) ? f[k].push(l) : f[k] = [f[k], l] : f[k] = l
                                }
                            } catch (m) {
                                Cd(d.l, "og.ed", m)
                            }
                        }, e);
                        else return null;
                        return I(f.type, this.tb.xf) ? z(b, {
                            data: f
                        }) : null
                    };
                    c.prototype.Na = function(b) {
                        b = b.element;
                        var d = this.l.document;
                        return b === d.head ? d.body : b.parentNode
                    };
                    c.prototype.Ea = function(b) {
                        return (b = this.qh(b)) ? a.prototype.Ea.call(this, b) : null
                    };
                    return c
                }(jh),
                de = {};
            Ol && (de.json_ld = Ol);
            kh && (de.schema = kh, de.microdata = kh);
            Pl && (de.opengraph = Pl);
            var zu = B("p.p", function(a, c) {
                    function b(m) {
                        var p = z({}, l);
                        p.ba.da = m;
                        return f(p, c)["catch"](E(a, "s.ww.p"))
                    }
                    var d, e = ti(a, "9", "8");
                    if (!Da("querySelectorAll", a.document.querySelectorAll) || !e) return K.resolve();
                    var f =
                        va(a, "p", c),
                        g = Ja(),
                        h = dd(a, c.id),
                        k = h.C("pai");
                    k && (h.pc("pai"), g.D("pai", k));
                    var l = {
                        J: (d = {}, d["wv-type"] = e.type, d),
                        K: g,
                        ba: {}
                    };
                    return pa(c, E(a, "ps.s", function(m) {
                        var p;
                        if (m = n(m, "settings.publisher.schema")) {
                            qk(c) && (m = "microdata");
                            var q = de[m];
                            if (q && e) {
                                var r = L(c);
                                q = new q(a, r);
                                q = new xu(a, q, e, b, r);
                                q.start();
                                Kb(a, r, "ps", (p = {}, p.schema = m, p));
                                return H(q.stop, q)
                            }
                        }
                    }))
                }),
                Au = function() {
                    function a(c, b) {
                        this.type = "0";
                        this.l = c;
                        this.oh = b
                    }
                    a.prototype.Ha = function(c) {
                        return If(xc(H(this.ub, this), c))
                    };
                    a.prototype.ub = function(c,
                        b) {
                        var d = this,
                            e = [],
                            f = this.oh(this.l, b && b.type, c.type);
                        f && (e = xc(function(g) {
                            return g({
                                l: d.l,
                                qa: c
                            }) || []
                        }, f));
                        return e
                    };
                    a.prototype.lb = function(c) {
                        return c.length
                    };
                    a.prototype.se = function(c) {
                        return [c]
                    };
                    a.prototype.isEnabled = function() {
                        return !0
                    };
                    return a
                }(),
                Ql = function() {
                    function a(c, b, d) {
                        this.Qe = 0;
                        this.ae = 1;
                        this.bd = 5E3;
                        this.l = c;
                        this.ma = b;
                        this.Vb = d
                    }
                    a.prototype.Vc = function() {
                        this.Qe = U(this.l, w(H(this.flush, this), H(this.Vc, this)), this.bd, "b.f")
                    };
                    a.prototype.send = function(c, b) {
                        var d = this.Vb(c, b || [], this.ae);
                        this.ae += 1;
                        return d
                    };
                    a.prototype.push = function() {};
                    a.prototype.flush = function() {};
                    return a
                }(),
                so = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.buffer = [];
                        b.pg = 7500;
                        b.bd = 3E4;
                        b.Vc();
                        return b
                    }
                    Na(c, a);
                    c.prototype.push = function(b, d) {
                        var e = this.ma.ub(b, d);
                        ra(this.buffer, e);
                        this.ma.lb(this.buffer) > this.pg && this.flush()
                    };
                    c.prototype.flush = function() {
                        var b = this.buffer;
                        b.length && (this.send(b), this.buffer = [])
                    };
                    return c
                }(Ql),
                Ho = /opera mini/i,
                ni = ["phone", "email"],
                Rl = "first(-|\\.|_|\\s){0,2}name last(-|\\.|_|\\s){0,2}name zip postal address passport (bank|credit)(-|\\.|_|\\s){0,2}card card(-|\\.|_|\\s){0,2}number card(-|\\.|_|\\s){0,2}holder cvv card(-|\\.|_|\\s){0,2}exp card(-|\\.|_|\\s){0,2}name card.*month card.*year card.*month card.*year password birth(-|\\.|_|\\s){0,2}(day|date) second(-|\\.|_|\\s){0,2}name third(-|\\.|_|\\s){0,2}name patronymic middle(-|\\.|_|\\s){0,2}name birth(-|\\.|_|\\s){0,2}place house street city flat state contact.*".split(" "),
                Eo = /^[\w\u0410-\u042f\u0430-\u044f]$/,
                Fo = [65, 90],
                Go = [97, 122],
                Co = "color radio checkbox date datetime-local email month number password range search tel text time url week".split(" "),
                Ao = new RegExp("(" + G("|", Rl) + ")", "i"),
                zo = new RegExp("(" + G("|", ni) + ")", "i"),
                Gk = ["password", "passwd", "pswd"],
                Bo = new RegExp("(" + G("|", Rl.concat("\u0438\u043c\u044f \u0444\u0430\u043c\u0438\u043b\u0438\u044f \u043e\u0442\u0447\u0435\u0441\u0442\u0432\u043e \u0438\u043d\u0434\u0435\u043a\u0441 \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u0430\u0434\u0440\u0435\u0441 \u043f\u0430\u0441\u043f\u043e\u0440\u0442 \u043d\u043e\u043c\u0435\u0440(-|\\.|_|\\s){0,2}\u043a\u0430\u0440\u0442\u044b \u0434\u0430\u0442\u0430(-|\\.|_|\\s){0,2}\u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f \u0434\u043e\u043c \u0443\u043b\u0438\u0446\u0430 \u043a\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0433\u043e\u0440\u043e\u0434 \u043e\u0431\u043b\u0430\u0441\u0442\u044c".split(" "))) +
                    ")", "i"),
                Ya = "metrikaId_" + Math.random(),
                Ac = {
                    counter: 0
                },
                ys = v(function() {
                    var a;
                    return a = {}, a.A = 1, a.ABBR = 2, a.ACRONYM = 3, a.ADDRESS = 4, a.APPLET = 5, a.AREA = 6, a.B = 7, a.BASE = 8, a.BASEFONT = 9, a.BDO = 10, a.BIG = 11, a.BLOCKQUOTE = 12, a.BODY = 13, a.BR = 14, a.BUTTON = 15, a.CAPTION = 16, a.CENTER = 17, a.CITE = 18, a.CODE = 19, a.COL = 20, a.COLGROUP = 21, a.DD = 22, a.DEL = 23, a.DFN = 24, a.DIR = 25, a.DIV = 26, a.DL = 27, a.DT = 28, a.EM = 29, a.FIELDSET = 30, a.FONT = 31, a.FORM = 32, a.FRAME = 33, a.FRAMESET = 34, a.H1 = 35, a.H2 = 36, a.H3 = 37, a.H4 = 38, a.H5 = 39, a.H6 = 40, a.HEAD = 41, a.HR = 42, a.HTML =
                        43, a.I = 44, a.IFRAME = 45, a.IMG = 46, a.INPUT = 47, a.INS = 48, a.ISINDEX = 49, a.KBD = 50, a.LABEL = 51, a.LEGEND = 52, a.LI = 53, a.LINK = 54, a.MAP = 55, a.MENU = 56, a.META = 57, a.NOFRAMES = 58, a.NOSCRIPT = 59, a.OBJECT = 60, a.OL = 61, a.OPTGROUP = 62, a.OPTION = 63, a.P = 64, a.PARAM = 65, a.PRE = 66, a.Q = 67, a.S = 68, a.SAMP = 69, a.SCRIPT = 70, a.SELECT = 71, a.SMALL = 72, a.SPAN = 73, a.STRIKE = 74, a.STRONG = 75, a.STYLE = 76, a.SUB = 77, a.SUP = 78, a.TABLE = 79, a.TBODY = 80, a.TD = 81, a.TEXTAREA = 82, a.TFOOT = 83, a.TH = 84, a.THEAD = 85, a.TITLE = 86, a.TR = 87, a.TT = 88, a.U = 89, a.UL = 90, a.VAR = 91, a.NOINDEX =
                        100, a
                }),
                vs = [17, 18, 38, 32, 39, 15, 11, 7, 1],
                Bu = function() {
                    var a = "first(-|\\.|_|\\s){0,2}name last(-|\\.|_|\\s){0,2}name zip postal phone address passport (bank|credit)(-|\\.|_|\\s){0,2}card card(-|\\.|_|\\s){0,2}number card(-|\\.|_|\\s){0,2}holder cvv card(-|\\.|_|\\s){0,2}exp card(-|\\.|_|\\s){0,2}name card.*month card.*year card.*month card.*year password email birth(-|\\.|_|\\s){0,2}(day|date) second(-|\\.|_|\\s){0,2}name third(-|\\.|_|\\s){0,2}name patronymic middle(-|\\.|_|\\s){0,2}name birth(-|\\.|_|\\s){0,2}place house street city flat state".split(" ");
                    return {
                        uj: new RegExp("(" + G("|", a) + ")", "i"),
                        Dj: new RegExp("(" + G("|", a.concat("\u0438\u043c\u044f;\u0444\u0430\u043c\u0438\u043b\u0438\u044f;\u043e\u0442\u0447\u0435\u0441\u0442\u0432\u043e;\u0438\u043d\u0434\u0435\u043a\u0441;\u0442\u0435\u043b\u0435\u0444\u043e\u043d;\u0430\u0434\u0440\u0435\u0441;\u043f\u0430\u0441\u043f\u043e\u0440\u0442;\u041d\u043e\u043c\u0435\u0440(-|\\.|_|\\s){0,2}\u043a\u0430\u0440\u0442\u044b;\u0434\u0430\u0442\u0430(-|\\.|_|\\s){0,2} \u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f;\u0434\u043e\u043c;\u0443\u043b\u0438\u0446\u0430;\u043a\u0432\u0430\u0440\u0442\u0438\u0440\u0430;\u0433\u043e\u0440\u043e\u0434;\u043e\u0431\u043b\u0430\u0441\u0442\u044c".split(";"))) +
                            ")", "i"),
                        sj: /ym-record-keys/i,
                        ji: "\u2022",
                        Cj: 88
                    }
                }(),
                Lk = Wb(u(Bu.ji, Q)),
                wd = !0,
                Ng = "",
                Og = !1,
                Pg = !0,
                Qg = !1,
                xo = sa(function(a, c) {
                    var b = C([a, "efv." + c.event], E);
                    c.O = A(w(Q, b), c.O);
                    return c
                }),
                Sl = v(function(a) {
                    var c = [],
                        b = [],
                        d = [];
                    a.document.attachEvent && !a.opera && (c.push(Of), b.push(Bs), b.push(Cs));
                    a.document.addEventListener ? c.push(Jk) : (b.push(Ik), d.push(Jk));
                    return wo(a, [{
                            target: a,
                            type: "window",
                            event: "beforeunload",
                            O: [D]
                        }, {
                            target: a,
                            type: "window",
                            event: "unload",
                            O: [D]
                        }, {
                            event: "click",
                            O: [cf]
                        }, {
                            event: "dblclick",
                            O: [cf]
                        },
                        {
                            event: "mousedown",
                            O: [cf]
                        }, {
                            event: "mouseup",
                            O: [Es]
                        }, {
                            event: "keydown",
                            O: [Fs]
                        }, {
                            event: "keypress",
                            O: [Gs]
                        }, {
                            event: "copy",
                            O: [Nk]
                        }, {
                            event: "blur",
                            O: c
                        }, {
                            event: "focusin",
                            O: b
                        }, {
                            event: "focusout",
                            O: d
                        }
                    ].concat(!a.document.attachEvent || a.opera ? [{
                        target: a,
                        type: "window",
                        event: "focus",
                        O: [li]
                    }, {
                        target: a,
                        type: "window",
                        event: "blur",
                        O: [Of]
                    }] : []).concat(a.document.addEventListener ? [{
                        event: "focus",
                        O: [Ik]
                    }, {
                        event: "change",
                        O: [Kk]
                    }, {
                        event: "submit",
                        O: [Pk]
                    }] : [{
                        type: "formInput",
                        event: "change",
                        O: [Kk]
                    }, {
                        type: "form",
                        event: "submit",
                        O: [Pk]
                    }]))
                }),
                uo = v(function(a) {
                    return Ic(a) ? [{
                        target: a,
                        type: "document",
                        event: "mouseleave",
                        O: [Hs]
                    }] : []
                }),
                Cu = ["submit", "beforeunload", "unload"],
                Du = v(function(a, c) {
                    var b = c(a);
                    return N(function(d, e) {
                        d[e.type + ":" + e.event] = e.O;
                        return d
                    }, {}, b)
                }),
                Eu = u(Sl, function(a, c, b, d) {
                    return Du(c, a)[b + ":" + d] || []
                }),
                vo = /^\s*function submit\(\)/,
                Fu = B("fw.p", function(a, c) {
                    var b;
                    if (!(b = c.Sg || !c.zb)) {
                        var d = J(a),
                            e = !1;
                        b = d.C("hitParam", {});
                        var f = L(c);
                        b[f] && (d = d.C("counters", {}), e = he(c.ca) && !d[f]);
                        b[f] = 1;
                        b = e
                    }
                    if (b) return K.resolve(D);
                    b = new Au(a, Eu);
                    return ro(a, c, b, Sl, Cu)
                }),
                lh, Tl = (lh = function(a) {
                    function c(b, d, e, f) {
                        void 0 === f && (f = 0);
                        d = a.call(this, b, d, e) || this;
                        d.ze = 0;
                        d.Cb = 0;
                        d.ye = 0;
                        d.buffer = [];
                        d.bd = 2E3;
                        d.$ = ud(b);
                        d.Vc();
                        d.ye = f;
                        return d
                    }
                    Na(c, a);
                    c.prototype.$e = function(b) {
                        return ua(this.$.R("ag", b))
                    };
                    c.prototype.Ze = function(b, d) {
                        var e = this;
                        b(Ra(E(this.l, "wv2.b.st"), function(f) {
                            e.send(f, d)
                        }))
                    };
                    c.prototype.Ji = function(b, d) {
                        var e = this;
                        la(this.l, this.Qe);
                        var f = Math.ceil(this.ma.lb(d) / 63E4),
                            g = this.ma.se(d, f);
                        x(function(h, k) {
                            var l, m = z({},
                                b, (l = {}, l.data = h, l.partNum = k + 1, l.end = k + 1 === f, l.partsTotal = g.length, l));
                            l = e.ma.Ha([m], !1);
                            e.Ze(l, [m])
                        }, g);
                        this.Vc()
                    };
                    c.prototype.send = function(b, d) {
                        var e = this;
                        this.$.R("se", d);
                        return a.prototype.send.call(this, b, d).then(Q, function() {
                            e.$.R("see", d)
                        })
                    };
                    c.af = function(b, d, e, f, g) {
                        c.ed["" + b + d] || (this.ed[d] = new c(g, f, e, "m" === d ? 31457280 : 0));
                        return this.ed[d]
                    };
                    c.prototype.Vh = function() {
                        return this.ye && this.ze >= this.ye
                    };
                    c.prototype.push = function(b) {
                        var d = this;
                        if (!this.Vh()) {
                            this.$.R("p", b);
                            var e = this.ma.ub(b),
                                f = this.ma.lb(e);
                            7E5 < f ? this.Ji(b, e) : (e = this.$e(this.buffer.concat([b])), e = Bb(function(g, h) {
                                return g + d.ma.lb(d.ma.ub(h))
                            }, 0, e), this.Cb + e + f >= 7E5 * .7 && this.flush(), this.buffer.push(b), this.Cb += f)
                        }
                    };
                    c.prototype.F = function(b, d) {
                        this.$.F([b], d)
                    };
                    c.prototype.ga = function(b, d) {
                        this.$.ga([b], d)
                    };
                    c.prototype.flush = function(b) {
                        var d = this.buffer.concat(this.$e(this.buffer));
                        d.length && (this.buffer = [], this.ze += this.Cb, this.Cb = 0, b = this.ma.Ha(d, b), this.Ze(b, d))
                    };
                    return c
                }(Ql), lh.ed = {}, lh),
                db = function() {
                    function a(c,
                        b, d) {
                        this.Zh = "wv2.c";
                        this.Ob = [];
                        this.ia = [];
                        this.l = c;
                        this.L = Mf(c, this, d, this.Zh);
                        this.G = b;
                        this.eb = this.G.th();
                        this.start = this.L.H(this.start, "st");
                        this.stop = this.L.H(this.stop, "sp")
                    }
                    a.prototype.start = function() {
                        var c = this;
                        this.Ob = A(function(b) {
                            var d = b[0],
                                e = b[2];
                            b = H(c.L.H(b[1], d[0]), c);
                            return c.eb.F(e || c.l, d, b)
                        }, this.ia)
                    };
                    a.prototype.stop = function() {
                        x(ma, this.Ob)
                    };
                    a.prototype.Z = function(c) {
                        return this.G.sa().Z(c)
                    };
                    return a
                }(),
                po = ["checkbox", "radio"],
                qo = /pwd|value|password/i,
                mh = T("location.href"),
                Gu =
                function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.ra = {
                            elements: [],
                            attributes: []
                        };
                        d.index = 0;
                        d.Wd = d.L.H(d.Wd, "o");
                        d.od = d.L.H(d.od, "io");
                        d.cd = d.L.H(d.cd, "ao");
                        d.ee = d.L.H(d.ee, "a");
                        d.ce = d.L.H(d.ce, "at");
                        d.fe = d.L.H(d.fe, "r");
                        d.de = d.L.H(d.de, "c");
                        d.za = new b.MutationObserver(d.Wd);
                        return d
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        this.za.observe(this.l.document.documentElement, {
                            attributes: !0,
                            characterData: !0,
                            childList: !0,
                            subtree: !0,
                            attributeOldValue: !0,
                            characterDataOldValue: !0
                        })
                    };
                    c.prototype.stop = function() {
                        this.za.disconnect()
                    };
                    c.prototype.cd = function(b) {
                        var d = b.target;
                        b = b.attributeName;
                        var e = Pb(this.l)(d, this.ra.elements); - 1 === e && (e = this.ra.elements.push(d) - 1, this.ra.attributes[e] = {});
                        this.ra.attributes[e] || (this.ra.attributes[e] = {});
                        e = this.ra.attributes[e];
                        var f = d.getAttribute(b);
                        e[b] = we(this.l, d, b, f, this.G.Ib()).value
                    };
                    c.prototype.od = function(b) {
                        function d(k) {
                            var l = Pb(e.l)(k, f);
                            return -1 === l ? (f.push(k), k = {
                                wd: {}
                            }, g.push(k), k) : g[l]
                        }
                        var e = this,
                            f = [],
                            g = [];
                        x(function(k) {
                            var l = k.attributeName,
                                m = k.removedNodes,
                                p = k.oldValue,
                                q =
                                k.target,
                                r = k.nextSibling,
                                t = k.previousSibling;
                            switch (k.type) {
                                case "attributes":
                                    e.cd(k);
                                    var y = d(q);
                                    y.wd[l] || (y.wd[l] = we(e.l, q, l, p, e.G.Ib()).value);
                                    break;
                                case "childList":
                                    m && x(function(F) {
                                        y = d(F);
                                        y.Xe || z(y, {
                                            Xe: q,
                                            ih: r ? r : void 0,
                                            jh: t ? t : void 0
                                        })
                                    }, Ba(m));
                                    break;
                                case "characterData":
                                    y = d(q), y.Ye || (y.Ye = p)
                            }
                        }, b);
                        var h = this.G.sa();
                        x(function(k, l) {
                            h.qe(k, g[l])
                        }, f)
                    };
                    c.prototype.Wd = function(b) {
                        var d = this;
                        if (mh(this.l)) {
                            var e = this.G.stamp();
                            this.od(b);
                            x(function(f) {
                                var g = f.addedNodes,
                                    h = f.removedNodes,
                                    k = f.target;
                                switch (f.type) {
                                    case "childList":
                                        h &&
                                            h.length && d.fe(Ba(h), e);
                                        g && g.length && d.ee(Ba(g), e);
                                        break;
                                    case "characterData":
                                        d.de(k, e)
                                }
                            }, b);
                            this.ce(e)
                        } else this.stop()
                    };
                    c.prototype.ce = function(b) {
                        var d = this;
                        x(function(e, f) {
                            var g = d.xc();
                            d.G.Y("mutation", {
                                index: g,
                                attributes: d.ra.attributes[f],
                                target: d.Z(e)
                            }, "ac", b)
                        }, this.ra.elements);
                        this.ra.elements = [];
                        this.ra.attributes = []
                    };
                    c.prototype.ee = function(b, d) {
                        var e = this,
                            f = this.xc();
                        this.G.sa().Bc({
                            nodes: b,
                            Uc: function(g) {
                                g = A(function(h) {
                                    h.node = void 0;
                                    return h
                                }, g);
                                e.G.Y("mutation", {
                                        index: f,
                                        nodes: g
                                    }, "ad",
                                    d)
                            }
                        })
                    };
                    c.prototype.fe = function(b, d) {
                        var e = this,
                            f = this.xc(),
                            g = this.G.sa(),
                            h = A(function(k) {
                                var l = g.removeNode(k);
                                fj(e.l, k, function(m) {
                                    g.removeNode(m)
                                });
                                return l
                            }, b);
                        this.G.Y("mutation", {
                            index: f,
                            nodes: h
                        }, "re", d)
                    };
                    c.prototype.de = function(b, d) {
                        var e = this.xc();
                        this.G.Y("mutation", {
                            value: b.textContent,
                            target: this.Z(b),
                            index: e
                        }, "tc", d)
                    };
                    c.prototype.xc = function() {
                        var b = this.index;
                        this.index += 1;
                        return b
                    };
                    return c
                }(db),
                Hu = function() {
                    function a(c, b) {
                        var d = this;
                        this.sc = [];
                        this.fb = [];
                        this.Vd = 1;
                        this.Ne = this.Qf =
                            0;
                        this.ya = {};
                        this.Mb = {};
                        this.Hb = [];
                        this.Hd = function(f) {
                            return d.fb.length ? I(f, d.fb) : !1
                        };
                        this.removeNode = function(f) {
                            var g = d.Z(f),
                                h = Ma(f);
                            if (h) return h = "NR:" + h.toLowerCase(), d.Hd(h) && d.$.R(h, {
                                data: {
                                    node: f,
                                    id: g
                                }
                            }), g
                        };
                        this.kb = function(f) {
                            var g = Ma(f);
                            if (g) {
                                var h = f.__ym_indexer;
                                return h ? h : (h = d.Vd, f.__ym_indexer = h, d.Vd += 1, g = "NA:" + g.toLowerCase(), d.Hd(g) && d.$.R(g, {
                                    data: {
                                        node: f,
                                        id: h
                                    }
                                }), h)
                            }
                            return null
                        };
                        this.Kf = function() {
                            d.Qf = U(d.l, w(H(d.aa, d, !1), d.Kf), 50, "i.s")
                        };
                        this.If = function() {
                            d.Ne = U(d.l, w(H(d.hd, d, !1),
                                d.If), 50, "i.g")
                        };
                        this.Bi = function(f) {
                            null === d.ya[f] && delete d.ya[f]
                        };
                        this.l = c;
                        var e = Mf(c, this, "i");
                        this.$ = ud(c);
                        this.options = b;
                        this.start = e.H(this.start, "st");
                        this.stop = e.H(this.stop, "sp");
                        this.Z = e.H(this.Z, "i");
                        this.qe = e.H(this.qe, "o");
                        this.Bc = e.H(this.Bc, "a");
                        this.removeNode = e.H(this.removeNode, "r");
                        this.aa = e.H(this.aa, "s");
                        this.hd = e.H(this.hd, "g")
                    }
                    a.prototype.qe = function(c, b) {
                        var d = this.kb(c);
                        Wa(d) || (this.Mb[d] && this.Z(c), this.Mb[d] = b)
                    };
                    a.prototype.F = function(c, b, d) {
                        c = "" + b + c;
                        this.fb.push(c);
                        this.Hd(c) ||
                            this.fb.push(c);
                        this.$.F([c], d)
                    };
                    a.prototype.ga = function(c, b, d) {
                        var e = "" + b + c;
                        this.fb = ha(function(f) {
                            return f !== e
                        }, this.fb);
                        this.$.ga([e], d)
                    };
                    a.prototype.start = function() {
                        this.Kf();
                        this.If()
                    };
                    a.prototype.stop = function() {
                        this.flush();
                        la(this.l, this.Ne);
                        la(this.l, this.Qf);
                        this.sc = [];
                        this.Hb = [];
                        this.ya = {};
                        this.Mb = {}
                    };
                    a.prototype.Bc = function(c) {
                        var b = this,
                            d = [],
                            e = 0,
                            f = {
                                Uc: c.Uc,
                                result: [],
                                Cc: 0,
                                nodes: d
                            };
                        this.sc.push(f);
                        x(function(g) {
                            fj(b.l, g, function(h) {
                                var k = b.kb(h);
                                Wa(k) || (d.push(h), b.ya[k] && b.Z(h), b.ya[k] = {
                                    node: h,
                                    event: f,
                                    Vi: e
                                }, e += 1)
                            })
                        }, c.nodes)
                    };
                    a.prototype.Z = function(c) {
                        if (c === this.l) return 0;
                        var b = this.kb(c),
                            d = this.ya[b],
                            e = this.mh(b),
                            f = e.Xe,
                            g = e.wd,
                            h = e.Ye,
                            k = e.ih,
                            l = e.jh;
                        if (d) {
                            e = d.event;
                            d = d.Vi;
                            var m = et(this.l) === c;
                            k = k || c.nextSibling;
                            var p = l || c.previousSibling;
                            l = !m && k ? this.kb(k) : null;
                            p = !m && p ? this.kb(p) : null;
                            m = this.l;
                            k = this.options;
                            f = this.kb(f || c.parentNode || c.parentElement) || 0;
                            var q = g,
                                r = void 0;
                            void 0 === p && (p = null);
                            void 0 === l && (l = null);
                            void 0 === q && (q = {});
                            void 0 === r && (r = Ma(c));
                            if (X(r)) c = void 0;
                            else {
                                g = {
                                    id: b,
                                    prev: p !== f ? p : null,
                                    next: l !== f ? l : null,
                                    parent: f,
                                    name: r.toLowerCase(),
                                    node: c
                                };
                                if (Sf(c)) {
                                    if (h = mo(c, h), g.attributes = {}, g.content = h)
                                        if (c = vd(m, c)) g.content = "" !== ab(h) ? Do(m, h) : h, g.hidden = c
                                } else h = no(m, c, k, q, r), m = h.pb, g.attributes = h.Ag, m && (g.hidden = m), c.namespaceURI && eb(c.namespaceURI, "svg") && (g.namespace = c.namespaceURI);
                                c = g
                            }
                            if (X(c)) return;
                            this.ya[b] = null;
                            this.Hb.push(b);
                            e.result[d] = c;
                            e.Cc += 1;
                            e.nodes.length === e.Cc && e.Uc(e.result)
                        }
                        return b
                    };
                    a.prototype.flush = function() {
                        this.aa(!0)
                    };
                    a.prototype.hd = function() {
                        if (this.Hb.length) {
                            var c =
                                ec(this.Hb, this.Bi),
                                b = wg(this.l, 30);
                            c(b)
                        }
                    };
                    a.prototype.aa = function(c) {
                        var b = this;
                        if (mh(this.l)) {
                            var d = da(this.ya);
                            d = N(function(e, f) {
                                b.ya[f] && e.push(b.ya[f].node);
                                return e
                            }, [], d);
                            d = ec(d, this.Z);
                            c = c ? dk(D) : bk(this.l, 20);
                            d(c);
                            this.sc = ha(function(e) {
                                return e.Cc !== e.result.length
                            }, this.sc)
                        }
                    };
                    a.prototype.mh = function(c) {
                        if (Wa(c)) return {};
                        var b = this.Mb[c];
                        return b ? (this.Mb[c] = null, this.Hb.push(c), b) : {}
                    };
                    return a
                }(),
                Iu = ["input", "change", "keyup", "paste", "cut"],
                Ju = function(a) {
                    function c(b, d, e) {
                        b = a.call(this,
                            b, d, e) || this;
                        b.inputs = {};
                        b.rd = !1;
                        b.Jc = b.L.H(b.Jc, "ii");
                        b.Kc = b.L.H(b.Kc, "ir");
                        b.Pc = b.L.H(b.Pc, "ri");
                        b.Zc = b.L.H(b.Zc, "ur");
                        b.Gd = b.L.H(b.Gd, "ce");
                        b.Ac = b.L.H(b.Ac, "vc");
                        return b
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        var b = this,
                            d = this.G.sa();
                        this.rd = this.Hg();
                        x(function(e) {
                            e = e.toLowerCase();
                            d.F(e, "NA:", H(b.Jc, b));
                            d.F(e, "NR:", H(b.Kc, b))
                        }, Rf);
                        this.Ob = [this.eb.F(this.l.document, Iu, H(this.Gd, this)), function() {
                            x(function(e) {
                                e = e.toLowerCase();
                                d.ga(e, "NA:", b.Jc);
                                d.ga(e, "NR:", b.Kc)
                            }, Rf);
                            x(b.Zc, da(b.inputs))
                        }]
                    };
                    c.prototype.Zc = function(b) {
                        var d = this.inputs[b];
                        if (d) {
                            if (this.rd) {
                                var e = d.wi;
                                d = d.element;
                                e && this.l.Object.defineProperty(d, this.yc(d), e)
                            }
                            delete this.inputs[b]
                        }
                    };
                    c.prototype.Kc = function(b) {
                        b && this.Zc(b.data.id)
                    };
                    c.prototype.Jc = function(b) {
                        b && (b = b.data, this.Pc(b.node, b.id))
                    };
                    c.prototype.yc = function(b) {
                        return Ue(b) ? "checked" : "value"
                    };
                    c.prototype.Gd = function(b) {
                        if (b = b.target) {
                            var d = this.yc(b);
                            this.Ac(b[d], b)
                        }
                    };
                    c.prototype.Ac = function(b, d) {
                        var e = this.Z(d),
                            f = this.inputs[e];
                        if (!f && (f = this.Pc(f, e), !f)) return;
                        e = f.Jg;
                        var g = f.value,
                            h = this.yc(d),
                            k = !b || I(typeof b, ["string", "boolean", "number"]),
                            l = this.G.Ib().Md;
                        k && b !== g && (g = we(this.l, d, h, b, this.G.Ib()).value, e ? this.G.Y("event", {
                            target: this.Z(d),
                            checked: !!b
                        }, "change") : (e = Uc(this.l, d, l), l = e.hb, this.G.Y("event", {
                            value: g,
                            hidden: e.qb && !l,
                            target: this.Z(d)
                        }, "change")), f.value = b)
                    };
                    c.prototype.Pc = function(b, d) {
                        var e = this;
                        if (!Kf(b) || "__ym_input_override_test" === b.getAttribute("class") || this.inputs[d]) return null;
                        var f = Ue(b),
                            g = this.yc(b),
                            h = {
                                element: b,
                                Jg: f,
                                value: b[g]
                            };
                        this.inputs[d] = h;
                        this.rd && Tb(this.l, function() {
                            var k = e.l.Object.getOwnPropertyDescriptor(Object.getPrototypeOf(b), g) || {},
                                l = e.l.Object.getOwnPropertyDescriptor(b, g) || {},
                                m = z({}, k, l);
                            if (Da("((set)?(\\s?" + g + ")?)?", m.set)) {
                                try {
                                    e.l.Object.defineProperty(b, g, z({}, m, {
                                        configurable: !0,
                                        set: function(p) {
                                            e.Ac(p, this);
                                            return m.set.call(this, p)
                                        }
                                    }))
                                } catch (p) {}
                                h.wi = m
                            }
                        });
                        return h
                    };
                    c.prototype.Hg = function() {
                        var b = !0,
                            d = fb(this.l)("input");
                        try {
                            d = fb(this.l)("input");
                            d.value = "INPUT_VALUE";
                            d.style.setProperty("display", "none",
                                "important");
                            d.setAttribute("type", "text");
                            d.setAttribute("class", "__ym_input_override_test");
                            var e = this.l.Object.getOwnPropertyDescriptor(Object.getPrototypeOf(d), "value") || {},
                                f = this.l.Object.getOwnPropertyDescriptor(d, "value") || {},
                                g = z({}, e, f);
                            this.l.Object.defineProperty(d, "value", z({}, g, {
                                configurable: !0,
                                set: function(h) {
                                    return g.set.call(d, h)
                                }
                            }));
                            "INPUT_VALUE" !== d.value && (b = !1);
                            d.value = "INPUT_TEST";
                            "INPUT_TEST" !== d.value && (b = !1)
                        } catch (h) {
                            b = !1
                        }
                        return b
                    };
                    return c
                }(db),
                Ku = function(a) {
                    function c(b,
                        d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.Xa = {
                            width: 0,
                            height: 0,
                            pageHeight: 0,
                            pageWidth: 0,
                            orientation: 0
                        };
                        b.ia.push([
                            ["resize"], b.ui
                        ]);
                        b.ia.push([
                            ["orientationchange"], b.ri
                        ]);
                        return b
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        a.prototype.start.call(this);
                        this.Nf()
                    };
                    c.prototype.ui = function() {
                        var b = this.Ed();
                        this.Jh(b) && (this.Xa = b, this.Of(b))
                    };
                    c.prototype.ri = function() {
                        var b = this.Ed();
                        this.Xa.orientation !== b.orientation && (this.Xa = b, this.Fi(b))
                    };
                    c.prototype.qf = function(b) {
                        return !b.height || !b.width || !b.pageWidth || !b.pageHeight
                    };
                    c.prototype.Jh = function(b) {
                        return b.height !== this.Xa.height || b.width !== this.Xa.width
                    };
                    c.prototype.Ed = function() {
                        var b = this.G.jb(),
                            d = Pc(this.l),
                            e = d[0];
                        d = d[1];
                        b = b.Dd();
                        return {
                            width: e,
                            height: d,
                            pageWidth: b ? b.scrollWidth : 0,
                            pageHeight: b ? b.scrollHeight : 0,
                            orientation: this.G.jb().vh()
                        }
                    };
                    c.prototype.Fi = function(b) {
                        var d;
                        void 0 === d && (d = this.G.stamp());
                        this.G.Y("event", {
                            width: b.width,
                            height: b.height,
                            orientation: b.orientation
                        }, "deviceRotation", d)
                    };
                    c.prototype.Of = function(b, d) {
                        void 0 === d && (d = this.G.stamp());
                        this.G.Y("event", {
                            width: b.width,
                            height: b.height,
                            pageWidth: b.pageWidth,
                            pageHeight: b.pageHeight
                        }, "resize", d)
                    };
                    c.prototype.Nf = function() {
                        var b = this.Ed();
                        this.qf(b) ? U(this.l, H(this.Nf, this), 300) : (this.qf(this.Xa) && (this.Xa = b), this.Of(b, 0))
                    };
                    return c
                }(db),
                gf = function() {
                    function a(c) {
                        this.index = 0;
                        this.wb = {};
                        this.l = c
                    }
                    a.prototype.nc = function(c, b, d) {
                        void 0 === d && (d = {});
                        var e = ja(this.l),
                            f = this.index;
                        this.index += 1;
                        this.wb[f] = {
                            Ka: 0,
                            Ub: !1,
                            gh: c,
                            dd: [],
                            Qd: e(Z)
                        };
                        var g = this;
                        return function() {
                            var h = Pa(arguments),
                                k = d.gb && !g.wb[f].Ub,
                                l = g.wb[f];
                            la(g.l, l.Ka);
                            l.dd = h;
                            l.Ub = !0;
                            var m = e(Z);
                            if (k || m - l.Qd >= b) c.apply(void 0, h), l.Qd = m;
                            l.Ka = U(g.l, function() {
                                k || (c.apply(void 0, h), l.Qd = e(Z));
                                l.Ub = !1;
                                l.dd = []
                            }, b, "th")
                        }
                    };
                    a.prototype.flush = function() {
                        var c = this;
                        x(function(b) {
                            var d = c.wb[b],
                                e = d.Ka,
                                f = d.gh,
                                g = d.dd;
                            d.Ub && (c.wb[b].Ub = !1, f.apply(void 0, g), la(c.l, e))
                        }, da(this.wb))
                    };
                    return a
                }(),
                Lu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.bg = [];
                        d.He = {
                            x: 0,
                            y: 0
                        };
                        d.Ca = new gf(b);
                        d.Nc = d.L.H(d.Nc, "o");
                        d.ia.push([
                            ["scroll"], d.vi
                        ]);
                        return d
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        a.prototype.start.call(this);
                        this.G.Y("event", {
                            x: Math.max(this.l.scrollX, 0),
                            y: Math.max(this.l.scrollY, 0),
                            page: !0,
                            target: -1
                        }, "scroll", 0)
                    };
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        this.Ca.flush()
                    };
                    c.prototype.vi = function(b) {
                        if (this.G.jb().lf()) this.Nc(b);
                        else {
                            var d = b.target,
                                e = ha(function(f) {
                                    return f[0] === d
                                }, this.bg).pop();
                            e ? e = e[1] : (e = this.Ca.nc(H(this.Nc, this), 100, {
                                gb: !0
                            }), this.bg.push([d, e]));
                            e(b)
                        }
                    };
                    c.prototype.Nc = function(b) {
                        var d = this.G.jb().Dd();
                        b = b.target;
                        var e = this.Jb(b);
                        d = d === b || this.l === b || this.l.document === b;
                        var f = Math.max(e.left, 0);
                        e = Math.max(e.top, 0);
                        if (d) {
                            if (this.He.x === f && this.He.y === e) return;
                            this.He = {
                                x: f,
                                y: e
                            }
                        }
                        this.G.Y("event", {
                            x: f,
                            y: e,
                            page: d,
                            target: d ? -1 : this.Z(b)
                        }, "scroll")
                    };
                    c.prototype.Jb = function(b) {
                        var d = {
                            left: 0,
                            top: 0
                        };
                        if (!b) return d;
                        if (b.window === b) return {
                            top: b.scrollY || 0,
                            left: b.scrollX || 0
                        };
                        var e = b.ownerDocument || b,
                            f = b.documentElement,
                            g = e.defaultView || e.parentWindow,
                            h = e.body;
                        return b !== e || (b = this.G.jb().Dd(), b) ? I(b, [f, h]) ? {
                            top: b.scrollTop ||
                                g.scrollY,
                            left: b.scrollLeft || g.scrollX
                        } : {
                            top: b.scrollTop || 0,
                            left: b.scrollLeft || 0
                        } : d
                    };
                    return c
                }(db),
                Mu = ["mousemove", "mousedown", "mouseup", "click"],
                Nu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.ia.push([Mu, d.oi]);
                        d.Ca = new gf(b);
                        d.Ic = d.L.H(d.Ic, "n");
                        d.Pi = d.L.H(d.Ca.nc(H(d.Ic, d), 100), "t");
                        return d
                    }
                    Na(c, a);
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        this.Ca.flush()
                    };
                    c.prototype.oi = function(b) {
                        var d = null;
                        try {
                            d = b.type
                        } catch (e) {
                            return
                        }
                        "mousemove" === d ? this.Pi(b) : this.Ic(b)
                    };
                    c.prototype.Ic =
                        function(b) {
                            var d = b.type,
                                e = b.clientX;
                            e = void 0 === e ? null : e;
                            var f = b.clientY;
                            f = void 0 === f ? null : f;
                            b = b.target || this.l.document.elementFromPoint(e, f);
                            this.G.Y("event", {
                                x: e || 0,
                                y: f || 0,
                                target: this.Z(b)
                            }, d)
                        };
                    return c
                }(db),
                Ou = ["focus", "blur"],
                Pu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.ia.push([Ou, b.hh]);
                        return b
                    }
                    Na(c, a);
                    c.prototype.hh = function(b) {
                        var d = b.target;
                        b = b.type;
                        this.G.Y("event", {
                            target: this.Z(d === this.l ? this.l.document.documentElement : d)
                        }, b)
                    };
                    return c
                }(db),
                Qu = v(function(a) {
                    var c = oa(a.getSelection,
                        "getSelection");
                    return c ? H(c, a) : D
                }),
                Ru = w(Qu, ma),
                Su = ["mousemove", "touchmove", "mousedown", "touchdown", "select"],
                Tu = /text|search|password|tel|url/,
                Uu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.Id = !1;
                        b.ia.push([Su, b.Hh]);
                        return b
                    }
                    Na(c, a);
                    c.prototype.Hh = function(b) {
                        var d = this.G,
                            e = b.type,
                            f = b.which;
                        b = b.target;
                        if ("mousemove" !== e || 1 === f)(e = "select" === e ? this.Ah(b) : this.yh()) && e.start !== e.end ? (this.Id = !0, d.Y("event", e, "selection")) : this.Id && (this.Id = !1, d.Y("event", {
                            start: 0,
                            end: 0
                        }, "selection"))
                    };
                    c.prototype.yh = function() {
                        var b = Ru(this.l);
                        if (b && 0 < b.rangeCount) {
                            b = b.getRangeAt(0) || this.l.document.createRange();
                            var d = this.Z(b.startContainer),
                                e = this.Z(b.endContainer);
                            if (!X(d) && !X(e)) return {
                                start: b.startOffset,
                                end: b.endOffset,
                                startNode: d,
                                endNode: e
                            }
                        }
                    };
                    c.prototype.Ah = function(b) {
                        if (Tu.test(b.type || "")) {
                            var d = this.Z(b);
                            if (!X(d)) return {
                                start: b.selectionStart,
                                end: b.selectionEnd,
                                target: d
                            }
                        }
                    };
                    return c
                }(db),
                Vu = {
                    focus: "windowfocus",
                    blur: "windowblur"
                },
                Wu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) ||
                            this;
                        b.visibility = null;
                        X(b.l.document.hidden) ? X(b.l.document.msHidden) ? X(b.l.document.webkitHidden) || (b.visibility = {
                            hidden: "webkitHidden",
                            event: "webkitvisibilitychange"
                        }) : b.visibility = {
                            hidden: "msHidden",
                            event: "msvisibilitychange"
                        } : b.visibility = {
                            hidden: "hidden",
                            event: "visibilitychange"
                        };
                        b.handleEvent = b.L.H(b.handleEvent, "e");
                        return b
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        this.Ob = [this.eb.F(this.l, this.visibility ? [this.visibility.event] : ["focus", "blur"], H(this.handleEvent, this))]
                    };
                    c.prototype.handleEvent =
                        function(b) {
                            this.G.Y("event", {}, Vu[this.visibility ? this.l.document[this.visibility.hidden] ? "blur" : "focus" : b.type])
                        };
                    return c
                }(db),
                Xu = ["touchmove", "touchstart", "touchend", "touchcancel", "touchforcechange"],
                Yu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.Xc = {};
                        d.scrolling = !1;
                        d.Lf = 0;
                        d.ia.push([
                            ["scroll"], d.Ei, d.l.document
                        ]);
                        d.ia.push([Xu, d.Ri, d.l.document]);
                        d.Ca = new gf(b);
                        d.Nb = d.L.H(d.Nb, "nh");
                        d.Qi = d.L.H(d.Ca.nc(d.Nb, d.G.jb().lf() ? 0 : 50, {
                            gb: !0
                        }), "th");
                        return d
                    }
                    Na(c, a);
                    c.prototype.Ei = function() {
                        var b =
                            this;
                        this.scrolling = !0;
                        la(this.l, this.Lf);
                        this.Lf = U(this.l, function() {
                            b.scrolling = !1
                        }, 150)
                    };
                    c.prototype.Ri = function(b) {
                        var d = this,
                            e = "touchcancel" === b.type || "touchend" === b.type;
                        b.changedTouches && 0 < b.changedTouches.length && x(function(f) {
                            var g = d.Ch(f);
                            f.__ym_touch_id = g;
                            e && delete d.Xc[f.identifier]
                        }, Ba(b.changedTouches));
                        "touchmove" === b.type ? this.scrolling ? this.Nb(b) : this.Qi(b, this.G.stamp()) : this.Nb(b)
                    };
                    c.prototype.Ch = function(b) {
                        this.Xc[b.identifier] || (this.Xc[b.identifier] = fi());
                        return this.Xc[b.identifier]
                    };
                    c.prototype.Nb = function(b, d) {
                        void 0 === d && (d = this.G.stamp());
                        var e = b.type,
                            f = A(function(g) {
                                return {
                                    id: g.__ym_touch_id,
                                    x: Math.round(g.clientX),
                                    y: Math.round(g.clientY),
                                    force: g.force
                                }
                            }, Ba(b.changedTouches));
                        0 < f.length && this.G.Y("event", {
                            touches: f,
                            target: this.Z(b.target)
                        }, e, d)
                    };
                    return c
                }(db),
                Zu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.ia.push([
                            ["load"], b.ni, b.l.document
                        ]);
                        return b
                    }
                    Na(c, a);
                    c.prototype.ni = function(b) {
                        b = b.target;
                        "IMG" === Ma(b) && b.getAttribute("srcset") && this.G.Y("mutation", {
                            target: this.Z(b),
                            attributes: {
                                src: b.currentSrc
                            }
                        }, "ac")
                    };
                    return c
                }(db),
                $u = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.mg = 1;
                        d.Ca = new gf(b);
                        d.ec = d.L.H(d.ec, "z");
                        return d
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        if (this.hf()) {
                            a.prototype.start.call(this);
                            this.ec();
                            var b = this.eb.F(n(this.l, "visualViewport"), ["resize"], this.Ca.nc(this.ec, 10));
                            this.Ob.push(b)
                        }
                    };
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        this.Ca.flush()
                    };
                    c.prototype.ec = function() {
                        var b = this.hf();
                        b && b !== this.mg && (this.mg =
                            b, this.Gi(b))
                    };
                    c.prototype.hf = function() {
                        var b = me(this.l);
                        return b ? b[2] : null
                    };
                    c.prototype.Gi = function(b) {
                        var d = bg(this.l);
                        this.G.Y("event", {
                            x: d.x,
                            y: d.y,
                            level: b
                        }, "zoom")
                    };
                    return c
                }(db),
                ee, hf = {
                    91: "super",
                    93: "super",
                    224: "super",
                    18: "alt",
                    17: "ctrl",
                    16: "shift",
                    9: "tab",
                    8: "backspace",
                    46: "delete"
                },
                Ul = {
                    "super": 1,
                    pj: 2,
                    alt: 3,
                    shift: 4,
                    Jj: 5,
                    "delete": 6,
                    nj: 6
                },
                av = [4, 9, 8, 32, 37, 38, 39, 40, 46],
                Vl = (ee = {}, ee["1"] = {
                        91: "&#8984;",
                        93: "&#8984;",
                        224: "&#8984;",
                        18: "&#8997;",
                        17: "&#8963;",
                        16: "&#8679;",
                        9: "&#8677;",
                        8: "&#9003;",
                        46: "&#9003;"
                    },
                    ee["2"] = {
                        91: "&#xff;",
                        93: "&#xff;",
                        224: "&#xff;",
                        18: "Alt",
                        17: "Ctrl",
                        16: "Shift",
                        9: "Tab",
                        8: "Backspace",
                        46: "Delete"
                    }, ee.ai = {
                        32: "SPACEBAR",
                        37: "&larr;",
                        38: "&uarr;",
                        39: "&rarr;",
                        40: "&darr;",
                        13: "Enter"
                    }, ee),
                bv = /flash/,
                cv = /ym-disable-keys/,
                dv = /^&#/,
                ev = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.mb = {};
                        d.Oa = 0;
                        d.Fa = [];
                        d.$f = [];
                        d.qc = 0;
                        d.Ef = 0;
                        d.ia.push([
                            ["keydown"], d.Eh
                        ]);
                        d.ia.push([
                            ["keyup"], d.Fh
                        ]);
                        d.wg = -1 !== kc(n(b, "navigator.appVersion") || "", "Mac") ? "1" : "2";
                        d.Gc = d.L.H(d.Gc, "v");
                        d.ud = d.L.H(d.ud, "ec");
                        d.Tc = d.L.H(d.Tc, "sk");
                        d.Bd = d.L.H(d.Bd, "gk");
                        d.te = d.L.H(d.te, "sc");
                        d.dc = d.L.H(d.dc, "cc");
                        d.reset = d.L.H(d.reset, "r");
                        d.Qc = d.L.H(d.Qc, "rs");
                        return d
                    }
                    Na(c, a);
                    c.prototype.Eh = function(b) {
                        if (this.Gc(b) && !this.Th(b)) {
                            var d = b.keyCode;
                            b.repeat || this.mb[d] || (this.mb[b.keyCode] = !0, hf[b.keyCode] && !this.Oa ? (this.Oa += 1, this.te(b), this.reset(300)) : this.Oa ? (this.Eg(), this.je(b), this.ud()) : (this.reset(), this.je(b)))
                        }
                    };
                    c.prototype.Fh = function(b) {
                        if (this.Gc(b)) {
                            var d = b.keyCode,
                                e = hf[b.keyCode];
                            this.mb[b.keyCode] && (this.mb[d] = !1);
                            e && this.Oa && (this.Oa = 0, this.mb = {});
                            1 === this.Fa.length && (b = this.Fa[0], I(b.keyCode, av) && (this.Tc([b], !0), this.reset()));
                            this.Fa = ha(w(T("keyCode"), Aa(d), Hc), this.Fa);
                            la(this.l, this.qc)
                        }
                    };
                    c.prototype.Gc = function(b) {
                        var d = this.l.document.activeElement;
                        d = d && "OBJECT" === d.nodeName && bv.test(d.getAttribute("type") || "");
                        b = b.target;
                        if (!b) return !d;
                        b = "INPUT" === b.nodeName && "password" === b.getAttribute("type") && cv.test(b.className);
                        return !d && !b
                    };
                    c.prototype.ud = function() {
                        this.$f = this.Fa.slice(0);
                        la(this.l, this.qc);
                        this.qc = U(this.l, u(this.$f, H(this.Tc, this)), 0, "e.c")
                    };
                    c.prototype.Tc = function(b, d) {
                        void 0 === d && (d = !1);
                        if (1 < b.length || d) {
                            var e = this.Bd(b);
                            this.G.Y("event", {
                                keystrokes: e
                            }, "keystroke")
                        }
                    };
                    c.prototype.Bd = function(b) {
                        var d = this;
                        b = A(function(e) {
                            e = e.keyCode;
                            var f = hf[e],
                                g = d.uh(e);
                            return {
                                id: e,
                                key: g,
                                isMeta: !!f && dv.test(g),
                                modifier: f
                            }
                        }, b);
                        return ze(function(e, f) {
                            return (Ul[e.modifier] || 100) - (Ul[f.modifier] || 100)
                        }, b)
                    };
                    c.prototype.uh = function(b) {
                        return Vl[this.wg][b] || Vl.ai[b] || String.fromCharCode(b)
                    };
                    c.prototype.je =
                        function(b) {
                            I(b, this.Fa) || this.Fa.push(b)
                        };
                    c.prototype.te = function(b) {
                        this.je(b);
                        this.dc()
                    };
                    c.prototype.dc = function() {
                        this.Oa ? U(this.l, this.dc, 100) : this.Fa = []
                    };
                    c.prototype.Eg = function() {
                        la(this.l, this.Ef)
                    };
                    c.prototype.reset = function(b) {
                        b ? this.Ef = U(this.l, H(this.Qc, this), b) : this.Qc()
                    };
                    c.prototype.Qc = function() {
                        this.Oa = 0;
                        this.Fa = [];
                        this.mb = {};
                        la(this.l, this.qc)
                    };
                    c.prototype.Th = function(b) {
                        return b.target && "INPUT" === b.target.nodeName ? b.shiftKey || 32 === b.keyCode || "shift" === hf[b.keyCode] : !1
                    };
                    return c
                }(db),
                lo = ["sr", "sd", "\u043d"],
                fv = /allow-same-origin/,
                gv = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.Xb = [];
                        d.xd = {};
                        d.Xd = d.L.H(d.Xd, "fi");
                        d.Yd = d.L.H(d.Yd, "sd");
                        d.Zd = d.L.H(d.Zd, "src");
                        d.za = new b.MutationObserver(d.Zd);
                        return d
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        a.prototype.start.call(this);
                        this.G.Ib().fc && this.G.sa().F("iframe", "NA:", H(this.Xd, this));
                        this.G.df().zd().F(["sdr"], H(this.Yd, this))
                    };
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        x(function(b) {
                            b.G.stop()
                        }, this.Xb)
                    };
                    c.prototype.Zd =
                        function(b) {
                            var d = b.pop().target;
                            if (b = ub(function(f) {
                                    return f.kf === d
                                }, this.Xb)) {
                                this.Xb = ha(function(f) {
                                    return f.kf !== d
                                }, this.Xb);
                                var e = b.G.Ad();
                                try {
                                    b.G.stop()
                                } catch (f) {}
                                this.lc(d, e)
                            }
                        };
                    c.prototype.Xd = function(b) {
                        if (b) {
                            var d = b.data.node;
                            this.za.observe(d, {
                                attributes: !0,
                                attributeFilter: ["src"]
                            });
                            this.lc(d, b.data.id)
                        }
                    };
                    c.prototype.lc = function(b, d) {
                        var e = this;
                        this.Rh(b) && Nb(this.l, b)(Ra(D, function() {
                            var f = e.G.lc(b.contentWindow, d);
                            e.Xb.push({
                                G: f,
                                kf: b
                            })
                        }))
                    };
                    c.prototype.Yd = function(b) {
                        var d = this,
                            e = b.frameId;
                        b = b.data;
                        this.xd[e] || (this.xd[e] = {
                            data: []
                        });
                        var f = this.xd[e];
                        f.data = f.data.concat(b);
                        this.l.isNaN(f.qd) && x(function(g) {
                            "page" === g.type && (f.qd = g.data.recordStamp - d.G.ef())
                        }, f.data);
                        this.l.isNaN(f.qd) || (this.G.aa(A(function(g) {
                            g.stamp += f.qd;
                            g.stamp = d.l.Math.max(0, g.stamp);
                            return g
                        }, f.data)), f.data = [])
                    };
                    c.prototype.Rh = function(b) {
                        var d = b.getAttribute("src"),
                            e = b.getAttribute("sandbox");
                        return b.getAttribute("_ym_ignore") || e && !e.match(fv) || d && "about:blank" !== d && (d = Tc(this.l, d).host) && S(this.l).host !==
                            d ? !1 : n(b, "contentWindow.location.href")
                    };
                    return c
                }(db),
                hv = v(function(a) {
                    var c = n(a, "sessionStorage");
                    if (!c) return null;
                    try {
                        var b = c.getItem("__ym_tab_guid");
                        c = !1;
                        var d = n(a, "opener.sessionStorage");
                        try {
                            c = !!d && b === d.getItem("__ym_tab_guid")
                        } catch (e) {
                            c = !0
                        }
                        if (!b || c) b = fi(), a.sessionStorage.setItem("__ym_tab_guid", b);
                        return b
                    } catch (e) {
                        return null
                    }
                }),
                iv = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.ne = b.L.H(b.ne, "ps");
                        return b
                    }
                    Na(c, a);
                    c.prototype.start = function() {
                        this.G.sa().Bc({
                            nodes: [this.l.document.documentElement],
                            Uc: this.ne
                        })
                    };
                    c.prototype.ne = function(b) {
                        var d = this.G.xh(),
                            e = d.nh(),
                            f = S(this.l),
                            g = f.host,
                            h = f.protocol;
                        f = f.pathname;
                        var k = Pc(this.l),
                            l = k[0];
                        k = k[1];
                        this.G.Y("page", {
                            content: A(function(m) {
                                m.node = void 0;
                                return m
                            }, b),
                            base: e || "",
                            hasBase: !!e,
                            viewport: {
                                width: l,
                                height: k
                            },
                            title: this.l.document.title,
                            doctype: d.ph() || "",
                            address: this.l.location.href,
                            ua: this.l.navigator.userAgent,
                            referrer: this.l.document.referrer,
                            screen: {
                                width: this.l.screen.width,
                                height: this.l.screen.height
                            },
                            location: {
                                host: g,
                                protocol: h,
                                path: f
                            },
                            recordStamp: this.G.ef(),
                            tabId: hv(this.l)
                        }, "page", 0)
                    };
                    return c
                }(db),
                jv = ["addRule", "removeRule", "insertRule", "deleteRule"],
                nh = [
                    [function(a) {
                        function c(b, d, e) {
                            b = a.call(this, b, d, e) || this;
                            b.ab = {};
                            b.Yb = {};
                            b.Me = 0;
                            b.Lc = b.L.H(b.Lc, "a");
                            b.vb = b.L.H(b.vb, "sr");
                            b.Mc = b.L.H(b.Mc, "r");
                            b.aa = b.L.H(b.aa, "d");
                            return b
                        }
                        Na(c, a);
                        c.prototype.start = function() {
                            var b = this.G.sa();
                            b.F("style", "NA:", this.Lc);
                            b.F("style", "NR:", this.Mc);
                            this.aa()
                        };
                        c.prototype.stop = function() {
                            var b = this;
                            a.prototype.stop.call(this);
                            var d = this.G.sa();
                            d.ga("style", "NA:", this.Lc);
                            d.ga("style", "NR:", this.Mc);
                            this.aa();
                            la(this.l, this.Me);
                            x(function(e) {
                                b.ab[e].sheet && b.Hf(b.ab[e].sheet)
                            }, da(this.ab));
                            this.ab = {}
                        };
                        c.prototype.aa = function() {
                            var b = this;
                            x(function(d) {
                                var e = d[0];
                                d = d[1];
                                if (d.length) {
                                    for (var f = [], g = d[0].stamp, h = [], k = 0; k < d.length; k += 1) {
                                        var l = d[k],
                                            m = l.stamp;
                                        delete l.stamp;
                                        m <= g + 50 ? f.push(l) : (h.push(f), g = m, f = [l])
                                    }
                                    f.length && h.push(f);
                                    h.length && x(function(p) {
                                        b.G.Y("event", {
                                            target: Ha(e),
                                            changes: p
                                        }, "stylechange", g)
                                    }, h);
                                    delete b.Yb[e]
                                }
                            }, La(this.Yb));
                            this.Me = U(this.l, this.aa, 100)
                        };
                        c.prototype.vb = function(b, d, e, f, g) {
                            void 0 === f && (f = "");
                            void 0 === g && (g = -1);
                            this.Yb[b] || (this.Yb[b] = []);
                            this.Yb[b].push({
                                op: d,
                                style: f,
                                index: g,
                                stamp: e
                            })
                        };
                        c.prototype.xi = function(b, d) {
                            var e = this,
                                f = b.addRule,
                                g = b.removeRule,
                                h = b.insertRule,
                                k = b.deleteRule;
                            O(f) && (b.addRule = function(l, m, p) {
                                e.vb(d, "a", e.G.stamp(), l + "{" + m + "}", p);
                                return f.call(b, l, m, p)
                            });
                            O(g) && (b.removeRule = function(l) {
                                e.vb(d, "r", e.G.stamp(), "", l);
                                return g.call(b, l)
                            });
                            O(h) && (b.insertRule = function(l, m) {
                                e.vb(d, "a",
                                    e.G.stamp(), l, m);
                                return h.call(b, l, m)
                            });
                            O(k) && (b.deleteRule = function(l) {
                                e.vb(d, "r", e.G.stamp(), "", l);
                                return k.call(b, l)
                            })
                        };
                        c.prototype.Hf = function(b) {
                            var d = this;
                            x(function(e) {
                                var f = d.l.CSSStyleSheet.prototype[e];
                                O(f) && (b[e] = H(f, b))
                            }, jv)
                        };
                        c.prototype.Zg = function(b) {
                            try {
                                return b.cssRules || b.rules
                            } catch (d) {
                                return null
                            }
                        };
                        c.prototype.Lc = function(b) {
                            var d = b.data;
                            b = d.id;
                            d = d.node;
                            if (d.sheet && !d.getAttribute("src") && !d.innerText) {
                                var e = d.sheet,
                                    f = this.Zg(e);
                                if (f && f.length) {
                                    for (var g = [], h = 0; h < f.length; h += 1) g.push({
                                        style: f[h].cssText,
                                        index: h,
                                        op: "a"
                                    });
                                    this.G.Y("event", {
                                        changes: g,
                                        target: b
                                    }, "stylechange")
                                }
                                this.xi(e, b);
                                this.ab[b] = d
                            }
                        };
                        c.prototype.Mc = function(b) {
                            b = b.data.id;
                            var d = this.ab[b];
                            d && (delete this.ab[b], d.sheet && this.Hf(d.sheet))
                        };
                        return c
                    }(db), "ss"],
                    [Ju, "in"],
                    [Gu, "mu"],
                    [Ku, "r"],
                    [Lu, "sc"],
                    [Nu, "mo"],
                    [Pu, "f"],
                    [Uu, "se"],
                    [Wu, "wf"],
                    [Yu, "t"],
                    [Zu, "src"],
                    [$u, "z"],
                    [ev, "ks"]
                ];
            nh.push([gv, "if"]);
            nh.push([iv, "pa"]);
            var kv = v(function(a) {
                    var c = a.document;
                    return {
                        Dd: function() {
                            if (c.scrollingElement) return c.scrollingElement;
                            var b = 0 === ib(c.compatMode,
                                "CSS1") ? c.documentElement : c.body;
                            return n(c, "documentElement.scrollHeight") >= n(c, "body.scrollHeight") ? b : null
                        },
                        vh: function() {
                            var b = a.screen;
                            if (!b) return 0;
                            var d = ub(u(b, n), ["orientation", "mozOrientation", "msOrientation"]);
                            return n(b, d + ".angle") || 0
                        },
                        Aj: u(a, sb),
                        lf: u(a, Bd),
                        zj: u(a, Ye)
                    }
                }),
                lv = function() {
                    function a(c, b) {
                        var d = this;
                        this.Lb = 0;
                        this.pd = [];
                        this.Kb = null;
                        this.va = this.Zb = this.Yf = !1;
                        this.recordStamp = 0;
                        this.xh = function() {
                            return d.page
                        };
                        this.Ad = function() {
                            return d.Lb
                        };
                        this.ef = function() {
                            return d.recordStamp
                        };
                        this.th = function() {
                            return d.eb
                        };
                        this.df = function() {
                            return d.Kb
                        };
                        this.sa = function() {
                            return d.Jd
                        };
                        this.stamp = function() {
                            return d.xe ? d.l.Math.max(d.xe(Z) - d.recordStamp, 0) : 0
                        };
                        this.Ib = function() {
                            return d.options
                        };
                        this.jb = function() {
                            return d.Bg
                        };
                        this.Y = function(f, g, h, k) {
                            void 0 === k && (k = d.stamp());
                            f = d.sh(f, g, h, k);
                            d.aa(f)
                        };
                        this.sh = function(f, g, h, k) {
                            void 0 === k && (k = d.stamp());
                            return {
                                type: f,
                                data: g,
                                stamp: k,
                                frameId: d.Lb,
                                event: h
                            }
                        };
                        this.aa = function(f) {
                            f = R(f) ? f : [f];
                            d.Yf && !d.Zb ? d.va ? (f = A(function(g) {
                                return g.frameId ?
                                    g : z(g, {
                                        frameId: d.Lb
                                    })
                            }, f), d.df().Pf(f)) : d.Vb(f) : d.pd = d.pd.concat(f)
                        };
                        this.l = c;
                        var e = Mf(c, this, "R");
                        this.ue = e.H(this.ue, "s");
                        this.aa = e.H(this.aa, "sd");
                        e = J(c);
                        e.C("wv2e") && fe();
                        e.D("wv2e", !0);
                        this.options = b;
                        this.eb = fa(c);
                        this.Jd = new Hu(this.l, b);
                        this.Bg = kv(c);
                        this.Oe = A(function(f) {
                            return new f[0](c, d, f[1])
                        }, nh);
                        this.Oh();
                        this.page = jo(this.l);
                        this.ue()
                    }
                    a.prototype.start = function(c) {
                        this.Yf = !0;
                        this.Vb = c;
                        this.Mf()
                    };
                    a.prototype.stop = function() {
                        mh(this.l) && (x(function(c) {
                                return c.stop()
                            }, this.Oe), this.Jd.stop(),
                            this.Kb && this.Kb.stop(), this.va || this.Y("event", {}, "eof"))
                    };
                    a.prototype.lc = function(c, b) {
                        var d = new a(c, z({}, this.options, {
                            frameId: b
                        }));
                        d.start(D);
                        return d
                    };
                    a.prototype.Oh = function() {
                        var c = this;
                        this.va = !!this.options.frameId;
                        this.Lb = this.options.frameId || 0;
                        this.Zb = !this.va;
                        var b = this.options.gg || [];
                        b.push(S(this.l).host);
                        this.Kb = ko(this.l, this, b);
                        b = this.Kb.zd();
                        sb(this.l) ? this.Zb && b.F(["i"], function(d) {
                            c.va = d.va;
                            c.Zb = !1;
                            d.frameId && (c.Lb = d.frameId);
                            c.Mf()
                        }) : this.Zb = this.va = !1
                    };
                    a.prototype.Mf = function() {
                        var c =
                            Ze(this.pd);
                        this.aa(c)
                    };
                    a.prototype.ue = function() {
                        this.xe = ig(this.l);
                        this.recordStamp = this.xe(Z);
                        x(function(c) {
                            c.start()
                        }, this.Oe);
                        this.Jd.start()
                    };
                    return a
                }(),
                mv = function() {
                    return function(a, c, b) {
                        var d = this;
                        this.fd = this.Qb = !1;
                        this.Wa = [];
                        this.tf = [];
                        this.Re = [];
                        this.send = function(e, f, g) {
                            e = d.sender(e, d.kc);
                            f && g && e.then(f, g);
                            return e
                        };
                        this.we = function(e, f, g) {
                            return new K(function(h, k) {
                                e.push([f, h, k, g])
                            })
                        };
                        this.Ih = function() {
                            d.Wa = ze(function(g, h) {
                                return g[3].partNum - h[3].partNum
                            }, d.Wa);
                            var e = N(function(g,
                                    h, k) {
                                    h = h[3];
                                    return g && k + 1 === h.partNum
                                }, !0, d.Wa),
                                f = !!d.Wa[d.Wa.length - 1][3].end;
                            return e && f
                        };
                        this.vd = function(e) {
                            uh(d.l, e.slice(), function(f) {
                                d.send(f[0], f[1], f[2])
                            }, 20, "s.w2.sf.fes");
                            Ze(e)
                        };
                        this.fh = function() {
                            d.fd || (d.fd = !0, d.vd(d.tf), d.vd(d.Re))
                        };
                        this.Ig = function(e) {
                            return N(function(f, g) {
                                var h = "page" === g.type && !g.frameId,
                                    k = "eof" === g.data.type || "eof" === g.event,
                                    l = h && !!g.partNum;
                                return {
                                    ld: f.ld || l,
                                    kd: f.kd || h,
                                    jd: f.jd || k
                                }
                            }, {
                                kd: !1,
                                jd: !1,
                                ld: !1
                            }, e)
                        };
                        this.Gh = function(e, f, g) {
                            g ? (e = d.we(d.Wa, e, f[0]), d.Ih() &&
                                (d.vd(d.Wa), d.Qb = !0)) : (d.Qb = !0, e = d.send(e));
                            return e
                        };
                        this.ff = function(e, f, g) {
                            var h;
                            f = {
                                J: (h = {}, h["wv-part"] = "" + g, h["wv-type"] = d.Hi, h),
                                K: Ja(),
                                ba: {
                                    da: f
                                }
                            };
                            e && f.K.D("bt", 1);
                            return f
                        };
                        this.Xg = function(e, f, g) {
                            e = d.ff(!1, e, g);
                            return d.Qb ? d.send(e) : d.we(d.Re, e, f)
                        };
                        this.bi = function(e, f, g) {
                            e = d.ff(!0, e, g);
                            if (d.Qb) return d.send(e);
                            var h = d.Ig(f);
                            g = h.kd;
                            var k = h.jd;
                            h = h.ld;
                            var l;
                            g && (l = d.Gh(e, f, h));
                            d.fd ? g || (l = d.send(e)) : (g || (l = d.we(d.tf, e, f)), (d.Qb || k) && d.fh());
                            return l
                        };
                        this.l = a;
                        this.Hi = b;
                        this.sender = va(a, "W", c);
                        this.kc = c
                    }
                }(),
                Wl = v(function(a) {
                    var c = J(a),
                        b = c.C("isEU");
                    if (X(b)) {
                        var d = Ha(ye(a, "is_gdpr") || "");
                        if (I(d, [0, 1])) c.D("isEU", d), b = !!d;
                        else if (a = Oa(a).C("wasSynced"), a = n(a, "params.eu")) c.D("isEU", a), b = !!a
                    }
                    return b
                }, function(a) {
                    return J(a).C("isEU")
                }),
                Hf = B("i.e", Wl),
                nv = B("i.ep", function(a) {
                    Wl(a)
                }),
                ov = B("w2", function(a, c) {
                    function b() {
                        h = !0
                    }
                    var d = J(a),
                        e = L(c);
                    if (!c.zb || qd(a) || !a.MutationObserver || !Da("Element", a.Element)) return D;
                    Da("MutationObserver", a.MutationObserver) || pc(a, e).warn("w2mo");
                    var f = Ga(function(k,
                            l) {
                            pa(c, l)["catch"](k)
                        }),
                        g = Nb(a)(Ug(C([a, c], ho)))(ml(function(k) {
                            return new lv(a, k)
                        })),
                        h = !1;
                    Fr([g, f])(Ra(E(a, "wv2.R.c"), function(k) {
                        var l = k[0];
                        k = k[1];
                        if (!h) {
                            b = function() {
                                h || (h = !0, l && l.stop())
                            };
                            var m = d.C("wv2Counter");
                            if (!hi(a, k) || m) b();
                            else if (fa(a).F(a, ["beforeunload", "unload"], b), d.D("wv2Counter", e), d.D("stopRecorder", b), k = ti(a, "7", "6")) {
                                m = new mv(a, c, k.type);
                                var p = Tl.af(e, "m", H(m.bi, m), k, a),
                                    q = Tl.af(e, "e", H(m.Xg, m), k, a);
                                k = io();
                                m = k.li;
                                q.F("ag", k.zg);
                                q.F("p", m);
                                p.F("see", function(t) {
                                    var y = !1;
                                    x(function(F) {
                                        "page" ===
                                        F.type && (y = !0)
                                    }, t);
                                    y && (h || q.push({
                                        type: "event",
                                        event: "fatalError",
                                        data: {
                                            code: "invalid-snapshot",
                                            Yg: "p.s.f",
                                            stack: ""
                                        }
                                    }), b())
                                });
                                var r = Wb(function(t) {
                                    "eof" === n(t, "data.type") || "eof" === t.event ? (q.push(t), p.push(t), q.flush(!0), p.flush(!0)) : ("event" === t.type ? q : p).push(t)
                                });
                                U(a, b, 864E5);
                                Tb(a, function() {
                                    var t, y;
                                    vb(a, (t = {}, t.counterKey = e, t.name = "webvisor", t.data = (y = {}, y.version = 2, y), t));
                                    l.start(r)
                                })
                            }
                        }
                    }));
                    return function() {
                        return b()
                    }
                }),
                pv = B("w2.cs", function(a, c) {
                    var b, d = L(c);
                    fg(a, d, (b = {}, b.webvisor = !!c.zb,
                        b))
                }),
                qv = ["rt", "mf"],
                Gf = v(Kc, L),
                bi = w(sd, gc),
                rv = mb("isp", function(a, c) {
                    pa(c, function(b) {
                        var d = ub(function(h) {
                            return n(b, "settings." + h)
                        }, qv);
                        if (d && Zd(a)) {
                            var e = zf(b) && !qe(a),
                                f = Gf(c);
                            z(f, {
                                Rb: d,
                                status: e ? 3 : 4
                            });
                            if (!e) {
                                e = co(a, c, d);
                                var g = function(h) {
                                    f.status = h
                                };
                                return ("mf" === d ? fo : eo)(a, c, e).then(u(1, g))["catch"](u(2, g))
                            }
                        }
                    })["catch"](E(a, "l.isp"))
                }),
                Xl = B("fbq.o", function(a, c, b) {
                    var d = n(a, "fbq");
                    if (d && d.callMethod) {
                        var e = function() {
                            var g = Pa(arguments),
                                h = d.apply(void 0, g);
                            c(g);
                            return h
                        };
                        z(e, d);
                        b && x(c, b);
                        a.fbq =
                            e
                    } else var f = U(a, C([a, c].concat(Ba(d && d.queue)), Xl), 1E3, "fbq.d");
                    return H(la, null, a, f)
                }),
                hd, Ib, id, oh = (hd = {}, hd.add_to_wishlist = "add-to-wishlist", hd.begin_checkout = "begin-checkout", hd.generate_lead = "submit-lead", hd.add_payment_info = "add-payment-info", hd),
                ph = (Ib = {}, Ib.AddToCart = "add-to-cart", Ib.Lead = "submit-lead", Ib.InitiateCheckout = "begin-checkout", Ib.Purchase = "purchase", Ib.CompleteRegistration = "register", Ib.Contact = "submit-contact", Ib.AddPaymentInfo = "add-payment-info", Ib.AddToWishlist = "add-to-wishlist",
                    Ib.Subscribe = "subscribe", Ib),
                ao = (id = {}, id["1"] = oh, id["2"] = oh, id["3"] = oh, id["0"] = ph, id),
                bo = [ph.AddToCart, ph.Purchase],
                sv = sa(function(a, c) {
                    var b = n(c, "ecommerce"),
                        d = n(c, "event") || "";
                    if (!(b = b && d && {
                            version: "3",
                            rc: d
                        })) a: {
                        if (R(c) || Sa(c))
                            if (b = Pa(c), d = b[1], "event" === b[0] && d) {
                                b = {
                                    version: "2",
                                    rc: d
                                };
                                break a
                            }
                        b = void 0
                    }
                    b || (b = (b = n(c, "ecommerce")) && {
                        version: "1",
                        rc: G(",", da(b))
                    });
                    b && a(b)
                }),
                tv = B("ag.e", function(a, c) {
                    if ("0" === c.ca) {
                        var b = [],
                            d = E(a, "ag.s", C([ma, b], x));
                        pa(c, function(e) {
                            if (n(e, "settings.auto_goals") && za(a,
                                    c) && (e = He(a, c, "autogoal").reachGoal)) {
                                e = C([e, c.sd], $n);
                                var f = sv(e);
                                e = C([a, e], Zn);
                                b.push(Xl(a, e));
                                b.push(ij(a, "dataLayer", function(g) {
                                    g.za.F(f)
                                }))
                            }
                        });
                        return d
                    }
                }),
                uv = /[^\d.,]/g,
                vv = /[.,]$/,
                Xn = B("ep.pp", function(a, c) {
                    if (!c) return 0;
                    a: {
                        var b = c.replace(uv, "").replace(vv, "");
                        var d = "0" === b[b.length - 1];
                        for (var e = b.length; 0 < e && !(3 < b.length - e + 1 && d); --e) {
                            var f = b[e - 1];
                            if (I(f, [",", "."])) {
                                d = f;
                                break a
                            }
                        }
                        d = ""
                    }
                    b = d ? c.split(d) : [c];
                    d = d ? b[1] : "00";
                    b = parseFloat(Ub(b[0]) + "." + Ub(d));
                    d = Math.pow(10, 8) - .01;
                    a.isNaN(b) ? b = 0 : (b = a.Math.min(b,
                        d), b = a.Math.max(b, 0));
                    return b
                }),
                wv = [
                    [
                        ["EUR", "\u20ac"], "978"
                    ],
                    [
                        ["USD", "\u0423\\.\u0415\\.", "\\$"], "840"
                    ],
                    [
                        ["UAH", "\u0413\u0420\u041d", "\u20b4"], "980"
                    ],
                    ["\u0422\u0413 KZT \u20b8 \u0422\u04a2\u0413 TENGE \u0422\u0415\u041d\u0413\u0415".split(" "), "398"],
                    [
                        ["GBP", "\u00a3", "UKL"], "826"
                    ],
                    ["RUR RUB \u0420 \u0420\u0423\u0411 \u20bd P \u0420UB P\u0423\u0411 P\u0423B PY\u0411 \u0420Y\u0411 \u0420\u0423B P\u0423\u0411".split(" "), "643"]
                ],
                xv = v(function(a) {
                    return new RegExp(G("|", a), "i")
                }),
                yv = B("ep.cp", function(a) {
                    if (!a) return "643";
                    var c = Zi(a);
                    return (a = ub(function(b) {
                        return xv(b[0]).test(c)
                    }, wv)) ? a[1] : "643"
                }),
                zv = v(function() {
                    function a() {
                        var k = h + "0",
                            l = h + "1";
                        f[k] ? f[l] ? (h = h.slice(0, -1), --g) : (e[l] = b(8), f[l] = 1) : (e[k] = b(8), f[k] = 1)
                    }

                    function c() {
                        var k = h + "1";
                        f[h + "0"] ? f[k] ? (h = h.slice(0, -1), --g) : (h += "1", f[h] = 1) : (h += "0", f[h] = 1)
                    }

                    function b(k) {
                        void 0 === k && (k = 1);
                        var l = d.slice(g, g + k);
                        g += k;
                        return l
                    }
                    for (var d = G("", $h("Cy2FcreLJLpYXW3BXFJqldVsGMwDcBw2BGnHL5uj1TKstzse3piMo3Osz+EqDotgqs1TIoZvKtMKDaSRFztgUS8qkqZcaETgKWM54tCpTXjV5vW5OrjBpC0jF4mspUBQGd95fNSfv+vz+g+Hze33Hg8by+Yen1PP6zsdl7PQCwX9mf+f7FMb9x/Pw+v2Pp8Xy74eTwuBwTt913u4On1XW6hxOO5nIzFam00tC218S0kaeugpqST+XliLOlMoTpRQkuewUxoy4CT3efWtdFjSAAm+1BkjIhyeU4vGOf13a6U8wzNY4bGo6DIUemE7N3SBojDr7ezXahpWF022y8mma1NuTnZbq8XZZlPStejfG/CsbPhV6/bSnA==")),
                            e = {}, f = {}, g = 1, h = ""; g < d.length - 1;)("0" === b() ? c : a)();
                    return e
                }),
                Un = B("ep.dec", function(a, c) {
                    if (!c || qd(a)) return [];
                    var b = $h(c),
                        d = b[1],
                        e = b[2],
                        f = b.slice(3);
                    if (2 !== Ae(b[0])) return [];
                    b = zv();
                    f = G("", f);
                    e = Ae(d + e);
                    var g = "";
                    d = "";
                    for (var h = 0; d.length < e && f[h];) g += f[h], b[g] && (d += String.fromCharCode(Ae(b[g])), g = ""), h += 1;
                    b = "";
                    for (f = 0; f < d.length;) e = d.charCodeAt(f), 128 > e ? (b += String.fromCharCode(e), f++) : 191 < e && 224 > e ? (g = d.charCodeAt(f + 1), b += String.fromCharCode((e & 31) << 6 | g & 63), f += 2) : (g = d.charCodeAt(f + 1), b += String.fromCharCode((e &
                        15) << 12 | (g & 63) << 6 | d.charCodeAt(f + 2) & 63), f += 3);
                    d = qb(a, b);
                    return R(d) ? A(js, d) : []
                }),
                Wn = B("ep.ent", function(a, c, b) {
                    a = "" + Xa(a, 10, 99);
                    b = "" + 100 * c + b + a;
                    if (16 < Sa(b)) return "";
                    b = ai("0", 16, b);
                    c = b.slice(0, 8);
                    b = b.slice(-8);
                    c = (+c ^ 92844).toString(35);
                    b = (+b ^ 92844).toString(35);
                    return "" + c + "z" + b
                }),
                Yl = w(Zh, yv),
                Zl = B("ep.ctp", function(a, c, b, d) {
                    var e = Yl(a, b),
                        f = Yh(a, d);
                    Xh(a, c, e, f);
                    Da("MutationObserver", a.MutationObserver) && (new a.MutationObserver(function() {
                        var g = Yl(a, b),
                            h = Yh(a, d);
                        if (e !== g || f !== h) e = g, f = h, Xh(a, c, e, f)
                    })).observe(a.document.body, {
                        attributes: !0,
                        childList: !0,
                        subtree: !0,
                        characterData: !0
                    })
                }),
                Av = B("ep.chp", function(a, c, b, d, e) {
                    b && Ff(a, c);
                    return d || e ? fa(a).F(a.document, ["click"], E(a, "ep.chp.cl", C([a, c, d, e], Vn))) : D
                }),
                Ev = B("ep.i", function(a, c) {
                    if (od(a)) return Tn(a, c).then(function(b) {
                        var d = b.Tg,
                            e = d[0],
                            f = d[1],
                            g = d[2],
                            h = d[3],
                            k = d[4],
                            l = d[5],
                            m = d[6],
                            p = d[7],
                            q = d[8],
                            r = d[9],
                            t = d[10],
                            y = d[11],
                            F = d[12],
                            P = d[13],
                            M = d[14],
                            na = d[15];
                        if (!b.isEnabled) return K.resolve(D);
                        var wa = te(a, e),
                            Db = te(a, h),
                            Id = te(a, m),
                            Ee = te(a, q),
                            Bv = "" + e + f + g === "" + h + k + l;
                        return new K(function(Cv,
                            Dv) {
                            Nb(a)(Ra(Dv, function() {
                                wa && Zl(a, c, f, g, t, y, F);
                                Db && !Bv && Zl(a, c, k, l, P, M, na);
                                Cv(Av(a, c, Id || Ee, p, r))
                            }))
                        })
                    })
                }),
                Cn = ["RTCPeerConnection", "mozRTCPeerConnection", "webkitRTCPeerConnection"],
                Sn = w(da, Yc),
                Fv = B("cc.i", function(a, c) {
                    var b = C([a, c], Rn);
                    b = C([a, b, 300, void 0], U);
                    pa(c, b)
                }),
                Gv = u("9-d5ve+.r%7", Q),
                Hv = B("ad", function(a, c) {
                    if (!c.Ua) {
                        var b = J(a);
                        if (!b.C("adBlockEnabled")) {
                            var d = function(m) {
                                    I(m, ["2", "1"]) && b.D("adBlockEnabled", m)
                                },
                                e = Vc(a),
                                f = e.C("isad");
                            if (f) d(f);
                            else {
                                var g = u("adStatus", b.D),
                                    h = function(m) {
                                        m =
                                            m ? "1" : "2";
                                        d(m);
                                        g("complete");
                                        e.D("isad", m, 1200);
                                        return m
                                    },
                                    k = va(a, "adb", c);
                                if (!b.C("adStatus")) {
                                    g("process");
                                    var l = "metrika/a" + Gv().replace(/[^a-v]+/g, "") + "t.gif";
                                    On(a, function() {
                                        return k({
                                            na: {
                                                Ba: l
                                            }
                                        }).then(u(!1, h))["catch"](u(!0, h))
                                    })
                                }
                            }
                        }
                    }
                }),
                Iv = B("pr.p", function(a, c) {
                    var b, d;
                    if (sg(a)) {
                        var e = va(a, "5", c),
                            f = Ja((b = {}, b.pq = 1, b.ar = 1, b));
                        e({
                            K: f,
                            J: (d = {}, d["page-url"] = S(a).href, d["page-ref"] = n(a, "document.referrer") || "", d)
                        }, c)["catch"](E(a, "pr.p.s"))
                    }
                }),
                Wh = !1,
                Jv = B("fid", function(a) {
                    var c, b = D;
                    if (!O(a.PerformanceObserver)) return b;
                    var d = J(a);
                    if (d.C("fido")) return b;
                    d.D("fido", !0);
                    var e = new a.PerformanceObserver(E(a, "fid", function(f) {
                        f = f.getEntries()[0];
                        d.D("fid", a.Math.round(100 * (f.processingStart - f.startTime)));
                        b()
                    }));
                    b = function() {
                        return e.disconnect()
                    };
                    try {
                        e.observe((c = {}, c.type = "first-input", c.buffered = !0, c))
                    } catch (f) {}
                    return b
                }),
                Kv = B("lt.p", mb("lt.p", function(a) {
                    var c;
                    if (Da("PerformanceObserver", a.PerformanceObserver)) {
                        var b = 0,
                            d = new a.PerformanceObserver(E(a, "lt.o", function(e) {
                                e && e.getEntries && (e = e.getEntries(), b = N(function(f,
                                    g) {
                                    return f + g.duration
                                }, b, e), Wd(a).D("lt", b))
                            }));
                        try {
                            d.observe((c = {}, c.type = "longtask", c.buffered = !0, c))
                        } catch (e) {
                            return
                        }
                        return function() {
                            return d.disconnect()
                        }
                    }
                })),
                Lv = v(w(T("performance.memory.jsHeapSizeLimit"), Ea("concat", ""))),
                Mv = ["availWidth", "availHeight", "availTop"],
                Nv = "appName vendor deviceMemory hardwareConcurrency maxTouchPoints appVersion productSub appCodeName vendorSub".split(" "),
                Ov = ["webgl", "experimental-webgl"],
                Mn = [-.2, -.9, 0, .4, -.26, 0, 0, .732134444, 0],
                Cf = u(Ta("ccf"), Va),
                Ln = "prefers-reduced-motion;prefers-reduced-transparency;prefers-color-scheme: dark;prefers-color-scheme: light;pointer: none;pointer: coarse;pointer: fine;any-pointer: none;any-pointer: coarse;any-pointer: fine;scan: interlace;scan: progressive;color-gamut: srgb;color-gamut: p3;color-gamut: rec2020;update: fast;update: slow;update: none;grid: 0;grid: 2;hover: hover;inverted-colors: inverted;inverted-colors: none".split(";"),
                Uh = "video/ogg video/mp4 video/webm audio/x-aiff audio/x-m4a audio/mpeg audio/aac audio/wav audio/ogg audio/mp4".split(" "),
                Jn = "theora vorbis 1 avc1.4D401E mp4a.40.2 vp8.0 mp4a.40.5".split(" "),
                En = v(Ui),
                Th = v(qb, bb),
                Pv = B("phc.p", function(a, c) {
                    if (!yl(a)) return pa(c, function(b) {
                        var d = c.id,
                            e = Qc(a, void 0, d),
                            f = e.C("phc_settings") || "";
                        if (b = n(b, "settings.phchange")) {
                            var g = Ab(a, b) || "";
                            g !== f && e.D("phc_settings", g)
                        } else f && (b = Th(a, f));
                        e = n(b, "clientId");
                        f = n(b, "orderId");
                        b = n(b, "phones") || [];
                        e && f && b.length && (f = {
                            Db: "",
                            Pb: "",
                            Wf: 0,
                            ja: {},
                            Aa: [],
                            nf: !1,
                            gb: !0,
                            l: a,
                            kc: c
                        }, z(f, {
                            nf: !0
                        }), Sh(a, d, f), b = Kd(a), e = Wi(a, b, 1E3), d = H(Sh, null, a, d, f), e.F(d), Xi(a, b))
                    })
                }),
                qh = v(function(a, c) {
                    var b = J(a),
                        d = Oa(a),
                        e = [],
                        f = C([a, c, b, d], aq);
                    Dd(a) || bq(a, "14.1") || e.push(C([Bn, "pp", ""], f));
                    var g = !Al(a) || Af(a, 68);
                    g && e.push(C([Dn, "pu", ""], f));
                    !g || d.Ld || Zd(a) || (e.push(C([An, "zzlc", "na"], f)), e.push(C([zn, "cc", ""], f)));
                    return e.length ? {
                        Da: function(h, k) {
                            if (0 === b.C("isEU")) try {
                                x(Ge, e)
                            } catch (l) {}
                            k()
                        },
                        N: function(h, k) {
                            var l = h.K;
                            if (l && 0 === b.C("isEU")) try {
                                x(Ga(l),
                                    e)
                            } catch (m) {}
                            k()
                        }
                    } : {}
                }, w(bb, L)),
                Qv = w(function(a) {
                    return (a = n(a, "navigator.plugins")) && Sa(a) ? w(Ba, ua, Js(function(c, b) {
                        return c.name > b.name ? 1 : 2
                    }), Wb(Yp))(a) : ""
                }, Ce(",")),
                Rv = function(a) {
                    return function(c) {
                        var b = fb(c);
                        if (!b) return "";
                        b = b("canvas");
                        var d = [],
                            e = a(),
                            f = e.$g;
                        e = e.Qg;
                        try {
                            var g = Ea("getContext", b);
                            d = A(w(Q, g), e)
                        } catch (h) {
                            return ""
                        }
                        return (g = ub(Q, d)) ? f(c, {
                            canvas: b,
                            Fg: g
                        }) : ""
                    }
                }(function() {
                    return {
                        Qg: Ov,
                        $g: vn
                    }
                }),
                tn = ["name", "lang", "localService", "voiceURI", "default"],
                Sv = B("p.tfs", function(a) {
                    var c = J(a);
                    if (!c.C("tfs")) {
                        c.D("tfs", !0);
                        c = fa(a);
                        var b = D;
                        b = c.F(a, ["message"], function(d) {
                            var e = n(d, "origin");
                            if ("https://iframe-toloka.com" === e || "https://iframe-tasks.yandex" === e)
                                if (d = qb(a, d.data), ka(d) && "appendremote" === d.action)
                                    if (d = Oa(a), d.C("tfsc") || a.confirm("\u0414\u043e\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u0435 \u201c\u0420\u0430\u0437\u043c\u0435\u0442\u043a\u0430 \u0441\u0430\u0439\u0442\u043e\u0432\u201c \u043e\u0442 toloka.ai \u0437\u0430\u043f\u0440\u0430\u0448\u0438\u0432\u0430\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u043c\u0443 \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u044b. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044c?")) {
                                        d.D("tfsc",
                                            1);
                                        var f, g;
                                        J(a).D("_u", (f = {}, f.getCachedTags = Fe, f.button = (g = {}, g.closest = u(a, je), g.select = Zf, g.getData = u(a, ke), g), f));
                                        uc(a, {
                                            src: "https://yastatic.net/s3/metrika/2.1540128042.1/form-selector/button_ru.js"
                                        });
                                        b()
                                    } else a.close()
                        })
                    }
                }),
                rn = gb(/[a-z\u0430-\u044f\u0451,.]/gi),
                Tv = B("ice", function(a, c, b) {
                    (c = za(a, c)) && (b = Mh(a, b)) && Lh(a, c, b)
                }),
                Uv = B("ice", function(a, c, b) {
                    (c = za(a, c)) && (b = Mh(a, b)) && wj(a, b.Qh).then(C([a, c, b], Lh), E(a, "ice.s"))
                }),
                Vv = ["text", "email", "tel"],
                Wv = ["cc-", "name", "shipping"],
                Xv = B("icei", function(a,
                    c) {
                    if (ul(a)) {
                        var b = !1,
                            d = D,
                            e = D;
                        pa(c, function(f) {
                            if (!(Hf(a) || n(f, "settings.eu") || b)) {
                                f = n(f, "settings.cf") ? Uv : Tv;
                                var g = C([a, c], f),
                                    h = function(k) {
                                        return Qf(a, k) || !I(k.type, Vv) || $a(Gb, A(u(k.autocomplete, eb), Wv)) ? !1 : !0
                                    };
                                d = Ph(a, "input", ["blur"], g, h);
                                e = Ph(a, "form", ["submit"], function(k) {
                                    var l = k.target;
                                    l && (l = jb("input", l), x(function(m) {
                                        h(m) && g({
                                            target: m,
                                            isTrusted: k.isTrusted
                                        })
                                    }, l))
                                })
                            }
                        });
                        return function() {
                            b = !0;
                            d();
                            e()
                        }
                    }
                }),
                Kh, Yv = B("p.ai", function(a, c) {
                    if (Dd(a) || tf(a)) return pa(c, function(b) {
                        var d;
                        if (b = n(b, "settings.sbp")) return Jh(a,
                            z({}, b, (d = {}, d.c = c.id, d)), 10)
                    })
                }),
                Zv = "architecture bitness model platformVersion uaFullVersion fullVersionList".split(" "),
                $l = mb("uah", function(a) {
                    if (!Da("getHighEntropyValues", n(a, "navigator.userAgentData.getHighEntropyValues"))) return K.reject("0");
                    try {
                        return a.navigator.userAgentData.getHighEntropyValues(Zv).then(function(c) {
                            if (!ka(c)) throw "2";
                            return c
                        }, function() {
                            throw "1";
                        })
                    } catch (c) {
                        return K.reject("3")
                    }
                }),
                am = new RegExp(G("|", "yandex.com/bots;Googlebot;APIs-Google;Mediapartners-Google;AdsBot-Google;FeedFetcher-Google;Google-Read-Aloud;DuplexWeb-Google;Google Favicon;googleweblight;Lighthouse;Mail.RU_Bot;StackRambler;Slurp;msnbot;bingbot;www.baidu.com/search/spi_?der.htm".split(";")).replace(/[./]/g,
                    "\\$&")),
                kn = v(function(a) {
                    var c = lb(a);
                    return (c = am.test(c)) ? K.resolve(c) : $l(a).then(function(b) {
                        try {
                            return N(function(d, e) {
                                return d || am.test(e.brand)
                            }, !1, b.brands)
                        } catch (d) {
                            return !1
                        }
                    }, u(!1, Q))
                }),
                wc = ["0", "1", "2", "3"],
                Rc = wc[0],
                sf = wc[1],
                $v = wc[2],
                bm = ["GDPR-ok-view-detailed-0", "GDPR-ok-view-detailed-1", "GDPR-ok-view-detailed-2", "GDPR-ok-view-detailed-3"],
                Hh = ["GDPR-ok-view-default", "GDPR-ok-view-detailed"].concat(bm),
                rf = "GDPR-ok GDPR-cross GDPR-cancel 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 GDPR-settings GDPR-ok-view-default GDPR-ok-view-detailed 21 22 23".split(" ").concat(bm).concat(["28",
                    "29", "30", "31"
                ]),
                aw = "3 13 14 31 15 16 17 28".split(" "),
                oe = w(Wb(T("ymetrikaEvent.type")), Is(vc(rf))),
                bw = {
                    Yh: !0,
                    url: "https://yastatic.net/s3/gdpr/v3/gdpr",
                    zf: "",
                    rf: "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz cs da de el hr it nl pl sk sv".split(" ")
                },
                nn = mb("gdpr", function(a, c, b, d, e) {
                    function f(p) {
                        c("10");
                        b.F(Hh, function(q) {
                            var r;
                            q = q.type;
                            l.Sf((r = {}, r.type = q, r));
                            p({
                                value: Ih(q)
                            })
                        })
                    }
                    var g = void 0 === e ? bw : e;
                    e = g.url;
                    var h = g.zf,
                        k = g.Yh;
                    g = qn(a, g.rf, d.gj);
                    var l = re(a, d);
                    if (!l) return K.resolve({
                        value: Rc,
                        Nd: !0
                    });
                    if (a._yaGdprLoaded) return new K(function(p) {
                        c("7");
                        f(p)
                    });
                    var m = uc(a, {
                        src: "" + e + (k ? "" : g) + h + ".js"
                    });
                    return new K(function(p, q) {
                        m ? (c("7"), m.onerror = function() {
                            var r;
                            c("9");
                            l.Sf((r = {}, r.type = "GDPR-ok-view-default", r));
                            p(null)
                        }, m.onload = u(p, f)) : (c("9"), q(Ta("gdp.e")))
                    })
                }),
                bc, pn = (bc = {}, bc["GDPR-ok"] = "ok", bc["GDPR-ok-view-default"] = "ok-default", bc["GDPR-ok-view-detailed"] = "ok-detailed", bc["GDPR-ok-view-detailed-0"] = "ok-detailed-all", bc["GDPR-ok-view-detailed-1"] = "ok-detailed-tech", bc["GDPR-ok-view-detailed-2"] =
                    "ok-detailed-tech-analytics", bc["GDPR-ok-view-detailed-3"] = "ok-detailed-tech-other", bc),
                hn = "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz ar he sr uk zh".split(" "),
                Gh = [],
                Eh = Ea("push", Gh),
                gn = v(function(a, c) {
                    var b = c.C("gdpr");
                    return I(b, wc) ? "-" + b : ""
                }),
                cm = v(Jd),
                cw = v(function() {
                    var a = N(function(c, b) {
                        "ru" !== b && (c[b] = Il + "." + b);
                        return c
                    }, {}, Cg);
                    x(function(c) {
                        a[c] = c
                    }, da(Dl));
                    return a
                }),
                Zm = v(function(a) {
                    a = S(a).hostname;
                    return (a = ub(w(T("1"), Vi("test"), wb(ma)(a)), La(Dl))) && a[0]
                }),
                dm = function(a,
                    c) {
                    return function(b, d) {
                        var e = L(d);
                        e = cw(e);
                        var f = Xm(b, e),
                            g = J(b),
                            h = sb(b);
                        return Zd(b) || Ud(b) ? {} : {
                            N: function(k, l) {
                                var m = k.K,
                                    p = Ch(b);
                                m = !(m && m.C("pv"));
                                if (!p || h || m || !f.length) return l();
                                if (g.C("startSync")) cm(b).push(l);
                                else {
                                    g.D("startSync", !0);
                                    p = C([b, f, D, !1], a);
                                    m = uf[0];
                                    if (!m) return l();
                                    m(b).then(p).then(l, w(Sc(l), E(b, c)))["catch"](D)
                                }
                            }
                        }
                    }
                }(function(a, c, b, d) {
                    var e = ja(a),
                        f = J(a),
                        g = Oa(a);
                    b = bh(a, "c");
                    var h = Zb(a, b);
                    return Bb(function(k, l) {
                        function m() {
                            var r = g.C("synced");
                            f.D("startSync", !1);
                            r && (r[l.$h] = p, g.D("synced",
                                r));
                            r = cm(a);
                            x(ma, r);
                            Ze(r)
                        }
                        var p, q = h({
                            ba: {
                                ha: ["sync.cook"],
                                Qa: 1500
                            }
                        }, [Fa.Sa + "//" + l.Ni + "/sync_cookie_image_check" + (d ? "_secondary" : "")]).then(function() {
                            p = e(rb);
                            m()
                        })["catch"](function() {
                            p = e(rb) - 1435;
                            m()
                        });
                        q = u(q, Q);
                        return k.then(q)
                    }, K.resolve(), c)["catch"](E(a, "ctl"))
                }, "sy.c"),
                Jb, Vm = (Jb = {}, Jb.brands = "chu", Jb.architecture = "cha", Jb.bitness = "chb", Jb.uaFullVersion = "chf", Jb.fullVersionList = "chl", Jb.mobile = "chm", Jb.model = "cho", Jb.platform = "chp", Jb.platformVersion = "chv", Jb),
                Sm = v(function(a) {
                    return $l(a).then(Tm,
                        Wm)
                }),
                dw = mb("ot", function(a, c) {
                    if (Qe(a)) {
                        var b = fa(a);
                        return pa(c, E(a, "ot.s", function(d) {
                            if (n(d, "settings.oauth")) {
                                var e = [],
                                    f = sd(a, c);
                                e.push(b.F(a, ["message"], E(a, "ot.m", u(f, Rm))));
                                Nb(a)(Ra(D, E(a, "ot.b", function() {
                                    function g(q) {
                                        var r, t = q.href;
                                        t && eh(t, "https://oauth.yandex.ru/") && !eb(t, "_ym_uid=") && (t = eb(t, "?") ? "&" : "?", q.href += "" + t + Fc((r = {}, r._ym_uid = f, r.mc = "v", r)), b.F(q, ["click"], E(a, "ot.click", function() {
                                            var y = "et=" + l(Z);
                                            q.href += "&" + y
                                        })))
                                    }
                                    var h, k = a.document.body,
                                        l = ja(a),
                                        m = jb("a", k);
                                    x(g, m);
                                    if (Da("MutationObserver",
                                            a.MutationObserver)) {
                                        m = new a.MutationObserver(E(a, "ot.m", u(function(q) {
                                            q = q.addedNodes;
                                            for (var r = 0; r < q.length; r += 1) {
                                                var t = q[r];
                                                "A" === t.nodeName && g(t)
                                            }
                                        }, x)));
                                        var p = (h = {}, h.childList = !0, h.subtree = !0, h);
                                        m.observe(k, p);
                                        e.push(H(m.disconnect, m))
                                    }
                                })));
                                return C([Ge, e], x)
                            }
                        }))
                    }
                }),
                ew = B("p.cta", function(a) {
                    Nb(a)(Ra(D, function() {
                        var c = J(a);
                        if (Pm(a.document)) {
                            var b = 0;
                            if (ci(a, ve, "cta")) {
                                var d = D,
                                    e = function() {
                                        di(ve, "cta");
                                        d();
                                        la(a, b)
                                    };
                                d = fa(a).F(a, ["message"], B("p.cta.o", C([a, c, e], Qm)));
                                b = U(a, e, 1500)
                            } else c.D("cta.e",
                                "if")
                        } else c.D("cta.e", "ns")
                    }))
                }),
                Lm = ["bidResponse", "bidAdjustment", "bidWon"],
                Mm = ["cpm", "currency", "netRevenue", "requestTimestamp", "responseTimestamp"],
                Ia = {},
                fw = B("pj", function(a, c) {
                    var b, d = za(a, c),
                        e = d && d.params;
                    return e ? (b = {}, b.pbjs = function(f) {
                        R(f) && (f = ha(Gb, A(function(g) {
                            if (ka(g) && g.data && g.event && ka(g.data)) {
                                var h = n(g, "data.args");
                                return h ? {
                                    event: g.event,
                                    data: h
                                } : g
                            }
                        }, f)), Km(f), Nm(a, e))
                    }, b) : D
                }),
                Im = /(\D\d*)/g,
                Jm = v(function() {
                    var a = Fe();
                    return N(function(c, b) {
                        c[a[b]] = b;
                        return c
                    }, {}, da(a))
                }),
                gw = B("g.v.e",
                    function(a, c) {
                        return pa(c, E(a, "g.v.t", function(b) {
                            var d = za(a, c);
                            if (d && (b = n(b, "settings.goal_values"))) {
                                var e = ha(w(T("url"), u(a, Dm)), b);
                                if (0 !== e.length) {
                                    b = fa(a);
                                    var f = [];
                                    e = C([a, function(g) {
                                        var h, k;
                                        return d.params((h = {}, h.__ym = (k = {}, k.goal_values = g, k), h))
                                    }, e], Gm);
                                    f.push(b.F(a, ["click"], E(a, "g.v.c", C([e], Em))));
                                    f.push(b.F(a, ["submit"], E(a, "g.v.s", C([a, e], Fm))));
                                    return C([w(Q, ma), f], x)
                                }
                            }
                        }))
                    }),
                jf = "close stop focus blur open alert confirm prompt print postMessage captureEvents releaseEvents getSelection getComputedStyle matchMedia moveTo moveBy resizeTo resizeBy scroll scrollTo scrollBy getDefaultComputedStyle scrollByLines scrollByPages find dump requestIdleCallback cancelIdleCallback requestAnimationFrame cancelAnimationFrame reportError setTimeout clearTimeout setInterval clearInterval queueMicrotask fetch self history customElements event frames opener parent frameElement navigator clientInformation external performance visualViewport crypto speechSynthesis localStorage origin indexedDB caches sessionStorage window document location top".split(" "),
                pf = {},
                vh = D,
                hw = v(function(a, c) {
                    vh = c
                }),
                jd, zm = (jd = {}, jd.copyFromWindow = function(a, c, b) {
                    if (I(b, jf) || eh(b, "on")) throw Qa("rwp");
                    c = a[b];
                    if (ca(c) || mc(a, c) || ia(c) || O(c)) return c;
                    if (R(c)) return Vd(c);
                    if (ka(c)) return Cm(c)
                }, jd.loadScript = function(a, c, b, d, e) {
                    c = O(d) ? of ("ls.ol", function() {
                        return d.apply(null)
                    }) : D;
                    var f = O(e) ? of ("ls.ol", function() {
                        return e.apply(null)
                    }) : void 0;
                    Am(a, b, c, f)
                }, jd.callFromWindow = function(a, c, b) {
                    for (var d = [], e = 3; e < arguments.length; e++) d[e - 3] = arguments[e];
                    if (I(b, jf)) throw Qa("rwp");
                    e =
                        n(a, b);
                    if (!O(e)) throw Qa("wenf");
                    return e.apply(void 0, d)
                }, jd.createArgumentsQueue = function(a, c, b, d) {
                    function e() {
                        for (var g = 0; g < arguments.length; g++);
                        f.push(arguments)
                    }
                    if (0 !== b.length && 0 !== d.length && !n(a, b) && !n(a, d)) {
                        c = b.split(".");
                        d = d.split(".");
                        if (I(c[0], jf) || I(d[0], jf)) throw Qa("rwp");
                        var f = [];
                        wh(a, c)[c[c.length - 1]] = e;
                        wh(a, d)[d[d.length - 1]] = f;
                        return e
                    }
                }, jd),
                iw = ["ymab", "rcmx", "yaSurvey", "ym_debug"],
                em = v(function(a) {
                    hw(a, function(c, b) {
                        Cd(a, "ytm." + c, b)
                    });
                    return function(c) {
                        sm(c) && x(function(b) {
                            if (R(b) &&
                                1 === b[0]) {
                                var d = b[1];
                                I(d, iw) && of ("p." + d, tm)(a, b)
                            }
                        }, c.code)
                    }
                }),
                jw = B("y.t.m", function(a, c) {
                    return pa(c, E(a, "y.t.t", function(b) {
                        if (b = n(b, "settings.aytm")) b = qb(a, b), em(a)(b)
                    }))
                }),
                fm = {},
                gm = v(Kc),
                rm = w(Ea("exec", /counterID=(\d+)/), T("1")),
                hm = sa(function(a, c) {
                    var b, d = gm(a),
                        e = Ba(c),
                        f = e[0],
                        g = e[1],
                        h = e.slice(2);
                    if (g) {
                        e = qm(a, f);
                        var k = e[0],
                            l = e[1];
                        e = L(l);
                        d[e] || (d[e] = {});
                        d = d[e];
                        c.Te || fm[g] && N(function(m, p) {
                            return m || !!p(a, l, h, k)
                        }, !1, fm[g]) || ("init" === g ? (c.Te = !0, k ? Kb(a, "" + f, "dc", (b = {}, b.key = f, b)) : a["yaCounter" + l.id] =
                            new a.Ya[Fa.jc](z({}, h[0], l))) : k && k[g] && d.Nh ? (k[g].apply(k, h), c.Te = !0) : (b = d.Xf, b || (b = [], d.Xf = b), b.push(ra([f, g], h))))
                    }
                }),
                kw = mb("is", function(a, c) {
                    var b;
                    We(a) && em(a)((b = {}, b.code = [
                        [1, "ym_debug", [18, ["a", [37, [40, "require"], "loadScript"]],
                                ["b", [37, [40, "require"], "callFromWindow"]]
                            ],
                            [2, [37, [40, "a"], Jl + "/tag_debug.js", [24, null, [],
                                [3, [2, [37, [40, "b"], "Ya._metrika.ytmm.tag_debug.init", L(c)]]]
                            ]]]
                        ]
                    ], b))
                }),
                om = B("destruct.e", function(a, c, b) {
                    return function() {
                        var d = J(a),
                            e = c.id;
                        x(function(f, g) {
                            return O(f) && E(a,
                                "dest.fr." + g, f)()
                        }, b);
                        pm(a, L(c));
                        delete d.C("counters")[L(c)];
                        delete a["yaCounter" + e]
                    }
                }),
                kd = J(window);
            kd.Ia("hitParam", {});
            kd.Ia("lastReferrer", window.location.href);
            (function() {
                W.push(function(a, c) {
                    var b;
                    return b = {}, b.firstPartyParams = tt(a, c), b.firstPartyParamsHashed = Sq(a, c), b
                });
                $d.push("fpp");
                $d.push("fpmh")
            })();
            (function() {
                var a = J(window);
                a.Ia("getCounters", ut(window));
                ld.push(vt);
                Sg.push(function(c, b) {
                    b.counters = a.C("getCounters")
                })
            })();
            (function() {
                W.push(function(a, c) {
                    var b;
                    vb(a, (b = {}, b.counterKey =
                        L(c), b.name = "counter", b.data = pk(c), b))
                })
            })();
            Ca["1"] = ob;
            W.push(wt);
            ya["1"] = tc;
            yb(eg, -1);
            Xb["1"] = [
                [eg, -1],
                [Ve, 1],
                [Pe, 2],
                [Qb(), 3],
                [Bj, 4]
            ];
            W.push(xt);
            W.push(B("p.ar", function(a, c) {
                var b, d = va(a, "a", c);
                return b = {}, b.hit = function(e, f, g, h, k, l) {
                    var m, p, q, r = {
                        J: {},
                        K: Ja((m = {}, m.pv = 1, m.ar = 1, m))
                    };
                    f = ka(f) ? {
                        title: f.title,
                        Df: f.referer,
                        X: f.params,
                        cc: f.callback,
                        l: f.ctx
                    } : {
                        title: f,
                        Df: g,
                        X: h,
                        cc: k,
                        l: l
                    };
                    h = Md(c);
                    g = e || S(a).href;
                    h.url !== g && (h.ref = h.url, h.url = e);
                    e = f.Df || h.ref || a.document.referrer;
                    h = nc(a, c, "pv", (p = {}, p.id = c.id,
                        p.url = g, p.ref = e, p), f.X);
                    p = z(r.M || {}, {
                        X: f.X,
                        title: f.title
                    });
                    r = d(z(r, {
                        M: p,
                        J: z(r.J || {}, (q = {}, q["page-url"] = g, q["page-ref"] = e, q))
                    }), c).then(h);
                    return Xc(a, "p.ar.s", r, f.cc || D, f.l)
                }, b
            }));
            Ca.a = ob;
            Xb.a = Yb;
            ya.a = tl;
            W.push(He);
            Ca.g = ob;
            ya.g = tc;
            Xb.g = Yb;
            W.push(yt);
            W.push(zt);
            Xb.t = Yb;
            Ca.t = ob;
            ya.t = tc;
            W.push(B("cl.p", function(a, c) {
                function b(p, q, r, t) {
                    void 0 === t && (t = {});
                    r ? Je(a, c, {
                        url: r,
                        ob: !0,
                        Dc: p,
                        Hc: q,
                        sender: e,
                        kg: t
                    }) : h.warn("clel")
                }
                var d, e = va(a, "2", c),
                    f = [],
                    g = L(c),
                    h = pc(a, g),
                    k = E(a, "s.s.tr", u(Ne(a, g), Kq));
                g = {
                    l: a,
                    cb: c,
                    ah: f,
                    sender: e,
                    wj: J(a),
                    Og: dd(a, c.id),
                    yj: Dc(a),
                    Ui: u(u(g, ef(a)), w(ma, T("trackLinks")))
                };
                g = E(a, "cl.p.c", u(g, Hq));
                g = fa(a).F(a, ["click"], g);
                c.dg && k(c.dg);
                var l = E(a, "file.clc", C([!0, !1], b)),
                    m = E(a, "e.l.l.clc", C([!1, !0], b));
                f = E(a, "add.f.e.clc", At(f));
                return d = {}, d.file = l, d.extLink = m, d.addFileExtension = f, d.trackLinks = k, d.u = g, d
            }));
            Xb["2"] = Yb;
            Ca["2"] = ob;
            ya["2"] = tc;
            Ca.r = Sd("r");
            ya.r = tl;
            Za.push(B("p.r", function(a, c) {
                var b = Ct(a),
                    d = va(a, "r", c),
                    e = E(a, "rts.p");
                return pa(c, C([function(f, g) {
                    var h = {
                            id: g.Ng,
                            ca: g.ca
                        },
                        k = {
                            ba: {
                                da: g.yi
                            },
                            K: Ja(g.Cg),
                            J: g.X,
                            M: {
                                Tb: g.Tb
                            },
                            na: {
                                Ba: g.Ba
                            }
                        };
                    g.Ja && (k.Ja = wf(g.Ja));
                    h = d(k, h)["catch"](e);
                    return f.then(u(h, Q))
                }, K.resolve(), b], N))["catch"](e)
            }));
            aa("r", function(a) {
                return {
                    N: function(c, b) {
                        var d = c.K,
                            e = void 0 === d ? Ja() : d,
                            f = c.M.Tb,
                            g = Ld(a);
                        d = e.C("rqnl", 0) + 1;
                        e.D("rqnl", d);
                        if (e = n(g, G(".", [f, "browserInfo"]))) e.rqnl = d, cg(a);
                        b()
                    },
                    Da: function(c, b) {
                        nj(a, c);
                        b()
                    }
                }
            }, 1);
            yb(Ie, 100);
            aa("1", Ie, 100);
            W.push(Dt);
            aa("n", Ve, 1);
            aa("n", Pe, 2);
            aa("n", Qb(), 3);
            aa("n", Ie, 100);
            Ca.n = ob;
            ya.n = tc;
            qc({
                Le: {
                    ea: "accurateTrackBounce"
                }
            });
            W.push(Et);
            Ca.m = Sd("cm");
            ya.m = pt;
            aa("m", Qb(["u", "v", "vf"]), 1);
            aa("m", Ie, 2);
            qc({
                Kg: {
                    ea: "clickmap"
                }
            });
            W.push(Ft);
            W.push(Gt);
            W.push(Ht);
            W.push(It);
            (function() {
                W.push(Jt);
                $d.push("ecommerce");
                qc({
                    sd: {
                        ea: "ecommerce",
                        Pa: function(a) {
                            if (a) return !0 === a ? "dataLayer" : "" + a
                        }
                    }
                })
            })();
            W.push(Kt);
            Za.push(Mt);
            W.push(Nt);
            $d.push("user_id");
            Za.push(B("p.st", Ot));
            W.push(Pt);
            yb(function(a, c) {
                return {
                    Da: function(b, d) {
                        var e = za(a, c);
                        e = e && e.userParams;
                        var f = (b.M || {}).Fe;
                        e && f && e(f);
                        d()
                    }
                }
            }, 0);
            Xe.push("_ym_debug");
            Lc.unshift(St);
            W.push(Tt);
            Lc.push(function(a) {
                var c = J(a);
                c.C("i") || (c.D("i", !0), fa(a).F(a, ["message"], u(a, fq)))
            });
            (function() {
                var a, c = (a = {}, a.tp = w(bb, qk, Ob), a.tpid = w(bb, Vr), a);
                z(Pd, c)
            })();
            yb(Gd, 20);
            aa("n", Gd, 20);
            aa("1", Gd, 20);
            Lc.unshift(Vt);
            Pd.fp = function(a, c, b) {
                if (b.J && b.J.nohit) return null;
                b = J(a).C;
                if (!b("fpe")) return null;
                c = Ut(c);
                if (c.eh) return null;
                b = b("fht", Infinity);
                a: {
                    var d = n(a, "performance.getEntriesByType");
                    if (O(d)) {
                        if (a = ha(w(Q, T("name"), Aa("first-contentful-paint")), d.call(a.performance, "paint")), a.length) {
                            a =
                                a[0].startTime;
                            break a
                        }
                    } else {
                        var e = n(a, "chrome.loadTimes");
                        d = ql(a);
                        if (O(e) && (e = e.call(a.chrome), e = n(e, "firstPaintTime"), d && e)) {
                            a = 1E3 * e - d;
                            break a
                        }
                        if (a = n(a, "performance.timing.msFirstPaint")) {
                            a -= d;
                            break a
                        }
                    }
                    a = void 0
                }
                return a && b > a ? (c.eh = a, Math.round(a)) : null
            };
            W.push(function(a, c) {
                var b;
                return b = {}, b.ecommerceAdd = B("ecm.a", Xt(a, c)), b.ecommerceRemove = B("ecm.r", Yt(a, c)), b.ecommerceDetail = B("ecm.d", Zt(a, c)), b.ecommercePurchase = B("ecm.p", $t(a, c)), b
            });
            (function() {
                var a, c = {};
                c.bu = fu;
                c.pri = Op;
                c.wv = u(2, Q);
                c.ds =
                    Rp;
                c.co = function(b) {
                    return tb(J(b).C("jn"))
                };
                c.td = lu;
                z(c, (a = {}, a.iss = w(Ts, Ob), a.hdl = w(Us, Ob), a.iia = w(Vs, Ob), a.cpf = w(eu, Ob), a.ntf = v(function(b) {
                    b = n(b, "Notification.permission");
                    b = "denied" === b ? !1 : "granted" === b ? !0 : null;
                    return Wa(b) ? null : b ? 2 : 1
                }), a.eu = Rb("isEU"), a.ns = ql, a.np = function(b) {
                    return Xa(b, 0, 100) ? null : md(le(ab(Vf(b), 100)))
                }, a));
                c.pani = gu;
                c.pci = hu;
                c.si = iu;
                c.gi = ju;
                z(Pd, c)
            })();
            (function() {
                var a = {};
                a.hc = Rb("hc");
                a.oo = Rb("oo");
                a.pmc = Rb("cmc");
                a.lt = function(c) {
                    var b = Wd(c).C("lt", null);
                    return b ? c.Math.round(100 *
                        b) : b
                };
                a.re = w(sr, Ob);
                a.aw = function(c) {
                    c = ub(w(ca, Hc), [c.document.hidden, c.document.msHidden, c.document.webkitHidden]);
                    return ca(c) ? null : tb(!c)
                };
                a.rcm = ou;
                a.yu = function(c) {
                    return (c = Qc(c, "").C("yandexuid")) && c.substring(0, 25)
                };
                a.ifc = Rb("ifc");
                a.ifb = Rb("ifb");
                a.ecs = Rb("ecs");
                a.csi = Rb("scip");
                a.cdl = Rb("cdl");
                a.eco = v(Mp, w(bb, L));
                a.dss = Rb("dSync");
                z(lg, a)
            })();
            ya.er = fd;
            (function(a) {
                try {
                    var c = bh(a, "er"),
                        b = Jp(a, c);
                    ik.push(function(d, e, f, g) {
                        var h, k, l, m, p;
                        .01 >= a.Math.random() || b((h = {}, h[d] = (k = {}, k[Fa.bc] = (l = {},
                            l[e] = (m = {}, m[f] = g ? (p = {}, p[a.location.href] = g, p) : a.location.href, m), l), k), h))
                    })
                } catch (d) {}
            })(window);
            (function() {
                mf.push(Np);
                Oe.unshift(Ip);
                gh.push(function(a) {
                    var c = void 0;
                    void 0 === c && (c = !0);
                    J(a).D("oo", c)
                })
            })();
            yb(function(a, c) {
                return {
                    N: function(b, d) {
                        var e = b.J,
                            f = b.K;
                        !Gl[c.id] && f.C("pv") && c.exp && !e.nohit && (e.exp = c.exp, Gl[c.id] = !0);
                        d()
                    }
                }
            }, -99);
            W.push(pu);
            Xb.e = Yb;
            Ca.e = ob;
            ya.e = tc;
            qc({
                exp: {
                    ea: "experiments"
                }
            });
            Bk.experiments = "ex";
            (function() {
                var a;
                uf.push(qu);
                Ca.f = ob;
                z(ya, (a = {}, a.f = sl, a));
                aa("f", Qb(),
                    1);
                aa("f", Fj, 2);
                aa("f", Gd, 20)
            })();
            mf.push(function(a, c) {
                var b = {
                        oa: L(c),
                        nd: za(a, c),
                        cg: ja(a),
                        Td: Oa(a)
                    },
                    d = b.cg(rb);
                if (!b.Td.Ld) {
                    var e = b.Td.C("ymoo" + b.oa);
                    if (e && 30 > d - e) b = b.oa, delete J(a).C("counters", {})[b], Va(Ta("uws"));
                    else pa(c, ru(b))["catch"](E(a, "d.f"))
                }
            });
            (function() {
                var a, c, b = [Fb];
                z(ya, (a = {}, a.s = b, a.S = b, a.u = fd, a));
                z(Ca, (c = {}, c.s = Zb, c.S = ob, c.u = Zb, c));
                aa("s");
                aa("u");
                aa("S", Qb(["v", "hid", "u", "vf", "rn"]), 1);
                W.push(B("s", tp))
            })();
            Ca["8"] = Zb;
            ya["8"] = [kg];
            rl.push([kg, 0]);
            W.push(B("p.us", function(a, c) {
                return pa(c,
                    function(b) {
                        if (n(b, "settings.sbp")) return Fi(a, b, {
                            cb: c,
                            Rb: "8",
                            Rd: "cs"
                        })
                    })
            }));
            aa("p", Qb(hh), 1);
            Wg("pub", function(a, c) {
                return {
                    N: function(b, d) {
                        si(a, c, b);
                        d()
                    }
                }
            }, 1);
            Ca.p = vu;
            ya.p = ua([Eb, Fb]);
            Za.push(zu);
            qc({
                zb: {
                    ea: "webvisor",
                    Pa: Gb
                },
                Sg: {
                    ea: "disableFormAnalytics",
                    Pa: Gb
                }
            });
            aa("4", Qb(hh), 1);
            Ca["4"] = Kl;
            ya["4"] = ua([Eb, Fb, Zc]);
            Za.push(Fu);
            (function() {
                aa("W", Qb(hh), 1);
                Wg("wv", Io, 1);
                ya.W = ua([Eb, Fb]);
                Ca.W = Kl;
                Za.push(ov);
                W.push(pv);
                qc({
                    zb: {
                        ea: "webvisor"
                    }
                });
                qc({
                    Wi: {
                        ea: "trustedDomains"
                    },
                    fc: {
                        ea: "childIframe",
                        Pa: Gb
                    }
                });
                gh.push(function(a) {
                    J(a).C("stopRecorder", D)()
                })
            })();
            W.push(rv);
            aa("pi");
            Ca.pi = Zb;
            ya.pi = fd;
            Wg("w", function(a, c) {
                return {
                    N: function(b, d) {
                        if (b.K) {
                            var e = Gf(c),
                                f = e.status;
                            "rt" === e.Rb && f && (b.K.D("rt", f), b.na || (b.na = {}), b.na.Kh = 1 === f ? bi(a, c) + "." : "")
                        }
                        d()
                    }
                }
            }, 2);
            W.push(tv);
            W.push(Ev);
            ya["6"] = ua([Eb, Fb]);
            Ca["6"] = Zb;
            W.push(Fv);
            W.push(mu);
            (function() {
                Sg.push(function(a, c) {
                    c.informer = Pn(a)
                })
            })();
            yb(Df, 6);
            aa("1", Df, 6);
            aa("adb");
            aa("n", Df, 4);
            ya.adb = fd;
            Ca.adb = Vj;
            ld.push(Hv);
            ya["5"] = tc;
            Ca["5"] = ob;
            Xb["5"] = ha(w(Yc, vc([Ve,
                Pe
            ]), Hc), Yb);
            W.push(Iv);
            aa("5", Gd, 20);
            yb(Vh, 7);
            aa("n", Vh, 6);
            Za.push(Jv);
            Ca.d = ob;
            aa("d", Qb(["hid", "u", "v", "vf"]), 1);
            ya.d = fd;
            aa("n", function(a, c) {
                return {
                    Da: function(b, d) {
                        if (!b.M || !b.M.force) {
                            var e = .002,
                                f = c.id === Fa.ug ? 1 : .002,
                                g, h, k, l, m;
                            void 0 === e && (e = 1);
                            void 0 === f && (f = 1);
                            var p = Ed(a);
                            if (p && O(p.getEntriesByType) && (e = Math.random() > e, f = Math.random() > f, !e || !f)) {
                                p = p.getEntriesByType("resource");
                                for (var q = {}, r = {}, t = {}, y = Fl(), F = S(a).href, P = 0; P < p.length; P += 1) {
                                    var M = p[P],
                                        na = M.name.replace(El, "").split("?")[0],
                                        wa = gc(na),
                                        Db = (g = {}, g.dns = Math.round(M.domainLookupEnd - M.domainLookupStart), g.tcp = Math.round(M.connectEnd - M.connectStart), g.duration = Math.round(M.duration), g.response = Math.round(M.responseEnd - M.requestStart), g);
                                    "script" !== M.initiatorType || e || (r[na] = z(Db, (h = {}, h.name = M.name, h.decodedBodySize = M.decodedBodySize, h.transferSize = Math.round(M.transferSize), h)));
                                    !nu[wa] && !y[wa] || q[na] || f || (q[na] = z(Db, (k = {}, k.pages = F, k)))
                                }
                                da(q).length && (t.timings8 = q);
                                da(r).length && (t.scripts = r);
                                if (da(t).length) va(a, "d", c)({
                                    K: Ja((l = {}, l.ar = 1, l.pv = 1, l)),
                                    ba: {
                                        da: Ab(a, t) || void 0
                                    },
                                    J: (m = {}, m["page-url"] = F, m)
                                }, {
                                    id: Fa.xg,
                                    ca: "0"
                                })["catch"](E(a, "r.tim.ng2"))
                            }
                        }
                        d()
                    }
                }
            }, 7);
            ya.ci = [Fb];
            Ca.ci = Zb;
            Za.push(B("p.sci", function(a, c) {
                return pa(c, u(a, Nn))["catch"](E(a, "ins.cs"))
            }));
            W.push(Kv);
            Za.push(du);
            W.push(Pv);
            yb(qh, 8);
            aa("f", qh, 3);
            aa("n", qh, 5);
            ld.push(function(a) {
                return B("fip", function(c) {
                    if (!Al(c) || Ud(c)) {
                        var b = Oa(c);
                        if (!b.C("fip")) {
                            var d = w(Wb(w(function(e, f) {
                                return B("fip." + f, e)(c)
                            }, H(us, null))), Ce("-"))(a);
                            b.D("fip", d)
                        }
                    }
                })
            }([Rv, Qv, function(a) {
                var c =
                    n(a, "ApplePaySession"),
                    b = S(a).protocol;
                a = c && "https:" === b && !sb(a) ? c : void 0;
                c = "";
                if (!a) return c;
                try {
                    c = "" + a.canMakePayments();
                    b = "";
                    var d = a.supportsVersion;
                    if (O(d))
                        for (var e = 1; 20 >= e; e += 1) b += d.call(a, e) ? "" + e : "0";
                    return b + c
                } catch (f) {
                    return c
                }
            }, function(a) {
                a = n(a, "navigator") || {};
                return a.doNotTrack || a.msDoNotTrack || "unknown"
            }, function(a) {
                if (a = cu(a)) try {
                    for (var c = [], b = 0; b < Bl.length; b += 1) {
                        var d = a(Bl[b]);
                        c.push(d)
                    }
                    var e = c
                } catch (f) {
                    e = []
                } else e = [];
                return e ? G("x", e) : ""
            }, function(a) {
                var c = void 0;
                void 0 === c && (c =
                    Nv);
                var b = n(a, "navigator") || {};
                c = A(u(b, n), c);
                c = G("x", c);
                try {
                    var d = n(a, "navigator.getGamepads");
                    var e = oa(d, "getGamepads") && a.navigator.getGamepads() || []
                } catch (f) {
                    e = []
                }
                return c + "x" + Sa(e)
            }, Lv, function(a) {
                a = n(a, "screen") || {};
                return G("x", A(u(a, n), Mv))
            }, function(a) {
                return G("x", sn(a) || [])
            }, function(a) {
                a = In(a);
                return R(a) ? G("x", a) : a
            }, function(a) {
                return (a = Kn(a)) ? G("x", A(C(["", ["matches", "media"]], un), ua(yh(a)))) : ""
            }]));
            yb(function(a) {
                return {
                    N: function(c, b) {
                        var d = c.K,
                            e = Oa(a).C("fip");
                        e && d && (d.D("fip", e),
                            pe(c, "fip", tb(e)));
                        b()
                    }
                }
            }, 9);
            aa("h", function(a) {
                return {
                    Da: function(c, b) {
                        var d = c.Ci;
                        Xf(c) && d && J(a).D("isEU", n(d, "settings.eu"));
                        b()
                    }
                }
            }, 3);
            ld.push(nv);
            Lc.push(Sv);
            Za.push(Xv);
            W.push(Yv);
            qc({
                fj: {
                    ea: "yaDisableGDPR"
                },
                gj: {
                    ea: "yaGDPRLang"
                }
            });
            Oe.push(function(a, c) {
                return {
                    N: C([a, c], dn)
                }
            });
            Xe.push("gdpr");
            Xe.push("gdpr_popup");
            Bg.push(function(a, c) {
                var b = ne(a);
                b = oe(b);
                if (ha(vc(aw), b).length) return !0;
                b = c(a, "gdpr");
                return I(b, [Rc, $v])
            });
            Oe.push(function(a) {
                return {
                    N: function(c, b) {
                        var d = c.na || {},
                            e;
                        (e = n(a, "document.referrer")) ?
                        (e = Tc(a, e).host, e = xj(e), e = Il + "." + (e || su)) : e = jc;
                        c.na = z(d, {
                            Lh: [e]
                        });
                        b()
                    }
                }
            });
            yb(dm, 5);
            aa("1", dm, 6);
            ya.c = fd;
            Ca.c = Zb;
            aa("1", Bh, 7);
            yb(Bh, 7);
            Lc.push(B("hcp", zh));
            Za.push(B("p.ot", dw));
            Za.push(mb("cta", ew, !0));
            aa("n", function(a) {
                var c = J(a);
                return {
                    N: function(b, d) {
                        var e = b.M || {},
                            f = c.C("cta"),
                            g = c.C("cta.e");
                        if (f || g) {
                            e.X || (e.X = {});
                            e.X.__ym || (e.X.__ym = {});
                            var h = {};
                            f ? (f = A(function(k) {
                                var l, m = n(k, "topic");
                                k = n(k, "version");
                                return l = {}, l.topic = m, l.version = k, l
                            }, f), h.ct = f) : g && (h["ct.e"] = g);
                            z(e.X.__ym, h);
                            b.M = z(b.M || {},
                                e)
                        }
                        d()
                    }
                }
            }, 7);
            aa("n", eg, 8);
            W.push(fw);
            W.push(gw);
            Lc.push(B("cdl", function(a) {
                var c = J(a).Ia;
                if (a = n(a, "navigator.cookieDeprecationLabel")) try {
                    a.getValue().then(u("cdl", c), C(["cdl", "e"], c))
                } catch (b) {
                    c("cdl", "d")
                } else c("cdl", "na")
            }));
            Za.push(jw);
            W.push(function(a, c) {
                var b = gm(a),
                    d = L(c),
                    e = b[d];
                e || (e = {}, b[d] = e);
                e.Nh = !0;
                if (b = e.Xf) d = hm(a), x(d, b)
            });
            Za.unshift(kw);
            x(wb(ma)(window), Lc);
            if (window.Ya && kf) {
                var im = Fa.jc;
                window.Ya[im] = kf;
                st(window);
                x(w(Nc([window, window.Ya[im]]), ma), Sg)
            }(function(a) {
                var c = n(a, "ym");
                if (c) {
                    var b = n(c, "a");
                    b || (c.a = [], b = c.a);
                    var d = hm(a);
                    Le(a, b, function(e) {
                        e.za.F(d)
                    }, !0)
                }
            })(window)
        })()
    } catch (kf) {};
}).call(this)